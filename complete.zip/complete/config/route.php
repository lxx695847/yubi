<?php
use think\Route;
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006~2016 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------
//接口模块
Route::rule([
    'getPwd'=>'@index/Index/getPwd',

    'sendResult'  =>  '@api/Index/sendResult',
    'getRank'   =>    '@api/Index/getRank',
    'getGroup'  =>    '@api/Index/getGroup',
    'cardResult'  =>  '@api/Index/cardResult',
    'editState'   =>  '@api/Index/editState',
    'test'     =>   '@api/Index/test',
    'getExam'  =>   '@api/Index/getExam',
    'checkFileExist'   => '@api/Index/checkFileExist',
    'uploadFile' => '@api/Index/uploadFile',

    //test
    'Buy'       =>     '@api/Test/Buy',
    'Prepare'   =>     '@api/Test/Prepare',
    'getReceive'   =>    '@api/Test/getReceive',
    'dataReceive'   =>   '@api/Collect/dataReceive',

    //login
    'sendReport'   =>    '@api/Login/sendReport',
    'getLogin'     =>    '@api/Login/getLogin',
    'otherLogin'   =>    '@api/Login/otherLogin',
    'getBlind'     =>    '@api/Login/getBlind',
    'groupStatus'  =>    '@api/Login/groupStatus',
    'getDetail'    =>    '@api/Login/getDetail',
    'moreLogin'    =>    '@api/Login/moreLogin',
    'switchCheck'  =>    '@api/Login/switchCheck',

    //extra
    'getList'       =>     '@api/Extra/getList',
    'receiveAward'  =>     '@api/Extra/receiveAward',
    'getRecord'     =>     '@api/Extra/getRecord',
    'lotteryAward'  =>     '@api/Extra/lotteryAward',
    'blindAddress'  =>     '@api/Extra/blindAddress',
    'lotteryReceive'  =>   '@api/Extra/lotteryReceive',
    'lotteryReceives'  =>  '@api/Extra/lotteryReceives',
    'task'       =>        '@api/Extra/autoTask',

    //Ys
    'sendSms'     =>     '@api/Ys/sendSms',
    'meLogin'     =>     '@api/Ys/meLogin',

    //元素周期表
    'api/login/account'=>'@api/Element/account',
    'api/currentUser'=>'@api/Element/currentUser',
    'elementInfo'    =>   '@api/Element/elementInfo',
    'elementList'  =>  '@api/Element/elementList',
    //后台
    'appList'    =>    '@api/Element/appList',
    'getVersion'  =>   '@api/Element/getVersion',
    'appVersion'  =>   '@api/Element/appVersion',
    'appDel'    =>    '@api/Element/appDel',
    'verDel'    =>    '@api/Element/verDel',
    'appAdd'    =>    '@api/Element/appAdd',
    'verAdd'    =>    '@api/Element/verAdd',
    'appEdit'   =>    '@api/Element/appEdit',
    'verEdit'   =>    '@api/Element/verEdit',
    'getUsers'  =>   '@api/Element/getUsers',

    //周公解梦
    'sortDetail'  =>  '@api/Dream/sortDetail',
    'dreamDetail' =>  '@api/Dream/dreamDetail',
    'getEsTest' =>   '@api/Dream/getEsTest',
    'dreamLists' => '@api/Dream/dreamLists',
    'getScroll'  =>  '@api/Dream/getScroll',
    'sortDetail'  =>  '@api/Dream/sortDetail',
    'dreamDetail' =>  '@api/Dream/dreamDetail',
    'reports'  =>  '@api/Dream/reports',
    'logins'   =>  '@api/Dream/logins',
    'userActs' =>  '@api/Dream/userActs',
    'dreamRecord' => '@api/Dream/dreamRecord',
    'dreamSearch' => '@api/Dream/dreamSearch',
    'univerify'  =>  '@api/Dream/univerify',

    //表格处理
    'excelExport'=>'@api/excel/excelExport',
    'excelImport'=>'@api/excel/excelImport',

    'dingParts'=>'@api/DingTalk/dingParts',
    'dingUsers'=>'@api/DingTalk/dingUsers',
    'userInfo'=>'@api/DingTalk/userInfo',
    'sendAgentMsg'=>'@api/DingTalk/sendAgentMsg',
    'dingCode'=>'@api/DingTalk/dingCode',

    //视频处理
    'getPro' => '@api/Collect/getPro',
    'upyUploads'=>'@api/Collect/upyUploads',

    //企业微信
    'getMsg'=>'@api/Order/getMsg',
    'setMsg'=>'@api/Order/setMsg',
    'setMsgs'=>'@api/Order/setMsgs',
    'dataTest'=>'@api/Order/dataTest',
    'getPartMent'=>'@api/Order/getPartMent',
    'getUserOrder'=>'@api/Order/getUserOrder',
    'setVipTimes'=>'@api/Order/setVipTimes',
    'updateCount'=>'@api/Order/updateCount',
    'getPostList'=>'@api/Order/getPostList',
    'getStore'=>'@api/Order/getPostList',
    'payOrder'=>'@api/Order/payOrder',
    'aliPay'=>'@api/Order/aliPay',
    'newPostData'=>'@api/Order/newPostData',

    //lv后台
    'getCustomer'=>'@api/LV/getCustomer',
    'getGoods'=>'@api/LV/getGoods',
    'newGood'=>'@api/LV/newGood',
    'getRecords'=>'@api/LV/getRecords',
    'orderNews'=>'@api/LV/orderNews',
    'payNews'=>'@api/LV/payNews',
    'storeChange'=>'@api/LV/storeChange'
]);




<?php
define('mainUrls',$_SERVER['REQUEST_SCHEME'].'://'.$_SERVER['SERVER_NAME']);
return [
    // +----------------------------------------------------------------------
    // | 应用设置
    // +----------------------------------------------------------------------
    // 应用命名空间
    'app_namespace'          => 'app',
    // 应用调试模式
    'app_debug'              => true,
    // 应用Trace
    'app_trace'              => true,
    // 应用模式状态
    'app_status'             => '',
    // 是否支持多模块
    'app_multi_module'       => true,
    // 入口自动绑定模块
    'auto_bind_module'       => false,
    // 注册的根命名空间
    'root_namespace'         => [],
    // 扩展函数文件
    'extra_file_list'        => [THINK_PATH . 'helper' . EXT],
    // 默认输出类型
    'default_return_type'    => 'html',
    // 默认AJAX 数据返回格式,可选json xml ...
    'default_ajax_return'    => 'json',
    // 默认JSONP格式返回的处理方法
    'default_jsonp_handler'  => 'jsonpReturn',
    // 默认JSONP处理方法
    'var_jsonp_handler'      => 'OAuth',
    // 默认时区
    'default_timezone'       => 'PRC',
    // 是否开启多语言
    'lang_switch_on'         => false,
    // 默认全局过滤方法 用逗号分隔多个
    'default_filter'         => '',
    // 默认语言
    'default_lang'           => 'zh-cn',
    // 应用类库后缀
    'class_suffix'           => false,
    // 控制器类后缀
    'controller_suffix'      => false,

    // +----------------------------------------------------------------------
    // | 模块设置
    // +----------------------------------------------------------------------

    // 默认模块名
    'default_module'         => 'index',
    // 禁止访问模块
    'deny_module_list'       => ['common'],
    // 默认控制器名
    'default_controller'     => 'Index',
    // 默认操作名
    'default_action'         => 'index',
    // 默认验证器
    'default_validate'       => '',
    // 默认的空控制器名
    'empty_controller'       => 'Error',
    // 操作方法后缀
    'action_suffix'          => '',
    // 自动搜索控制器
    'controller_auto_search' => false,

    // +----------------------------------------------------------------------
    // | URL设置
    // +----------------------------------------------------------------------

    // PATHINFO变量名 用于兼容模式
    'var_pathinfo'           => 's',
    // 兼容PATH_INFO获取
    'pathinfo_fetch'         => ['ORIG_PATH_INFO', 'REDIRECT_PATH_INFO', 'REDIRECT_URL'],
    // pathinfo分隔符
    'pathinfo_depr'          => '/',
    // URL伪静态后缀
    'url_html_suffix'        => 'html',
    // URL普通方式参数 用于自动生成
    'url_common_param'       => false,
    // URL参数方式 0 按名称成对解析 1 按顺序解析
    'url_param_type'         => 0,
    // 是否开启路由
    'url_route_on'           => true,
    // 路由使用完整匹配
    'route_complete_match'   => false,
    // 路由配置文件（支持配置多个）
    'route_config_file'      => ['route'],
    // 是否强制使用路由
    'url_route_must'         => false,
    // 域名部署
    'url_domain_deploy'      => false,
    // 域名根，如thinkphp.cn
    'url_domain_root'        => '',
    // 是否自动转换URL中的控制器和操作名
    'url_convert'            => false,
    // 默认的访问控制器层
    'url_controller_layer'   => 'controller',
    // 表单请求类型伪装变量
    'var_method'             => '_method',
    // 表单ajax伪装变量
    'var_ajax'               => '_ajax',
    // 表单pjax伪装变量
    'var_pjax'               => '_pjax',
    // 是否开启请求缓存 true自动缓存 支持设置请求缓存规则
    'request_cache'          => false,
    // 请求缓存有效期
    'request_cache_expire'   => null,
    // 全局请求缓存排除规则
    'request_cache_except'   => [],

    // +----------------------------------------------------------------------
    // | 模板设置
    // +----------------------------------------------------------------------

    'template'               => [
        // 模板引擎类型 支持 php think 支持扩展
        'type'         => 'Think',
        // 模板路径
        'view_path'    => '',
        // 模板后缀
        'view_suffix'  => 'html',
        // 模板文件名分隔符
        'view_depr'    => DS,
        // 模板引擎普通标签开始标记
        'tpl_begin'    => '{',
        // 模板引擎普通标签结束标记
        'tpl_end'      => '}',
        // 标签库标签开始标记
        'taglib_begin' => '{',
        // 标签库标签结束标记
        'taglib_end'   => '}',
    ],

    // 视图输出字符串内容替换
    'view_replace_str'       => [
        '__PATH__' => '/static',
        '__CSS__'    => '/static/css',
        '__JS__'   => '/static/js',
        '__IMG__'  => '/static/images',
        '__UPLOAD__' => '/Uploads',
        '__HOME__' => '/Home',
        '__STATICADMIN__'=>'/static/admin/',
        '__ADMINIMAGES__' => '/static/admin/images',
    ],

    // 默认跳转页面对应的模板文件
    'dispatch_success_tmpl'  => THINK_PATH . 'tpl' . DS . 'dispatch_jump.tpl',
    'dispatch_error_tmpl'    => THINK_PATH . 'tpl' . DS . 'dispatch_jump.tpl',

    // +----------------------------------------------------------------------
    // | 异常及错误设置
    // +----------------------------------------------------------------------

    // 异常页面的模板文件
    'exception_tmpl'         => THINK_PATH . 'tpl' . DS . 'think_exception.tpl',

    // 错误显示信息,非调试模式有效
    'error_message'          => '页面错误！请稍后再试～',
    // 显示错误信息
    'show_error_msg'         => false,
    // 异常处理handle类 留空使用 \think\exception\Handle
    'exception_handle'       => '',

    // +----------------------------------------------------------------------
    // | 日志设置
    // +----------------------------------------------------------------------
    'log'                    => [
        // 日志记录方式，内置 file socket 支持扩展
        'type'  => 'File',
        // 日志保存目录
        'path'  => LOG_PATH,
        // 日志记录级别
        'level' => [],
    ],

    // +----------------------------------------------------------------------
    // | Trace设置 开启 app_trace 后 有效
    // +----------------------------------------------------------------------
    'trace'                  => [
        // 内置Html Console 支持扩展
        'type' => 'Html',
    ],

    // +----------------------------------------------------------------------
    // | 缓存设置
    // +----------------------------------------------------------------------
    'cache'                  => [
        // 驱动方式
        'type'   => 'File',
        // 缓存保存目录
        'path'   => CACHE_PATH,
        // 缓存前缀
        'prefix' => '',
        // 缓存有效期 0表示永久缓存
        'expire' => 0,
    ],

    // +----------------------------------------------------------------------
    // | 会话设置
    // +----------------------------------------------------------------------
    'session' => [
        'id'             => '',
        // SESSION_ID的提交变量,解决flash上传跨域
        'var_session_id' => '',
        // SESSION 前缀
        'prefix'         => 'think',
        // 驱动方式 支持redis memcache memcached
        'type'           => '',
        // 是否自动开启 SESSION
        'auto_start'     => true,
        //session 页面共享
        'use_trans_sid'  => 1,
        //过期时间
        'expire' => 43200
    ],

    // +----------------------------------------------------------------------
    // | Cookie设置
    // +----------------------------------------------------------------------
    'cookie'                 => [
        // cookie 名称前缀
        'prefix'    => '',
        // cookie 保存时间
        'expire'    => 0,
        // cookie 保存路径
        'path'      => '/',
        // cookie 有效域名
        'domain'    => '',
        //  cookie 启用安全传输
        'secure'    => false,
        // httponly设置
        'httponly'  => '',
        // 是否使用 setcookie
        'setcookie' => true,
    ],

    //分页配置
    'paginate'               => [
        'type'      => 'page\page',
        'var_page'  => 'page',
        'list_rows' => 15
    ],

    'temp_id'=>[
        'login'=>'UkvFP7Wt3orPb-hbPersKaTwUxoEom_UDsOgxgevoNY'
    ],

    //腾讯云手机短信
    'sms'=>[
        'appid'=>'1400331409',
        'appkey'=>'34e523de821451cc9c55185a79b622a6',
        'smsSign'=>'手机排行榜',
        'templateId'=>'552041'
    ],

    //微信第三方登录
    'wx'=>[
        'appid'=>'wx092fb8588720e44b',
        'secret'=>'c00e9ed9de1f73c2af1ac06eea769e04',
        'tokenUrl'=>'https://api.weixin.qq.com/sns/oauth2/access_token',
        'infoUrl'=>'https://api.weixin.qq.com/sns/userinfo',
        'scope'  => 'snsapi_userinfo',
        'grant_type'=>'authorization_code',
        'lang' => 'zh_CN'
    ],

    'WEIXINPAY_CONFIG'  => array(
        'APPID'  => 'wx092fb8588720e44b', // 微信支付APPID
        'MCHID'  => '1608421838', // 微信支付MCHID 商户收款账号
//	    'KEY'           => 'wx8b3047d954f6b9bc', // 微信支付KEY
        'NOTIFY_URL' => mainUrls.'/index/pay/wxnotify', // 接收支付状态的连接
        'appSecret'  => 'SWDuJi8aQPguMuPmL3uLQGwNNIYnFges'
    ),

    'ALIPAY_CONFIG'=> array(
        'version'     =>  '1.0',
        'sign_type' => "RSA2",
        //支付宝公钥
        'alipay_public_key' => "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAkjv10bDOEBWeRx03b/4TWqlkK5RmloKSczzIESDd00OcNJAhn/3OUtQZ4JPz1FMq8D/J5ModLHikk91nTZXkE+3Vh4adiu7j4O8E/rXYyu+3+AFi3XaSS5aQw/B5O9jdpMkLFTURfXFrCkLgCeI8M1d10Vr5MI2P0nQMDh5aeSBUg8hileVL9vOUl0lTvbJ9SlIh/HU3Dt9WJCGTUSX70xnx4MMj3v+mA24T6wYCNSRjK8SHqpC6r4ubbmtrRID8TzFgmTBful/VaoH8Mynp3ISIqitvzdCCatyWOk9EwIA3L1hitLLQZd0ASlmh1QOBaFbQBCUcs2WY/eTJkD8RTwIDAQAB",
        //商户私钥
        'merchant_private_key' => "MIIEowIBAAKCAQEAliKJk4h8mh2LRgu6StEikYxbVrygpV2JCyVL2kXCrqRGNsIecdFZ38t5bEqrb2k7+VObnaP7EhYovnQO2+5HrrRsyGttV2BxGoVgj6UOcUsEYAUH6F7zBuq09VGdlfkJtKfoxadohyu36o2H7d3r1fb7tTFM9M2ZhgRKsyDs3sOEvrEdDPgGIsRfiSNudW30Fj/9aFt7xLfXN8hWHDb0zlIf3X0fZkpSSFgTQWb1EMA9mC7iNnEOG1MBl3E8c+DFyaD1NBLwuuXauvjH2sLW3+5pzLHPRDmV6AbnXovKcyUjtinDXpIc2N5OlXgoxhwys9pVK61Vw3x1tR2NT6GDKwIDAQABAoIBADstUdz9J1/31TW+2acz19RW5onBv/Budd4WzVczuBDuX16mFSn3wt0bbrjolbpMWH9mHSh9wjDW2yh2xoSZ31dVdqto7KhMM0io2e7EuHSfhRHz6bIF+vT2/mzTxrGef9zdcjq2SdU9vjiNoM55csPbnktFK3gyshjJCEii6brD6zyOd+9Gx1JPhw9memp0p3DrJOtPy/o74j1E6zvDzM1lT4kBY1lWyIrktFvKxE/dJ4Fem0bjPrSLT+f1/mdTBmrJ4oGzydVbfcTLNC6O4i+NP2yCm5wYTu/56DRFrFnMivRY8i6+wsjA88yAhSOc7wc/aWYVZ4/BEm8X3dJxNsECgYEA1ExJuFdZ1xGedYqb4DIjZP8hXBcO3dMojkcu4ofFZ1M0GcEBJz7YUpO64f5gCyao8nnyCFdjfNeobmpCB/5zpK5aSoM9KK8sSv8olxttOx9Z7CKjFvuTB7b07JTFqbxW9AugeSilGyilgIvTmzylk8raLX+XywvyUg4LfcIFpIUCgYEAtQpeoL92KRwt/LcfC3BpYXK+UxT/pEQX17bkDOdNZQkW60Bjvs54ZunW1mZ5eXeYDYfwTGDuRmy20cbGA7omMdtK+YpSN+aRfkn0kiq7AIjZywaPE0/Tjqof7nA09QkC8Ml/KAsavKOUQCYkLgqDW+A3P8xxX4lkOJTQIQ0ur+8CgYEAoLEV4+iKYhY+AO5nyi1pSRssXw48/H7GZdtPi7wFGY6LEytZ+iDBkM+tVz456HbczpyrLNEoxuhd3yWi0XYyhmZKhbgM5Oyi9ClqyeXCqkuyvuAA3naR9fbwMNrzOuUKVDMwxkSTpJkBnOk5xHkFQ3b56hJ4DQL/6kgjPo9LwhkCgYBfZ9SQb/WsGn6dpD9G/vl58kccb399KKlL88Tgi/B8YzrhxPALuLE4wtiF6kDv4zeNQes/xQEsudPqXw8xHaNNONyc/ujvLqHT5NNvR/d+g6AK3yz9J1882qizNgyiaRpUnEtXZeq0KJxS5gbBAKdS/qj/BRVmHHhlXP8Fu/WznwKBgAChuEWG1btS6yo+yo05Re58A6uQERD0Voz2n4plS7u8OjNkF3zZJIenKL/s7ZkLQQHizHGpVfcG3v7ZLFJ6BwgD4SKQs2ZtMOWz0oc72+KSnMSWhJlunhJMBVCFKZDSFzHV6lwEatFogpGKrgSZcwQSLbmKr/Mgryvfh/zZOAAi",
        //编码格式
        'charset' => "UTF-8",
        //支付宝网关
        'gatewayUrl' => "https://openapi.alipay.com/gateway.do",
        //应用ID
        'app_id' => "2021002139657702",
        //异步通知地址,只有扫码支付预下单可用
        'notify_url' => mainUrls."/index/Pay/alinotify",
        //异步通知地址,只有扫码支付预下单可用
        'return_url' => mainUrls."/index/Pay/alireturn",
        //最大查询重试次数
        'MaxQueryRetry' => "10",
        //查询间隔
        'QueryDuration' => "3",
    ),

    //一键登录
    'login'=>[
        'ApiKey'=>'05b3a3ebe265d7551a6524aab7dce02c',
        'ApiSecret'=>'ee0d1497ba897b20b98303625a9866b3'
    ],

    //滑块验证码
    'afs'=>[
        'AccessKey'=>'LTAI5tAQz193XyEfeW9BVEuV',
        'AccessSecret'=>'CDfeplhnPQ1iQ0WgkEJW5VWK6sDvtb',
        'scene'=>'nc_register',
        'appKey'=>'FFFF0N0000000000A311'
    ],

    'companyWx'=>[
        'corpid'=>'ww27032bd4abd5ecf5',
        'corpsecret_custom'=>'xEs6NJx-xtfcknWDHoqc73Z-8ub5Q7LyzCN2MHCreWI',
        'corpsecret_user'=>'lecs-_MvzfA8TId0G7PAZHysWNiTDbrVzEo7jTu5IfU',
        'corpsecret_app'=>'fwm5m4X7dumjDMK1rewGSl21xluKb7pGgDkIGTU5YMU',
        'tokenUrl'=>'https://qyapi.weixin.qq.com/cgi-bin/gettoken',
        'listUrl'=>'https://qyapi.weixin.qq.com/cgi-bin/externalcontact/list',
        'msgUrl'=>'https://qyapi.weixin.qq.com/cgi-bin/externalcontact/add_msg_template',
        'newsUrl'=>'https://qyapi.weixin.qq.com/cgi-bin/message/send',
        'PartMentUrl'=>'https://qyapi.weixin.qq.com/cgi-bin/user/list',
        'upPartMent'=>'https://qyapi.weixin.qq.com/cgi-bin/user/update'
    ],

    'dingding'=>[
        'AgentId'=>'1456049819',  //应用id
        'corpid'=>'ding0f9dcbbda3bdda0d35c2f4657eb6378f', //组织id
        'AppKey'=>'dingirqwtezgupyw1553',
        'AppSecret'=>'_cNa63FhjmQjW6kCiHilNCXi-AWusTFvmD_Z-rgxq-dqFCMQ3PexuFD5HlZCZ5gP',
        'accessUrl'=>'https://oapi.dingtalk.com/gettoken',
        'partUrl'=>'https://oapi.dingtalk.com/topapi/v2/department/listsub',
        'userList'=>'https://oapi.dingtalk.com/topapi/v2/user/list',
        'userInfo'=>'https://oapi.dingtalk.com/topapi/v2/user/get',
        'newsTell'=>'https://oapi.dingtalk.com/topapi/message/corpconversation/asyncsend_v2',

        //登录相关
        'loginAppKey'=>'dingoap4wchtfdi8tjmn8c',
        'loginAppSecret'=>'OU7P7grnnJVdmreZly4MFpCfD4SpkUDy-3ElFrcjZI-tr_M1XUlBqkhBL2_lZmER',
        //获取token（GET）
        "AccessTokenUrl"=>"https://oapi.dingtalk.com/sns/gettoken",
        //获取临时授权码 (POST)
        "PersistentCodeUrl"=>"https://oapi.dingtalk.com/sns/get_persistent_code",
        //获取用户授权（POST）
        "SnsTokenUrl"=>"https://oapi.dingtalk.com/sns/get_sns_token",
        //获取用户信息（GET）
        "UserInfoUrl"=>"https://oapi.dingtalk.com/sns/getuserinfo"
    ],

    'puzzle'=>[
        //最小步数7步(32种)
        [4,1,3,2,5,6,7,"",8],
        [4,1,3,2,6,"",7,5,8],
        [4,3,6,2,1,"",7,5,8],
        [1,3,6,"",4,2,7,5,8],
        [1,3,6,4,5,2,7,"",8],
        [1,"",6,4,3,2,7,5,8],
        [4,1,6,"",3,2,7,5,8],
        [2,5,3,"",1,6,4,7,8],
        [2,5,3,1,6,"",4,7,8],
        [2,5,3,1,7,6,4,"",8],
        [2,3,6,1,5,"",4,7,8],
        [4,1,2,5,3,"",7,8,6],
        [4,"",2,5,1,3,7,8,6],
        [4,1,2,5,8,3,7,"",6],
        [4,1,2,7,5,3,8,"",6],
        [2,4,3,"",1,5,7,8,6],
        [2,4,3,1,5,"",7,8,6],
        [2,4,3,1,8,5,7,"",6],
        [2,3,5,1,4,"",7,8,6],
        [4,"",3,2,1,5,7,8,6],
        [4,1,3,2,5,"",7,8,6],
        [4,1,3,2,8,5,7,"",6],
        [4,1,3,7,2,5,8,"",6],
        [2,4,3,"",1,6,7,5,8],
        [2,4,3,1,6,"",7,5,8],
        [2,4,3,1,5,6,7,"",8],
        [2,3,6,1,4,"",7,5,8],
        [1,6,2,"",4,3,7,5,8],
        [1,6,2,4,3,"",7,5,8],
        [1,6,2,4,5,3,7,"",8],
        [4,1,2,"",6,3,7,5,8],

        //最小步数9步(12步数)
        [5,"",3,2,1,6,4,7,8],
        [2,"",3,1,6,3,4,7,8],
        [2,5,3,4,1,6,7,"",8],
        [2,5,3,"",7,6,1,4,8],
        [2,5,3,1,6,8,4,"",7],
        [2,5,3,1,7,"",4,8,6],
        [5,1,3,2,6,"",4,7,8],
        [5,1,3,4,2,6,7,"",8],
        [1,"",6,5,3,2,4,7,8],
        [1,3,6,"",5,2,4,7,8],
        [5,1,3,"",2,6,4,7,8],

        //最小步数8步（10不）
        [1,5,2,8,"",3,4,7,6],
        [1,5,2,4,"",8,7,6,3],
        ["",5,2,1,8,3,4,7,6],
        [1,5,"",4,8,2,7,6,3],
        [4,1,"",5,3,2,7,8,6],
        [4,1,2,5,3,6,7,8,""],
        [4,1,2,7,5,3,8,6,""],
        ["",5,2,1,4,3,7,8,6],
        [1,5,2,4,3,6,"",7,8]
    ]
];

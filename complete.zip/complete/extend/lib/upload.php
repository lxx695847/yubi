<?php
/**
 * Created by PhpStorm.
 * User: GG
 * Date: 2018/5/15
 * Time: 14:26
 */
namespace lib;
use think\Image;

class upload
{
    /**
     * 单个上传
     * @param $name
     * @param $save(文件夹)
     * @return array
     */
    public function get_upload($name="file",$save="",$type=1,$saveName=""){
        $file = request()->file($name);
        if($file){
            $roots=ROOT_PATH . 'public' . DS . 'Uploads' . DS . $save;
            //保留原文件名
            if($type==2){
                $info=$file
                    ->move($roots,$saveName);  //DS为 "/"
            }else{
                $info = $file
                    ->rule('uniqid')     //也可以为date,md5
                    ->move($roots);  //DS为 "/"
            }
            if($info){
                // 成功上传后 获取上传信息
                $title= $info->getFilename();
//添加水印
//                $image =Image::open($roots . DS .$title);
//                $image->water(ROOT_PATH.DS.'public/logo.png',Image::WATER_SOUTHEAST)->save($roots.DS.$title);
                $data=[
                    'info'=>$save . DS . $title,
                    'status'=>2
                ];
            }else{
                // 上传失败获取错误信息
                $data=[
                   'info'=>$file->getError(),
                   'status'=>1
                ];
            };
            return $data;
        }else{
            return  $data=[
                'info'=>"暂无文件上传",
                'status'=>1
            ];
        }
    }

    //编辑器图片上传
    public function get_uploads($save=""){
        $file=current($_FILES);
//        $file = request()->file('file');
        if($file){
            $roots=ROOT_PATH . 'public' . DS . 'Uploads' . DS . $save;
            $info = $file->validate(['size'=>3145728,'ext'=>'jpg,png,jpeg,csv,xsl,xlsx,mp4'])
                ->rule('uniqid')     //也可以为date,md5
                ->move($roots);  //DS为 "/"
            if($info){
                // 成功上传后 获取上传信息+
                $title= $info->getFilename();
                //添加水印
                $image =Image::open($roots.DS.$title);
                $image->water(ROOT_PATH.DS.'public/logo.png',Image::WATER_SOUTHEAST)->save($roots.DS.$title);
                $src= svp . $save . DS .$title;
                echo json_encode(['location' => $src]);
            }
        }
    }

    /**
     * 多个上传
     * @param $name
     * @return string
     */
    public function multi_upload($name){
        $files = request()->file($name);
        $str="";
        // 获取表单上传文件
        foreach($files as $file){
            // 移动到框架应用根目录/public/uploads/ 目录下
            $info = $file->validate(['size'=>3145728,'ext'=>'jpg,png,gif,jpeg'])
                ->rule('uniqid')     //也可以为date,md5
                ->move(ROOT_PATH . 'public' . DS . 'uploads');  //DS为 "/"
            if($info){
                // 成功上传后 获取上传信息
               $str.= "http://".$_SERVER['HTTP_HOST']."/uploads/".$info->getFilename()."@";
            }else{
                // 上传失败获取错误信息
                $info=$file->getError();
                Info::ajaxError('500',$info);
            }
        }
        return $str;
    }
}
<?php
/**
 * Created by PhpStorm.
 * User: GG
 * Date: 2019/7/23
 * Time: 11:03
 */

namespace lib;
vendor('jpush.pull');

class push{
    /**
     * 系统通知
     * @param $type
     * @param $title
     * @param $content
     * @param string $device
     * @param $area
     */
    function sendInform($type,$title,$content,$device="",$area){
        $push=new \Vendor\jpush\pull();
        switch ($type){
            //所有平台
            case 1:
                $push->sendAll($title,$content,$area);
                break;

            // 单个平台
            case 2:
                switch ($device){
                    case 'ios':
                        $push->sendIos(2,$title,$content,false,$area);
                        break;
                    case "android":
                        $push->sendAndroid(2,$title,$content,false,$area);
                        break;
                }
                break;
        }
    }


    /**
     * 消息推送
     * @param $device
     * @param $uid
     * @param $title
     * @param $content
     * @param $area
     */
    function sendMsg($device,$uid,$title,$content,$area){
        $push=new \Vendor\jpush\pull();
        $opt['id']=$uid;
        $user=M('fm_user');
        $token=$user->where($opt)->getField('token');
        if($token && $token!="-1"){
            switch ($device){
                case "ios":
                    $push->sendIos(1,$title,$content,$token,false,$area);
                    break;
                case "android":
                    $push->sendAndroid(1,$title,$content,$token,false,$area);
                    break;
            }
        }

    }

    /**
     * 群发消息
     * @param $uid
     * @param $title
     * @param $content
     * @param $area
     */
    function sendGroup($uid,$title,$content,$area){
        $push=new \Vendor\jpush\pull();
        $opt['id']=$uid;
        $user=M('fm_user');
        //获取关注的人的设备号
        $attention=$user->where($opt)->getField('favorite_id');
        if($attention){
            $save['id']=array('in',explode(",",$attention));
            $token=$user->where($save)->getField('token',true);
            if($token){
                foreach ($token as $k=>$v){
                    if($v==false || $v=="-1"){
                        array_splice($token, $k, 1);
                    }
                }
            }
            if($token){
                $push->groupSend($title,$content,$token,$area);
            }
        }
    }

    /**
     * 定时任务
     * @param $action
     * @param $content
     * @param string $date
     * @param string $time
     */
    function dailyTask($action,$content,$date="",$time=""){
        $push=new \Vendor\jpush\pull();
        switch ($action){
            case 1:
                $push->getSchedule(1,$content,$date);
                break;
            case 2:
                $push->getSchedule(2,$content,"",$time);
                break;
        }
    }
}
<?php
namespace helper;

class arr{
    //取指定键名
    //array_flip 函数，将数组的键和值对调
    //array_intersect_key 函数,使用键名比较计算数组的交集
    //$keys 为数组
    public function newOnlyKeys($array, $keys){
        return array_intersect_key($array, array_flip($keys));
    }

    //移除指定键名
    function removeKeys($array, $keys) {
        return array_diff_key($array, array_flip($keys));
    }

    //清除空值   array_filter

    //去重 ，不保留键名  array_values(array_flip(Array))  一维数组

}
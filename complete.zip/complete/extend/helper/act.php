<?php
namespace helper;


class act extends HelperClass
{
    /**
     * 生成UUID
     * @param bool $strtoupper 是否转换为大小写输出
     * @param string $spilt 链接字符 false表示不连接
     * @return string
     */
    public static function uuid( $strtoupper = false , $spilt = '-')
    {
        $str = uniqid('',true);
        $arr = explode('.',$str);
        $str = base_convert($arr[0],16,36) .
            base_convert($arr[1],10,36).
            base_convert(bin2hex(random_bytes(5)),16,36);
        $len = 24;
        $str = substr($str,0,$len);
        if(strlen($str) < $len){
            $mt = base_convert(bin2hex(random_bytes(5)),16,36);
            $str = $str.substr($mt,0,$len - strlen($str));
        }
        if ( $spilt ) {
            $str = substr($str, 0, 5) . $spilt .
                substr($str, 5, 5) . $spilt .
                substr($str, 15, 5) . $spilt .
                substr($str, 20, $len);
        }
        return $strtoupper ? strtoupper($str) : $str;
    }
}
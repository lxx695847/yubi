<?php
namespace app\admin\model;
use lib\upload;

class Message{
    public function getSort(){
        $res=db('main_sort')->select();
        return get_column($res);
    }

    public function listData($page,$limit,$search){
        $opt['id']=['>',0];
        $opt1['pid']=['>',0];
        $sort=db('main_sort')->where($opt1)->column('id,title');
        if($search!=false) {
            $search = json_decode($search, true);
            if (isset($search['title'])) {
                $opt['title'] = ['like', "%" . $search['title'] . "%"];
            }
            if (isset($search['grade'])) {
                $opt['grade'] = $search['grade'];
            }
            if(isset($search['genre'])){
                $opt['genre'] = $search['genre'];
            }
            if(isset($search['content'])){
                $opt['content'] = $search['content'];
            }
            if(isset($search['material'])){
                $opt['material'] = $search['material'];
            }
            if(isset($search['holiday'])){
                $opt['holiday'] = $search['holiday'];
            }
            if(isset($search['topic'])){
                $opt['topic'] = $search['topic'];
            }
            if(isset($search['exam'])){
                $opt['exam'] = $search['exam'];
            }
        }
        $writing=db('main_writing');
        $joke=$writing->where($opt)->page($page,$limit)->select();
        if($joke){
            foreach ($joke as $k=>$v){
                $arr=[];
                if($v['grade']){
                    array_push($arr,$sort[$v['grade']]);
                }
                if($v['genre']){
                    array_push($arr,$sort[$v['genre']]);
                }
                if($v['content']){
                    array_push($arr,$sort[$v['content']]);
                }
                if($v['material']){
                    array_push($arr,$sort[$v['material']]);
                }
                if($v['holiday']){
                    array_push($arr,$sort[$v['holiday']]);
                }
                if($v['topic']){
                    array_push($arr,$sort[$v['topic']]);
                }
                if($v['exam']){
                    array_push($arr,$sort[$v['exam']]);
                }
                $joke[$k]['sign']=implode(',',$arr);
                $joke[$k]['upTime']=date('Y-m-d H:i',$v['upTime']);
            }
        }
        $row['list']=$joke;
        $row['count']=$writing->where($opt)->count();
        return $row;
    }

    public function getSingle($id){
        return db('main_writing')->where(['id'=>$id])->find();
    }

    public function getEdit($data){
        $upload=new upload();
        $opt['id']=$data['id'];
        $writing=db('main_writing');
        $list=[
            'upTime'=>strtotime($data['upTime']),
            'title'=>$data['title'],
            'detail'=>$data['detail'],
            'keywords'=>$data['keywords'],
            'author'=>$data['author'],
            'grade'=>$data['label0']==false ? '' : $data['label0'],
            'genre'=>$data['label1']==false ? '' : $data['label1'],
            'content'=>$data['label2']==false ? '' : $data['label2'],
            'material'=>$data['label3']==false ? '' : $data['label3'],
            'holiday'=>$data['label4']==false ? '' : $data['label4'],
            'topic'=>$data['label5']==false ? '' : $data['label5'],
            'exam'=>$data['label6']==false ? '' : $data['label6']
        ];
        $img=$writing->where($opt)->value('poster');
        $row=[];
        switch ($data['up']){
            case 1:
                if($img){unlink(vip.$img);}
                $list['poster']="";
                $id=$writing->where($opt)->update($list);
                $row['status']= $id==false ? 3 : 2;
                break;

            case 2:
                if($img){unlink(vip.$img);}
                $lit=$upload->get_upload('poster',$list['upTime']);
                if($lit['status']==1){
                    $row=$lit;
                }else{
                    $list['poster']=$lit['info'];
                    $writing->where($opt)->update($list);
                    $row['status']=2;
                }
                break;

            case 3:
                $id=$writing->where($opt)->update($list);
                $row['status']= $id==false ? 3 : 2;
                break;
        }
        return $row;
    }

    public function getDel($data){
        $model=db('main_writing');
        $opt=[];
        switch ($data['type']){
            //多删
            case 1:
                $ids=explode(',',$data['id']);
                $opt['id']=array('in',$ids);
                $img=$model->where($opt)->column('poster');
                foreach ($img as $v){
                    if( $v ){ unlink(vip.$v); }
                }
                break;
            //单删
            case 2:
                $opt['id']=$data['id'];
                $img=$model->where($opt)->value('poster');
                if( $img ){ unlink(vip.$img); }
                break;
        }
        $row=$model->where($opt)->delete();
        return $row ? true: false;
    }

    public function getAdd($data){
        $upload=new upload();
        $writing=db('main_writing');
        $list=[
            'title'=>trim($data['title']),
            'detail'=>trim($data['detail']),
            'upTime'=>time(),
            'keywords'=>$data['keywords'],
            'author'=>$data['author'],
            'grade'=>$data['label0']==false ? '' : $data['label0'],
            'genre'=>$data['label1']==false ? '' : $data['label1'],
            'content'=>$data['label2']==false ? '' : $data['label2'],
            'material'=>$data['label3']==false ? '' : $data['label3'],
            'holiday'=>$data['label4']==false ? '' : $data['label4'],
            'topic'=>$data['label5']==false ? '' : $data['label5'],
            'exam'=>$data['label6']==false ? '' : $data['label6']
        ];
        if($data['up']==2){
            $lit=$upload->get_upload('poster',time());
            if($lit['status']==1){
                $row=$lit;
                return $row;
            }else{
                $list['poster']=$lit['info'];
                $res=$writing->insert($list);
                check($res,1);
            }
        }else{
            $res=$writing->insert($list);
            check($res,1);
        }
    }
}
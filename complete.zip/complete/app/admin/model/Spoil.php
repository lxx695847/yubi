<?php
namespace app\admin\model;
use lib\upload;

class Spoil{
    //奖池商品抽奖
    public function lists($page,$limit,$search){
        $opt['id']=['>',0];
        if($search!=false) {
            $search = json_decode($search, true);
            if (isset($search['area'])) {
                $opt['area'] = $search['area'];
            }
            if (isset($search['kind'])) {
                $opt['kind'] = $search['kind'];
            }
        }
        $writing=db('switch_goods');
        $row['list']=$writing->where($opt)->page($page,$limit)->select();
        $row['count']=$writing->where($opt)->count();
        return $row;
    }

    public function getSingle($id){
        return db('switch_goods')->where(['id'=>$id])->find();
    }

    public function getAdd($data){
        $upload=new upload();
        $rows=[];
        $writing=db('switch_goods');
        $list=[
            'title'  =>  trim($data['title']),
            'kind'   =>  $data['kind'],
            'area'  =>   $data['area'],
            'intro'  =>  trim($data['intro']),
            'show'  =>  $data['show'],
            'sorts'  => $data['sorts']
        ];
        if(isset($data['card']) && $data['card']!=false){
            $row=json_decode($data['card'],true);
            $list['totalCount']=count($row);
        } else{
            $list['totalCount']= trim($data['totalCount']);
        }
        $list['limitCount']= $data['limitCount'] > $list['totalCount'] ?  $list['totalCount'] : trim($data['limitCount']);
        $list['dayCount']= $list['limitCount'];
        $list['count']= $list['totalCount'];

        $list['worth']= $data['worth']==false ? 1 : $data['worth'];
        if($data['up']==2){
            $lit=$upload->get_upload('pic','goods/'.time());
            if($lit['status']==1){
                return $lit;
            }else{
                $list['pic']=$lit['info'];
                $res=$writing->insertGetId($list);
            }
        }else{
            $res=$writing->insertGetId($list);
        }

        if($res!==false){
            model('admin/Manages')->writeLog('模块配置',session('user_info')['id'],'奖池商品添加');
            //虚拟商品入库
            if(isset($data['card']) && $data['card']!=false){
                $row=json_decode($data['card'],true);
                foreach ($row as $k=>$v){
                    $hit=[
                        'idCard'=>$v['idCard'],
                        'charge'=>1,
                        'gid'=>$res
                    ];
                    array_push($rows,$hit);
                }
                $dot=db('virtual_goods')->insertAll($rows);
                check($dot,1);
            }
            successReturn(201);
        }else{
            errorReturn(405);
        }
    }

    public function getEdit($data){
        $upload=new upload();
        $opt['id']=$data['id'];
        $writing=db('switch_goods');
        $list=[
            'title'  =>  trim($data['title']),
            'kind'   =>  $data['kind'],
            'area'  =>   $data['area'],
            'totalCount'  =>   trim($data['totalCount']),
            'intro'  =>  trim($data['intro']),
            'weight'  =>   trim($data['weight'])/100,
            'worth' => $data['worth']!=false ? $data['worth'] : 1,
            'show'  =>  $data['show'],
            'sorts'  => $data['sorts']
        ];
//        $list['count']=$list['totalCount'];
        $list['limitCount']= $data['limitCount']>$data['totalCount'] ?  $data['totalCount'] :trim($data['limitCount']);
        $list['dayCount']= $list['limitCount'];

//        $img=$writing->where($opt)->value('pic');
        $row=[];
        switch ($data['up']){
            case 1:
            /*    if($img){unlink(vip.$img);}*/
                $list['pic']="";
                $id=$writing->where($opt)->update($list);
                $row['status']= $id==false ? 3 : 2;
                break;

            case 2:
//                if($img){unlink(vip.$img);}
                $lit=$upload->get_upload('pic','goods/'.time());
                if($lit['status']==1){
                    $row=$lit;
                }else{
                    $list['pic']=$lit['info'];
                    $writing->where($opt)->update($list);
                    $row['status']=2;
                }
                break;

            case 3:
                $id=$writing->where($opt)->update($list);
                $row['status']= $id==false ? 3 : 2;
                break;
        }
        model('admin/Manages')->writeLog('模块配置',session('user_info')['id'],'奖池商品修改');
        return $row;
    }

    public function getDel($data){
        $model=db('switch_goods');
        $opt=[];
        switch ($data['type']){
            //多删
            case 1:
                $ids=explode(',',$data['id']);
                $opt['id']=array('in',$ids);
                $img=$model->where($opt)->column('pic');
                foreach ($img as $v){
                    if( $v ){ unlink(vip.$v); }
                }
                break;
            //单删
            case 2:
                $opt['id']=$data['id'];
                $img=$model->where($opt)->value('pic');
                if( $img ){ unlink(vip.$img); }
                break;
        }
        model('admin/Manages')->writeLog('模块配置',session('user_info')['id'],'奖池商品删除');
        $row=$model->where($opt)->delete();
        check($row,3);
    }

    //里程碑
    public function setSingle($id){
        return db('milestone')->where(['id'=>$id])->find();
    }

    public function milesData($page,$limit){
        $milestone=db('milestone');
        $list=$milestone->page($page,$limit)->select();
        $regular=db('system')->where(['id'=>1])->find();

        $opt=['area'=>1,'model'=>2];
        foreach ($list as $k=>$v){
            $count=db('index_lottery')->where($opt)->count();
            $rule=$count*$regular['game_coin']*$regular['game_base'];  //基数
            if($rule>=$v['goal']){
                $list[$k]['progress']=100;
                $list[$k]['state']=2;
            }else{
                $list[$k]['progress']=round($rule/$v['goal'],2)*100;
                $list[$k]['state']=1;
            }
        }
        return [
            'list'=>$list,
            'count'=>$milestone->count()
        ];
    }

    public function milesEdit($data){
        $opt['id']=$data['id'];
        $send=[
            'worth'=>trim($data['worth']),
            'intro'=>trim($data['intro'])
        ];
        if(isset($data['links'])){
            $send['links']=trim($data['links']);
        }
        $id=db('milestone')->where($opt)->update($send);
        model('admin/Manages')->writeLog('模块配置',session('user_info')['id'],'里程碑数据修改');
        $row['status']= $id==false ? 3 : 2;
        return $row;
    }

    //任务列表
    public function taskSingle($id){
        return db('task_list')->where(['id'=>$id])->find();
    }

    public function task_list($page,$limit,$search){
        $opt['show']=2;
        if($search!=false) {
            $search = json_decode($search, true);
            if (isset($search['type'])) {
                $opt['type'] = $search['type'];
            }
            if (isset($search['kind'])) {
                $opt['kind'] = $search['kind'];
            }
        }
        $writing=db('task_list');
        $row['list']=$writing->where($opt)->page($page,$limit)->select();
        $row['count']=$writing->where($opt)->count();
        return $row;
    }

    public function taskEdit($data){
        $opt['id']=$data['id'];
        $id=db('task_list')->where($opt)->setField('worth',$data['worth']);
        model('admin/Manages')->writeLog('模块配置',session('user_info')['id'],'任务列表修改');
        $row['status']= $id==false ? 3 : 2;
        return $row;
    }

    public function gameBase($param){
        $send=[
            'game_coin'=>$param['game_coin'],
            'game_bullion'=>$param['game_bullion']
        ];
        $res=db('system')->where(['id'=>1])->update($send);
        check($res,2);
    }

    public function sendSorts($sort){
        $mile=db('switch_goods');
        $opt=['area'=>$sort];
        $list=$mile->field('id,title,weight')->where($opt)->select();
        $dom=$mile->where($opt)->sum('weight');
        return [
            'list'=>$list,
            'count'=>$dom*100
        ];
    }
}
<?php
namespace app\admin\model;

class Examine extends Base{
    public function manager($page,$limit){
        $product=db('user');
        $row['list']=$product
            ->alias('a')
            ->field('a.*,c.title,c.base')
            ->join('auth_group_access b','a.id=b.uid')
            ->join('auth_group c','b.group_id=c.id')
            ->page($page,$limit)
            ->select();
        $row['count']=$product->count();
        return $row;
    }

    public function setSingle($id){
        $list['row']=db('user')
            ->alias('a')
            ->field('a.user,c.title,c.id as gid')
            ->join('auth_group_access b','a.id=b.uid')
            ->join('auth_group c','b.group_id=c.id')
            ->where(['a.id'=>$id])
            ->find();
        $opt['base']=['neq',2];
        $list['sort']=db('auth_group')->field('id,title')->where($opt)->select();
        return $list;
    }

    public function groups($page,$limit){
        $group=db('auth_group');
        $access=db('auth_group_access');
        $row['list']=$group->page($page,$limit)->select();
        foreach($row['list'] as $k=>$v){
            $opt['group_id']=$v['id'];
            $row['list'][$k]['count']=$access->where($opt)->count('uid');
        }
        $row['count']=$group->count();
        return $row;
    }

    public function getStatus($uid,$range,$act){
        $ins="";
        $opt['id']=$uid;
        $model="";
        switch ($range){
            case 1:
                $ins=db('user');
                $model='后台用户';
                break;
            case 2:
                $ins=db('login');
                $model="前台用户";
                break;
        }
        model('admin/Manages')->writeLog($model,session('user_info')['id'],'用户状态管理操作');
        return $ins->where($opt)->setField('status',$act);
    }

    public function watch_auth($group_id){
        $opt['id']=$group_id;
        $rules=db('auth_group')->where($opt)->value('rules');
        $row=db('auth_rule')->select();
        $checkedId=explode(",",$rules);
        foreach ($checkedId as $key=>$val){
            $checkedId[$key]=(int)$val;
        }
        foreach($row as $k=>$v){
            if(in_array($v['id'],$checkedId)){
                $row[$k]['checked']=true;
            }else{
                $row[$k]['checked']=false;
            }
        }

        $rows=[
            'data'=>[
                'list'=>$row,
                'checkedId'=>$checkedId
            ],
            'code'=>0,
            'msg'=>"获取成功"
        ];
        echo json_encode($rows);
        exit;
    }
}
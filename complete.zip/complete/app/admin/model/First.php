<?php
namespace app\admin\model;


class First extends Base{
    /**
     * 分析统计(用户，发放，提现，收入)
     * 公告
     */
    public function analyse($area){
        $dom=[];
        $time=get_week();
        if($area==1){
            $res1=$this->getSends($time,$area,['area'=>1,'model'=>2]);
            $res2=$this->getSends($time,$area,['area'=>2,'model'=>2]);
            foreach ($time as $k=>$v){
                $dom[$k]=[
                    'time'=>$v,
                    'count1'=>isset($res1['sum'][$v]) ? count($res1['sum'][$v]) : 0,
                    'people1'=>isset($res1['people'][$v]) ? count($res1['people'][$v]) : 0,
                    'count2'=>isset($res2['sum'][$v]) ? count($res2['sum'][$v]) : 0,
                    'people2'=>isset($res2['people'][$v]) ? count($res2['people'][$v]) : 0
                ];
            }
        }else if($area==5){
            $res1=$this->getSends($time,$area,['pid'=>1,'model'=>1]);
            $res2=$this->getSends($time,$area,['pid'=>2,'model'=>1]);
            $res3=$this->getSends($time,$area,['pid'=>3,'model'=>1]);
            $res4=$this->getSends($time,$area,['pid'=>4,'model'=>1]);
            $res5=$this->getSends($time,$area,['pid'=>5,'model'=>1]);
            $res6=$this->getSends($time,$area,['pid'=>6,'model'=>1]);
            foreach ($time as $k=>$v){
                $dom[$k]=[
                    'time'=>$v,
                    'count1'=>isset($res1['sum'][$v]) ? count($res1['sum'][$v]) : 0,
                    'count2'=>isset($res2['sum'][$v]) ? count($res2['sum'][$v]) : 0,
                    'count3'=>isset($res3['sum'][$v]) ? count($res3['sum'][$v]) : 0,
                    'count4'=>isset($res4['sum'][$v]) ? count($res4['sum'][$v]) : 0,
                    'count5'=>isset($res5['sum'][$v]) ? count($res5['sum'][$v]) : 0,
                    'count6'=>isset($res6['sum'][$v]) ? count($res6['sum'][$v]) : 0,
                ];
            }
        }else{
            $res1=$this->getSends($time,$area);
            foreach ($time as $k=>$v){
                $dom[$k]=[
                    'time'=>$v,
                    'count'=>isset($res1['sum'][$v]) ? count($res1['sum'][$v]) : 0,
                    'people'=>isset($res1['people'][$v]) ? count($res1['people'][$v]) : 0,
                    'share'=>isset($res1['share'][$v]) ? array_sum($res1['share'][$v]) : 0
                ];
            }
        }
        return ['list'=>array_reverse($dom),'count'=>7];
    }

    public function getSends($time,$area,$where=[]){
        $obj="";$word="";$dom=[];$push=[];
        $filed="";$share=[];
        switch ($area){
            case 1:
                $obj=db("index_lottery");
                $word="receive_time";
                $filed="uid,".$word;
                break;
            case 2:
                $obj=db("index_card");
                $word="complete_time";
                $filed="uid,share,".$word;
                break;
            case 4:
                $obj=db("index_puzzle");
                $word="complete_time";
                $filed="uid,share,".$word;
                break;
            case 5:
                $obj=db("index_lottery");
                $word="receive_time";
                $filed="uid,".$word;
                break;
        }

        $where[$word]=[['>=',(int)strtotime($time[0])],['<',(int)strtotime($time[6])+86400],'and'];
        $list=$obj->field($filed)->where($where)->select();
        if($area==1){
            foreach ($time as $key=>$val){
                foreach ($list as $k=>$v){
                    if($val==date('Y-m-d',$v[$word])){
                        $dom[$val][]=$list[$k];
                        $push[$val][$v['uid']][]=$list[$k];
                    }
                }
            }
        }else if($area==5){
            foreach ($time as $key=>$val){
                foreach ($list as $k=>$v){
                    if($val==date('Y-m-d',$v[$word])){
                        $dom[$val][]=$list[$k];
                    }
                }
            }
        }else{
            foreach ($time as $key=>$val){
                foreach ($list as $k=>$v){
                    if($val==date('Y-m-d',$v[$word])){
                        $dom[$val][]=$list[$k];
                        $push[$val][$v['uid']][]=$list[$k];
                        $share[$val][]=$list[$k]['share'];
                    }
                }
            }
        }

        return [
            'sum'=>$dom,
            'people'=>$push,
            'share'=>$share
        ];
    }


    /**
     * 图表显示
     */
    public function show($area){
        $time=get_week();
        if($area==1){
            $list=[
                'count1'=>[],
                'count2'=>[],
                'people1'=>[],
                'people2'=>[]
            ];
            $res1=$this->getSends($time,$area,['area'=>1,'model'=>2]);
            $res2=$this->getSends($time,$area,['area'=>2,'model'=>2]);
            foreach ($time as $k=>$v){
                if(!isset($res1['sum'][$v])){
                    array_push($list['count1'],0);
                }else{
                    array_push($list['count1'],count($res1['sum'][$v]));
                }

                if(!isset($res1['people'][$v])){
                    array_push($list['people1'],0);
                }else{
                    array_push($list['people1'],count($res1['people'][$v]));
                }

                if(!isset($res2['sum'][$v])){
                    array_push($list['count2'],0);
                }else{
                    array_push($list['count2'],count($res2['sum'][$v]));
                }

                if(!isset($res2['people'][$v])){
                    array_push($list['people2'],0);
                }else{
                    array_push($list['people2'],count($res2['people'][$v]));
                }
            }
        }elseif ($area==5){
            $list=[
                'count1'=>[], 'count2'=>[],
                'count3'=>[], 'count4'=>[],
                'count5'=>[], 'count6'=>[]
            ];
            $res1=$this->getSends($time,$area,['pid'=>1,'model'=>1]);
            $res2=$this->getSends($time,$area,['pid'=>2,'model'=>1]);
            $res3=$this->getSends($time,$area,['pid'=>3,'model'=>1]);
            $res4=$this->getSends($time,$area,['pid'=>4,'model'=>1]);
            $res5=$this->getSends($time,$area,['pid'=>5,'model'=>1]);
            $res6=$this->getSends($time,$area,['pid'=>6,'model'=>1]);
            foreach ($time as $k=>$v){
                if(!isset($res1['sum'][$v])){
                    array_push($list['count1'],0);
                }else{
                    array_push($list['count1'],count($res1['sum'][$v]));
                }
                if(!isset($res2['sum'][$v])){
                    array_push($list['count2'],0);
                }else{
                    array_push($list['count2'],count($res2['sum'][$v]));
                }
                if(!isset($res3['sum'][$v])){
                    array_push($list['count3'],0);
                }else{
                    array_push($list['count3'],count($res3['sum'][$v]));
                }
                if(!isset($res4['sum'][$v])){
                    array_push($list['count4'],0);
                }else{
                    array_push($list['count4'],count($res4['sum'][$v]));
                }
                if(!isset($res5['sum'][$v])){
                    array_push($list['count5'],0);
                }else{
                    array_push($list['count5'],count($res5['sum'][$v]));
                }
                if(!isset($res6['sum'][$v])){
                    array_push($list['count6'],0);
                }else{
                    array_push($list['count6'],count($res6['sum'][$v]));
                }
            }
        }else{
            $list=[
                'count'=>[],
                'people'=>[],
                'share'=>[]
            ];
            $res1=$this->getSends($time,$area,[]);
            foreach ($time as $k=>$v){
                if(!isset($res1['sum'][$v])){
                    array_push($list['count'],0);
                }else{
                    array_push($list['count'],count($res1['sum'][$v]));
                }
                if(!isset($res1['people'][$v])){
                    array_push($list['people'],0);
                }else{
                    array_push($list['people'],count($res1['people'][$v]));
                }
                if(!isset($res1['share'][$v])){
                    array_push($list['share'],0);
                }else{
                    array_push($list['share'],array_sum($res1['share'][$v]));
                }
            }
        }
        $list['time']=$time;
        successReturn(200,'',$list);
    }
}
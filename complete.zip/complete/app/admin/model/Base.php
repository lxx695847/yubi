<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/8/6 0006
 * Time: 16:42
 */

namespace app\admin\model;
use think\Model;

class Base extends Model{

}
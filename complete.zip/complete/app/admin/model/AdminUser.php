<?php
/**
 * Created by PhpStorm.
 * User: GG
 * Date: 2018/6/26
 * Time: 17:15
 */
namespace app\admin\model;

class AdminUser extends Base {
    /**
     * 查询用户
     * @param  $name
     * @param  $pwd
     * @return boolean
     */
    public static function findUser($name, $pwd){
        $where['user']=$name;
        $res=db('user')->where($where)->find();
        if($res!=false){
            if($res['status']==2){
                $data=pwdAct(2,$pwd,$res['pwd']);
                if($data!==false){
                    return $res;
                }else{
                    return 1002;
                }
            }else{
                return 1001;
            }
        }else{
            return 1003;
        }
    }

    /**
     * 根据id更新用户登录时间
     * @check  $id
     * @return boolean
     */
    public static function updateLoginTime($id){
        $where['id']=$id;
        $saveData['login_time']=date('Y-m-d H:i:s');
        return db('user')->where($where)->update($saveData);
    }
}
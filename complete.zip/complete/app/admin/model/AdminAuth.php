<?php
/**
 * Created by PhpStorm.
 * User: GG
 * Date: 2018/6/26
 * Time: 10:40
 */
namespace app\admin\model;

class AdminAuth extends Base
{
    /**
     * 获取用户所有权限
     * @check $user_id
     * @return string
     */
    public static function getUserRules($user_id)
    {
        $where['a.uid']=$user_id;
        //根据用户id获取权限规则
        $rules = db('auth_group_access')->alias('a')
            ->join('auth_group c','c.id=a.group_id','LEFT')   //默认为inner
            ->field('c.rules')
            ->where($where)
            ->find();
        if($rules!==false){
            $menu = self::getMenus($rules['rules']);
            //根据规则id递归菜单栏目
            return  get_column($menu);
        }
    }

    /**
     * 根据规则id数组获取菜单
     * @check  $rules_arr
     * @return array
     */
    public static function getMenus($rules_arr)
    {
        $where = array(
            'id' => array('in', $rules_arr),
            'status' => 1,
            'is_menu'=>2
        );
        return db('auth_rule')->where($where)->order('sort asc')->select();
    }
}
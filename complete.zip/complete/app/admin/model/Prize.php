<?php
namespace app\admin\model;


class prize extends Base{
    /**
     * 奖励领取
     */
    public function get_total($page,$limit,$search){
        $opt=[
            'a.model'=>2,
            'c.kind' => [['neq',3],['neq',4],'and']
        ];

        if($search!=false) {
            $search = json_decode($search,true);
            if (isset($search['phone']) && $search['phone']!=false) {
                $opt['b.phone'] = ['like', "%" . $search['phone'] . "%"];
            }
            if (isset($search['kind']) && $search['kind']!=false) {
                $opt['c.kind'] = $search['kind'];
            }
            if (isset($search['area']) && $search['area']!=false) {
                $opt['c.area'] = $search['area'];
            }
        }

        $record=db('index_lottery');
        $rows=$record->alias('a')
            ->field('a.*,b.phone,b.email,d.address,c.title,c.kind')
            ->join('login b','a.uid=b.id')
            ->join('switch_goods c','a.pid=c.id')
            ->join('info d','a.uid=d.uid')
            ->order('a.receive_time desc')
            ->page($page,$limit)
            ->where($opt)
            ->select();
        foreach ($rows as $k=>$v){
            if($v['address']){
                $tom=json_decode($v['address'],true);
                $rows[$k]['address']=$tom['province'].$tom['city'].$tom['area'].$tom['address'];
                $rows[$k]['extra']=$tom['name']." / ".$tom['phone'];
            }else{
                $rows[$k]['address']='';
                $rows[$k]['extra']='';
            }
        }

        $row['list']=$rows;
        $row['count']=$record->alias('a')
            ->join('login b','a.uid=b.id')
            ->join('switch_goods c','a.pid=c.id')
            ->join('info d','a.uid=d.uid')
            ->where($opt)
            ->count();
        return $row;
    }

    public function get_totals($search=[]){
        $opt=[
            'a.model'=>2,
            'c.kind' => [['neq',3],['neq',4],'and']
        ];

        if($search!=false) {
            if (isset($search['phone']) && $search['phone']!=false) {
                $opt['b.phone'] = ['like', "%" . $search['phone'] . "%"];
            }
            if (isset($search['kind']) && $search['kind']!=false) {
                $opt['c.kind'] = $search['kind'];
            }
            if (isset($search['area']) && $search['area']!=false) {
                $opt['c.area'] = $search['area'];
            }
        }

        $record=db('index_lottery');
        $rows=$record->alias('a')
            ->field('a.id,b.email,b.phone,c.title,a.area,c.kind,a.idCard,a.receive_time,d.address')
            ->join('login b','a.uid=b.id')
            ->join('switch_goods c','a.pid=c.id')
            ->join('info d','a.uid=d.id')
            ->order('a.receive_time desc')
            ->where($opt)
            ->select();
        foreach ($rows as $k=>$v){
            if($v['address']){
                $tom=json_decode($v['address'],true);
                $rows[$k]['address']=$tom['province'].$tom['city'].$tom['area'].$tom['address'];
                $rows[$k]['extra']=$tom['name']." / ".$tom['phone'];
            }else{
                $rows[$k]['address']='暂未填写';
                $rows[$k]['extra']='暂未填写';
            }

            $rows[$k]['email']= $v['email'] ? $v['email'] : '暂未绑定';
            $rows[$k]['receive_time']=date('Y-m-d H:i:s',$v['receive_time']);
            $rows[$k]['area']= $v['area']==1 ? '普通补给' : '精英补给';
            switch($v['kind']){
                case 1:
                    $rows[$k]['kind']='实物';
                    break;
                case 2:
                    $rows[$k]['kind']='虚拟折扣券';
                    break;
                case 5:
                    $rows[$k]['kind']='代币&游戏';
                    break;
            }
            $rows[$k]['idCard']= $v['idCard'] ? $v['idCard'] : '无';
        }
        return $rows;
    }

    /**
     * 分享记录
     */
    public function share_total($page,$limit,$search){
        $opt['a.id']=['gt',0];
        $row=[];
        if($search!=false) {
            $search = json_decode($search,true);
            if (isset($search['phone'])) {
                $opt['b.phone'] = ['like', "%" . $search['phone'] . "%"];
            }
            if (isset($search['version'])) {
                $opt['a.version'] = ['like', "%" . $search['version'] . "%"];
            }
        }
        $record=db('index_puzzle');

        $row['list']=$record->alias('a')
            ->field('a.*,b.phone')
            ->join('login b','a.uid=b.id')
            ->page($page,$limit)
            ->where($opt)
            ->select();
        $use_time = array_column($row['list'],'use_time');
        $step = array_column($row['list'],'step');
        array_multisort($use_time ,SORT_ASC,$step,SORT_ASC,$row['list']);
        $row['count']=$record->alias('a')
            ->join('login b','a.uid=b.id')
            ->where($opt)
            ->count();
        return $row;
    }

    /**
     * 分享记录
     */
    public function share_totals($search=[]){
        $opt['a.id']=['gt',0];
        if($search!=false) {
            if (isset($search['phone'])) {
                $opt['b.phone'] = ['like', "%" . $search['phone'] . "%"];
            }
            if (isset($search['version'])) {
                $opt['a.version'] = ['like', "%" . $search['version'] . "%"];
            }
        }
        $record=db('index_puzzle');

        return $record->alias('a')
            ->field('a.id,b.phone,a.use_time,a.step,a.version,a.complete_time,a.is_share')
            ->join('login b','a.uid=b.id')
            ->order("a.use_time desc,a.step desc")
            ->where($opt)
            ->select();
    }

    /**
     * 后台操作
     */
    public function system_act($page,$limit,$search){
        $admin=db('admin_act');
        $opt['a.area']=1;
        if($search!=false) {
            $search = json_decode($search,true);
            if (isset($search['user']) && $search['user']!=false) {
                $opt['b.user'] = ['like', "%" . $search['user'] . "%"];
            }
            if(isset($search['edit']) && $search['edit']!=false){
                $arr=explode('~',$search['edit']);
                $end1=(int)strtotime($arr[1])+86400;
                $opt['a.edit_time'] = [['>=',strtotime($arr[0])],['<',$end1],'and'];
            }
        }
        $row['list']=$admin->alias('a')
            ->field('a.*,b.user')
            ->join('user b','a.aid=b.id')
            ->order('a.edit_time desc')
            ->page($page,$limit)
            ->where($opt)
            ->select();
        $row['count']=$admin->alias('a')
            ->join('user b','a.aid=b.id')
            ->where($opt)
            ->count();
        return $row;
    }
}
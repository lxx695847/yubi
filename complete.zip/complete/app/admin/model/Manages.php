<?php
/**
 * Created by PhpStorm.
 * User: GG
 * Date: 2018/7/13
 * Time: 15:58
 */
namespace app\admin\model;

class Manages extends Base {
    /**
     * 获取用户
     * @check page
     * @check order
     * @return array
     */
    public function getCustomer($page,$limit,$search){
        $opt['a.id']=['>',0];
        if($search!=false) {
            $search = json_decode($search, true);
            if (isset($search['phone']) && $search['phone']!=false) {
                $opt['a.phone'] = ['like', "%" . $search['phone'] . "%"];
            }
            if(isset($search['status']) && $search['status']!=false){
                $opt['a.status'] = $search['status'];
            }
            if(isset($search['id']) && $search['id']!=false){
                $opt['a.id'] = $search['id'];
            }
            if(isset($search['ip']) && $search['ip']!=false){
                $opt['a.ip'] = ['like', "%" . $search['ip'] . "%"];
            }
            if(isset($search['blind']) && $search['blind']!=false){
                $opt['b.blind'] = $search['blind'];
            }
            if(isset($search['open']) && $search['open']!=false){
                if($search['open']==2){
                    $opt['a.nickName'] = ['neq','新晋玩家'];
                } else{
                    $opt['a.nickName'] = ['eq','新晋玩家'];
                }
            }
            if(isset($search['register']) && $search['register']!=false){
                $arr=explode('~',$search['register']);
                $end1=(int)strtotime($arr[1])+86400;
                $opt['a.registerTime'] = [['>=',strtotime($arr[0])],['<',$end1],'and'];
            }
        }

        $login=db('login');
        $row['list']=$login->alias('a')
            ->field('a.*,b.coin,b.bullion,b.blind')
            ->join('info b','a.id=b.uid')
            ->order('a.registerTime desc')
            ->page($page,$limit)
            ->where($opt)
            ->select();
        $row['count']=$login
            ->alias('a')
            ->join('info b','a.id=b.uid')
            ->where($opt)
            ->count();
        return $row;
    }


    /**
     * 详情首页
     */
    public function get_shares($uid){
        $lottery=db('index_lottery');
        $card=db('index_card');
        $puzzle=db('index_puzzle');
        $list['info']=db('login')->alias('a')->field('a.*,b.coin,b.bullion')
            ->join('info as b','a.id=b.uid')
            ->where(['a.id'=>$uid])
            ->find();
        $opt['uid']=$uid;
        for ($i=0;$i<8;$i++){
            $opt['version']=$i+1;
            $list['puzzle'][$i]['step']=$puzzle->where($opt)->min('step');
            $list['puzzle'][$i]['score']=$puzzle->where($opt)->min('use_time');
        }
        $opt1['uid']=$uid;
        $list['card']=$card->where($opt1)->count();
        $list['share']['card']=$card->where($opt1)->sum('share');
        $list['share']['puzzle']=$puzzle->where($opt1)->count();
        $list['game']['common']=$lottery->where(['model'=>2,'area'=>1,'uid'=>$uid])->count();
        $list['game']['higher']=$lottery->where(['model'=>2,'area'=>2,'uid'=>$uid])->count();
        return $list;
    }


    public function userALL($uid){
                $opt['uid']=$uid;
                $lottery=db('index_lottery');
                $rows=$lottery->where($opt)->select();
                $dom=[];$obj="";
                foreach ($rows as $k=>$v){
                    switch ($v['model']){
                        case 1:
                            $obj="task_list";
                            break;
                        case 2:
                            $obj="switch_goods";
                            break;
                        case 3:
                            $obj="milestone";
                            break;
                    }
                    $base=db($obj)->field('worth,kind')->where(['id'=>$v['pid']])->find();
                    $dom[$k]=$v;
                    if($v['model']!=2){
                        if($base['kind']==3 || $base['kind']==4){
                            $dom[$k]['worth']="+".$base['worth'];
                            $dom[$k]['kind']=$base['kind'];
                            $dom[$k]['output']=1;
                        }
                    }else{
                        $regular=db('system')->where(['id'=>1])->find();
                        if($v['area']==1){
                            $dom[$k]['worth']="-".$regular['game_coin'];
                            $dom[$k]['kind']=3;
                        }else{
                            $dom[$k]['worth']="-".$regular['game_bullion'];
                            $dom[$k]['kind']=4;
                        }
                        $dom[$k]['output']=2;
                    }
                }
                return ['list'=>$dom, 'count'=>count($dom)];
    }


    /**
     * 日志
     */
    public function writeLog($model,$aid,$detail){
        $send=[
            'aid'=>$aid,
            'model'=>$model,
            'detail'=>$detail,
            'edit_time'=>time()
        ];
        db('admin_act')->insert($send);
    }


    /**
     * 前台操作
     */
    public function system_act($uid,$page,$limit){
        $admin=db('admin_act');
        $row['list']=$admin->alias('a')
            ->field('a.*,b.phone')
            ->join('login b','a.aid=b.id')
            ->order('a.edit_time desc')
            ->page($page,$limit)
            ->where(['a.area'=>2,'a.aid'=>$uid])
            ->select();
        $row['count']=$admin->alias('a')
            ->join('login b','a.aid=b.id')
            ->where(['a.area'=>2,'a.aid'=>$uid])
            ->count();
        return $row;
    }
}
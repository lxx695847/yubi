<?php
namespace app\admin\controller;
use think\Hook;
use lib\upload;

class News extends Base{
    public function __construct(){
        parent::__construct();
    }

    public function index(){
        $res=model('admin/Message')->getSort();
        return $this->fetch('Article/list',['res'=>$res]);
    }

    public function list_add(){
        try{
            if(request()->isGet()){
                $res=model('admin/Message')->getSort();
                return $this->fetch('Article/list_add',['res'=>$res]);
            }else{
                $param=input('post.');
                $list= model('admin/Message')->getAdd($param);
                $list['status']==2 ?  successReturn(201) : successReturn(405,$list['info']);
            }
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }

    public function list_edit(){
        try{
            if(request()->isGet()){
                $id=input('get.id');
                Hook::exec('app\\api\\behavior\\Check','run',$id);
                $list= model('admin/Message')->getSingle($id);
                return $this->fetch('Article/list_edit',['list'=>$list]);
            }else{
                $param=input('post.');
                $list= model('admin/Message')->getEdit($param);
                switch ($list['status']){
                    case 1:
                        errorReturn(405,$list['info']);
                        break;
                    case 2:
                        successReturn(202);
                        break;
                    case 3:
                        successReturn(206,'暂无内容更新');
                        break;
                }
            }
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }

    /**
     * 获取列表数据
     */
    public function getList(){
        try{
            $param=input("get.");
            $search=input("get.search");
            $res=model('admin/Message')->listData($param['page'],$param['limit'],$search);
            layui_table($res);
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }

    /**
     * 批量标签
     */
    public function takeSign(){
        try{
            $param=input('post.');
            $list= model('admin/Message')->editSign($param);
            $list ?  successReturn(202) : errorReturn(405);
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }

    /**
     * 删除
     * @method post
     * @param type(1为批量删除,2为单删)
     * @param area(1为资讯,2为研招,3为简章,4为访谈)
     * @param id
     */
    public function del(){
        try{
            $param=input('post.');
            $list= model('admin/Message')->getDel($param);
            $list ?  successReturn(203) : errorReturn(405);
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }

    /**
     * 添加图片
     */
    public function img(){
        try{
            (new upload())->get_upload();
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }

    /**
     * 编辑器添加图片
     */
    public function other_img(){
        try{
            (new upload())->get_uploads();
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }

}
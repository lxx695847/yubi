<?php
namespace app\admin\controller;
use think\Hook;
use app\admin\validate\Add;
use app\admin\validate\Common;

class Award extends Base{
    public function __construct(){
        parent::__construct();
    }

    public function index(){
        return $this->fetch('Award/index');
    }

    public function mileStone(){
        return $this->fetch('Award/mileStone');
    }

    public function task(){
        return $this->fetch('Award/task');
    }

    public function getMiles(){
        try{
            $param=input("get.");
            $res=model('admin/Spoil')->milesData($param['page'],$param['limit']);
            layui_table($res);
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }

    public function mileEdit(){
        try{
            if(request()->isGet()){
                $id=input('get.id');
                Hook::exec('app\\api\\behavior\\Check','run',$id);
                $list= model('admin/Spoil')->setSingle($id);
                return $this->fetch('Award/mileEdit',['list'=>$list]);
            }else{
                $param=input('post.');
                $res=(new Add())->goCheck('edit',$param);
                if($res===true) {
                    $list = model('admin/Spoil')->milesEdit($param);
                    switch ($list['status']){
                        case 2:
                            successReturn(202);
                            break;
                        case 3:
                            successReturn(206,'暂无内容更新');
                            break;
                    }
                }
            }
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }

    public function getList(){
        try{
            $param=input("get.");
            $search=input("get.search");
            $res=model('admin/Spoil')->lists($param['page'],$param['limit'],$search);
            layui_table($res);
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }

    public function getTask(){
        try{
            $param=input("get.");
            $search=input("get.search");
            $res=model('admin/Spoil')->task_list($param['page'],$param['limit'],$search);
            layui_table($res);
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }

    public function getDel(){
        try{
            $param=input('post.');
            $tag=[$param['type'],$param['id']];
            Hook::exec('app\\api\\behavior\\Check','run',$tag);
            model('admin/Spoil')->getDel($param);
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }

    public function list_add(){
        try{
            if(request()->isGet()){
                return $this->fetch('Award/list_add');
            }else{
                $param=input('post.');
                $res=(new Add())->goCheck('add',$param);
                if($res===true) {
                   model('admin/Spoil')->getAdd($param);
                }
            }
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }

    public function list_edit(){
        try{
            if(request()->isGet()){
                $id=input('get.id');
                Hook::exec('app\\api\\behavior\\Check','run',$id);
                $list= model('admin/Spoil')->getSingle($id);
                return $this->fetch('Award/list_edit',['list'=>$list]);
            }else{
                $param=input('post.');
                $res=(new Add())->goCheck('add',$param);
                if($res===true) {
                    $list = model('admin/Spoil')->getEdit($param);
                    switch ($list['status']){
                        case 1:
                            errorReturn(405,$list['info']);
                            break;
                        case 2:
                            successReturn(202);
                            break;
                        case 3:
                            successReturn(206,'暂无内容更新');
                            break;
                    }
                }
            }
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }

    public function task_edit(){
        try{
            if(request()->isGet()){
                $id=input('get.id');
                Hook::exec('app\\api\\behavior\\Check','run',$id);
                $list= model('admin/Spoil')->taskSingle($id);
                return $this->fetch('Award/taskEdit',['list'=>$list]);
            }else{
                $param=input('post.');
                $res=(new Add())->goCheck('edit',$param);
                if($res===true) {
                    $list = model('admin/Spoil')->taskEdit($param);
                    switch ($list['status']){
                        case 2:
                            successReturn(202);
                            break;
                        case 3:
                            successReturn(206,'暂无内容更新');
                            break;
                    }
                }
            }
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }

    public function award_rule(){
        try{
            if(request()->isGet()){
                $rule=db('system')->field('common_start,higher_start,game_coin,game_bullion')->where(['id'=>1])->find();
                $common=explode("@",$rule['common_start']);
                $higher=explode("@",$rule['higher_start']);
                $rule['common_start']=date('Y-m-d',$common[0]) . "--" . date('Y-m-d',$common[1]);
                $rule['higher_start']=date('Y-m-d',$higher[0]) . "--" . date('Y-m-d',$higher[1]);
                successReturn(200,'',$rule);
            }else{
                $param=input('post.');
                $res=(new Common())->goCheck('game',$param);
                if($res===true) {
                     model('admin/Spoil')->gameBase($param);
                }
            }
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }

    //商品模拟
    public function award_simulate(){
        $area=input('param.area');
        $count=input('param.count');
        $max=[];$kom=[];
        $lottery=db('switch_goods');
        $opt=[
            'area'=>$area,
            'count'=>['gt',0], //剩余库存
            'dayCount'=>['gt',0]   //今日余额
        ];
        $list=$lottery->where($opt)->field('title,weight')->select();
        if($list){
            for ($i=0;$i<$count;$i++){
                array_push($max,$this->getGoods($list));
            }
            foreach($max as $k=>$v){
                $kom[$v['title']][]=$max[$k];
            }

            $send=[];
            foreach ($kom as $k=>$v){
                array_push($send,[
                    'title'=>$k,
                    'count'=>count($kom[$k])
                ]);
            }
            successReturn(200,'',$send);
        }else{
            errorReturn(1020,'奖品已抽取完毕');
        }
    }

    public function getGoods($row){
        $sum=10000;
        $win=[];
        //奖池商品等级
        for($i=0;$i<count($row);$i++){
            for ($g = 0; $g < floor($sum * $row[$i]['weight']); $g++) {
                array_push($win,$i);
            }
        }
        $leave=$sum-count($win);
        if($leave>0){
            for($k=0;$k<$leave;$k++){
                array_push($win,'-1');
            }
        }
        shuffle($win);
        $ins = mt_rand(0,count($win)-1);
        if($win[$ins]!='-1'){
            return $row[$win[$ins]];
        }else{
            return ['title'=>'未中奖'];
        }
    }

    public function getSorts(){
        try{
            $sort=input('get.sort');
            $res=model('admin/Spoil')->sendSorts($sort);
            successReturn(200,'',$res);
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }

    public function setWeight(){
        try{
            $param=input('post.');
            $goods=db('switch_goods');
            $data=json_decode($param['row'],true);
            foreach($data as $k=>$v){
                $goods->where(['area'=>$param['sort'],'id'=>$v['id']])->update($v);
            }
            successReturn(202);
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }
}
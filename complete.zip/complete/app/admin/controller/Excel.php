<?php
/**
 * Created by PhpStorm.
 * User: GG
 * Date: 2019/7/11
 * Time: 9:45
 */

namespace app\admin\controller;
use think\Controller;
use lib\upload;

class Excel extends Controller{
    /**
     * 数据导出
     */
  public function export(){
        $xlsData = db('user')->select();
        Vendor('PHPExcel.PHPExcel');//调用类库,路径是基于vendor文件夹的
        Vendor('PHPExcel.PHPExcel.Worksheet.Drawing');
        Vendor('PHPExcel.PHPExcel.Writer.Excel2007');
        $objExcel = new \PHPExcel();
        $objExcel->setActiveSheetIndex(0);

        $letter =["A","B","C","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T"];
        $arrHeader = array('ID','姓名','性别');
        //填充表头信息
        for($i = 0; $i < count($arrHeader); $i++) {
            $objExcel->setActiveSheetIndex(0)->setCellValue("$letter[$i]1","$arrHeader[$i]");
        };
        $objActSheet = $objExcel->getActiveSheet();

        //填充表格信息
        foreach($xlsData as $k=>$v){
            $objActSheet->setCellValue('A'.($k+2),$v['id']);
            $objActSheet->setCellValue('B'.($k+2), $v['user_name']);
            $objActSheet->setCellValue('C'.($k+2), $v['sex']);
        }

        $objActSheet->setTitle('学生信息');

        $objActSheet->getDefaultRowDimension()->setRowHeight(30);  //行高
        // 设置水平居中
        $objActSheet->getStyle("A1:".$letter[count($arrHeader)-1]."1")->getAlignment()->setHorizontal('center');
        // 设置垂直居中
        $objActSheet->getStyle("A1:".$letter[count($arrHeader)-1].count($xlsData))->getAlignment()->setVertical('center');

        //保存的表格
        $outfile = "学生信息.xls";
        //9.设置浏览器窗口下载表格
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header('Content-Disposition:inline;filename="'.$outfile.'"');
        //生成excel文件
        $objWriter = \PHPExcel_IOFactory::createWriter($objExcel, 'Excel5');
        //下载文件在浏览器窗口
        $objWriter->save('php://output');
        exit;
    }

    /**
     * 数据导入
     */
  public function import(){
        $upload=new upload();
        $file=$upload->get_upload($_FILES,'excel');
        if($file['status']==1){
            ajaxError(500,$file['info']);
        }else{
            vendor("PHPExcel.PHPExcel");
            $objReader=new \PHPExcel_Reader_Excel5();
            $objPHPExcel = $objReader->load($file['info']);//获取excel文件
            $sheet = $objPHPExcel->getSheet(0); //激活当前的表
            $highestRow = $sheet->getHighestRow(); // 取得总行数
            $highestColumn = $sheet->getHighestColumn(); // 取得总列数
//            $data=$sheet->toArray();
            $letter =["A","B","C","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T"];

            $data=[];
            //转成数组(去除表头)
            for($i=0;$i<$highestRow;$i++) {
                for($j=2;$j<$highestColumn;$j++){
                    $data[$i][] = $objPHPExcel->getActiveSheet()->getCell($letter.$j)->getValue();//姓名
                }
            }
        }
    }
}
<?php
namespace app\admin\controller;
use think\Hook;

class Check extends Base{
    public function index(){
        return view('Check/index');
    }

    public function group(){
        return view('Check/group');
    }

    public function authCheck(){
        $type=1;
        Hook::exec('app\\admin\\behavior\\Auths','run',$type);
        return view('Check/authCheck');
    }

    public function getManager(){
        try{
            $page=input("get.page");
            $limit=input("get.limit");
            $res=model('admin/Examine')->manager($page, $limit);
            layui_table($res);
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }

    public function editStatus(){
        try{
            $uid=input("get.uid");
            $range=input("get.range");
            $act=input("get.act");
            $tag=[$uid,$range,$act];
            Hook::exec('app\\api\\behavior\\Check','run',$tag);
            $res=model('admin/Examine')->getStatus($uid,$range,$act);
            check($res,2);
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }

    public function getGroup(){
        try{
            $page=input("get.page");
            $limit=input("get.limit");
            $res=model('admin/Examine')->groups($page, $limit);
            layui_table($res);
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }

    public function editRule(){
        $choose=input("post.choose");
        $id=input("post.id");
        $tag=[$choose,$id];
        Hook::exec('app\\api\\behavior\\Check','run',$tag);
        $res=db('auth_group')->where(['id'=>$id])->setField('rules',$choose);
        model('admin/Manages')->writeLog('权限管理',session('user_info')['id'],'权限规则修改');
        check($res,2);
    }

    public function getData(){
        try{
            $group_id=input("get.id");
            Hook::exec('app\\api\\behavior\\Check','run',$group_id);
            $res=model('admin/Examine')->watch_auth($group_id);
            layui_table($res);
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }

    public function system_edit(){
        if(request()->isGet()){
            $id=input('get.id');
            Hook::exec('app\\api\\behavior\\Check','run',$id);
            $list= model('admin/Examine')->setSingle($id);
            return $this->fetch('Check/user_edit',['list'=>$list['row'],'sort'=>$list['sort']]);
        }else{
            $param=input('post.');
            $tag=[$param['id'],$param['pwd']];
            Hook::exec('app\\api\\behavior\\Check','run',$tag);
            $res=db('user')->where(['id'=>$param['id']])->setField('pwd',pwdAct(1,$param['pwd']));

            $access=db('auth_group_access');
            if($param['oid']!=$param['gid']){
                $new1=[
                   'uid'=>$param['id'],
                    'group_id'=>$param['oid']
                ];
                $access->where($new1)->delete();
                $new2=[
                    'uid'=>$param['id'],
                    'group_id'=>$param['gid']
                ];
                $access->insert($new2);
            }
            model('admin/Manages')->writeLog('权限管理',session('user_info')['id'],'管理员密码管理');
            check($res,2);
        }
    }

    public function group_add(){
        $title=input('post.title');
        $res=db('auth_group')->insert(['title'=>trim($title)]);
        check($res,1);
    }

    public function system_add(){
        if(request()->isGet()){
            $opt['base']=['neq',2];
            $sort=db('auth_group')->field('id,title')->where($opt)->select();
            return $this->fetch('Check/user_add',['sort'=>$sort]);
        }else{
            $param=input('post.');
            $info=[
                'user'=>$param['user'],
                'pwd'=>pwdAct(1,$param['pwd']),
                'register'=>time(),
                'pic'=>'icon/user.png',
                'name'=>'hello',
                'is_act'=>2
            ];
            $id=db('user')->insertGetId($info);
            $access=db('auth_group_access');
            $new2=[
                    'uid'=>$id,
                    'group_id'=>$param['gid']
            ];
            $res=$access->insert($new2);
            check($res,1);
            model('admin/Manages')->writeLog('权限管理',session('user_info')['id'],'管理员新增');
        }
    }
}
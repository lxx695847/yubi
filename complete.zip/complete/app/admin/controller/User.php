<?php
/**
 * Created by PhpStorm.
 * User: GG
 * Date: 2018/7/4
 * Time: 10:05
 */
namespace app\admin\controller;
use think\Hook;

class User extends Base{
    public function __construct(){
        parent::__construct();
    }

    /**
     * 首页
     */
    public function index(){
        return view('User/index');
    }

    public function customer(){
        try{
            $page=input('page');
            $limit=input('limit');
            $search=input('search');
            $list= model('admin/Manages')->getCustomer($page,$limit,$search);
            layui_table($list);
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }

    public function detail(){
        $id=input('get.uid');
        Hook::exec('app\\api\\behavior\\Check','run',$id);
        $res=model('admin/Manages')->get_shares($id);
        return view('User/detail',['res'=>$res]);
    }

    public function sendInfos(){
        $uid=input('param.uid');
        Hook::exec('app\\api\\behavior\\Check','run',$uid);
        $list= model('admin/Manages')->userALL($uid);
        layui_table($list);
    }

    public function getCount(){
        $uid=input('post.uid');
        Hook::exec('app\\api\\behavior\\Check','run',$uid);
        $row= model('admin/Manages')->userALL($uid);
        $ins1=0;$ins2=0;$outs1=0;$outs2=0;
        foreach ($row['list'] as $k=>$v){
            if($v['kind']==3){
                if($v['output']==1){
                    $ins1+=$v['worth'];
                }else{
                    $outs1+=$v['worth'];
                }
            }else{
                if($v['output']==1){
                    $ins2+=$v['worth'];
                }else{
                    $outs2+=$v['worth'];
                }
            }
        }
        $list=[
            'coin'=>[$ins1,$outs1],
            'bullion'=>[$ins2,$outs2]
        ];
        successReturn(200,'',$list);
    }

    /**
     * 前台操作记录
     */
    public function system_record(){
        try{
            $uid=input('param.uid');
            Hook::exec('app\\api\\behavior\\Check','run',$uid);
            $param=input("get.");
            $res=model('admin/Manages')->system_act($uid,$param['page'],$param['limit']);
            layui_table($res);
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }
}
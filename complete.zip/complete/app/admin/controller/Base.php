<?php
/**
 * Created by PhpStorm.
 * User: GG
 * Date: 2018/6/15
 * Time: 16:27
 */
//基类
namespace app\admin\controller;
use think\Controller;
use think\Loader;
use think\Hook;

class Base extends Controller{
    public function __construct(){
        parent::__construct();
        //行为标签
        Hook::exec('app\\admin\\behavior\\Check','run',session('user_info')['id']);
        $this->assign("controller",ucwords(Loader::parseName($this->request->controller())));
    }
}
<?php
namespace app\admin\controller;
use think\Hook;
use app\admin\validate\Add;

class Record extends Base{
    public function __construct(){
        parent::__construct();
    }

    public function award(){
        return view('Record/award');
    }

    public function share(){
        $version=db('system')->where(['id'=>1])->value('version');
        return view('Record/share',['version'=>$version]);
    }

    /**
     * 后台操作记录
     */
    public function act(){
        return view('Record/act');
    }

    /**
     * 领取奖励记录
     */
    public function award_record(){
        try{
            $param=input("get.");
            $res=model('admin/Prize')->get_total($param['page'],$param['limit'],input("get.search"));
            layui_table($res);
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }

    /**
     * 导出表格
     */
    public function award_export(){
        try{
            $res=model('admin/Prize')->get_totals(input("post."));
            successReturn(200,'',$res);
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }

    /**
     * @param $area
     * 游戏排行
     */
    public function share_record(){
        try{
            $param=input("get.");
            $res=model('admin/Prize')->share_total($param['page'],$param['limit'],input("get.search"));
            layui_table($res);
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }

    /**
     * @param $area
     * 游戏排行导出
     */
    public function share_export(){
        try{
            $res=model('admin/Prize')->share_totals(input("post."));
            successReturn(200,'',$res);
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }

    /**
     * 后台操作记录
     */
    public function system_record(){
        try{
            $param=input("get.");
            $res=model('admin/Prize')->system_act($param['page'],$param['limit'],input("get.search"));
            layui_table($res);
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }
}
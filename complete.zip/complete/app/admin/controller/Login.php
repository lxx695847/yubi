<?php
/**
 * Created by PhpStorm.
 * User: GG
 * Date: 2018/6/26
 * Time: 16:22
 */
namespace app\admin\controller;
use app\admin\model\AdminUser as AdminUser;
use app\admin\validate\Logins;
use think\Auth;
use think\captcha\Captcha;

class Login{
    public function login(){
       return view('Login/login');
    }

    /**
     * 登录操作
     */
    public function doLogin(){
        $param=input("post.");
        //验证层验证(场景，数据)
        $res=(new Logins())->goCheck('check',$param);
        if($res===true){
            //查询用户
            $captcha = new Captcha();
            if(!$captcha->check($param['captcha'])){
                errorReturn(501,'请输入正确的验证码');
            }else{
                $user_info =AdminUser::findUser($param['user'], $param['pwd']);
                if($user_info=="1001"){
                    errorReturn($user_info,'用户已被禁用');
                }elseif ($user_info=="1002"){
                    errorReturn($user_info,'账号密码不正确,请确认后重试！');
                }elseif ($user_info=="1003"){
                    errorReturn($user_info,'该用户不存在,如有需求请联系管理员添加');
                } else{
                    //个人信息入session
                    $group=(new Auth())->getGroups($user_info['id']);
                    foreach ($group as $v){
                        $user_info['title']=$v['title'];
//                        $user_info['base']=$v['base'];
                    }
                    session('user_info',$user_info);
                    session('start_time',time());
                    if(session('?user_info')){
                        model('admin/Manages')->writeLog('后台登录',session('user_info')['id'],'登录成功');
                        successReturn('200','',session('user_info'));
                    }else{
                        errorReturn('500','信息缓存失败');
                    }
                }
            }
        }
    }


    /**
     * 退出登录
     */
    public function logout(){
        model('admin/Manages')->writeLog('后台登录',session('user_info')['id'],'退出登录');
        session(null);
        return view('Login/login');
    }
}

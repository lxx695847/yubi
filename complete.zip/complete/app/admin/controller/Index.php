<?php
namespace app\admin\controller;
use think\Hook;

class Index extends Base{
    public function __construct(){
        parent::__construct();
    }

    /**
     * 数据统计
     */
    public function index() {
        return view('Index/index');
    }

    public function getData(){
        $area=input('param.area');
        Hook::exec('app\\api\\behavior\\Check','run',$area);
        $list= model('admin/First')->analyse($area);
        layui_table($list);
    }

    public function getSort(){
        $area=input('param.area');
        Hook::exec('app\\api\\behavior\\Check','run',$area);
        model('admin/First')->show($area);
    }
}

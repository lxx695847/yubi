<?php
/**
 * Created by PhpStorm.
 * User: GG
 * Date: 2018/6/26
 * Time: 14:42
 */
use lib\upload;
/**
 * description: 递归菜单
 * @check $array
 * @check  $fid
 * @check  $level
 * @return array
 */
function get_column($array,$fid=0,$level=0){
    $column = [];
        foreach($array as $key => $vo) {
            if ($vo['pid'] == $fid) {
                $vo['level'] = $level;
                $vo['sub'] = get_column($array, $vo['id'], $level + 1);
                $column[]=$vo;
            }
        }
    return $column;
}

function getTime($type){
    switch ($type){
        case 'day':
            $beginToday=mktime(0,0,0,date('m'),date('d'),date('Y'));
            $endToday=mktime(0,0,0,date('m'),date('d')+1,date('Y'))-1;
            return [$beginToday,$endToday];
            break;
        case 'yesterday':
            $beginYesterday=mktime(0,0,0,date('m'),date('d')-1,date('Y'));
            $endYesterday=mktime(0,0,0,date('m'),date('d'),date('Y'))-1;
            return [$beginYesterday,$endYesterday];
        case 'week':
            $beginWeek = mktime(0,0,0,date("m"),date("d")-date("w")+1,date("Y"));
            $endWeek = mktime(23,59,59,date("m"),date("d")-date("w")+7,date("Y"));
            return [$beginWeek,$endWeek];
        case 'month':
            $beginMonth=mktime(0,0,0,date('m'),1,date('Y'));
            $endMonth=mktime(23,59,59,date('m'),date('t'),date('Y'));
            return [$beginMonth,$endMonth];
    }
}


////获取最近7天的时间日期
//function get_week(){
//    //获取当前周几
//    $date = [];
//    $date[0] = date('Y-m-d', time());
//    for ($i=1; $i<7; $i++){
//        $date[$i] = date('Y-m-d' ,strtotime( '-' . $i .' days', time()));
//    }
//    $row=array_reverse($date);
//    return $row;
//}

<?php
namespace app\admin\behavior;
use org\Auth;

class Auths{
    /**
     * 操作权限
     */
    public function run($type){
        $url=request()->module()."/".request()->controller()."/".request()->action();
        $res=(new Auth())->check($url,session('user_info')['id']);
        if($res===false){
            switch ($type){
                //新增、编辑
                case 1:
                    $pic=scp."images/deny.png";
                    echo "<img src='".$pic."' style='width:30%;margin:100px 35%;'>";
                    exit;
                    break;
                //删除
                case 2:
                    errorReturn(1001,"权限不足,不可操作");
                    break;
            }

        }
    }


}
<?php
/**
 * Created by PhpStorm.
 * User: GG
 * Date: 2019/7/26
 * Time: 15:24
 */

namespace app\admin\behavior;

class Examine{
    public function run(&$params){
        if($params !=false){
            if(is_array($params)){
                foreach ($params as $val){
                    if(!$val){
                        errorReturn(400);
                    }
                }
            }else if(is_string($params)){
                if($params===false){
                    errorReturn(400);
                }
            }else{
                errorReturn(500,"暂不支持该类型的检测");
            }
        }else{
            errorReturn(400);
        }
    }
}
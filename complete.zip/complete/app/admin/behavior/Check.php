<?php
/**
 * Created by PhpStorm.
 * User: GG
 * Date: 2018/7/15
 * Time: 14:42
 */

namespace app\admin\behavior;
use app\admin\model\AdminAuth as AdminAuth;

class Check
{
    use \traits\controller\Jump;//类里面引入jump类

    public function run($params){
        if(!$params) {
            $this->redirect(url('Login/login'));
        }else{
            //过期时间
            if (time() - session('start_time') >=config('session.expire')) {
                session(null);
                $this->error('请重新登录',url('Login/login'));
            }else{
                $menus=AdminAuth::getUserRules($params);
                session('user_menu',$menus);
            }
        }
    }
}
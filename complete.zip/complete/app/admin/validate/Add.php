<?php
/**
 * Created by PhpStorm.
 * User: GG
 * Date: 2018/7/10
 * Time: 15:27
 */
namespace app\admin\validate;

class Add extends Base{
    //定义验证规则
    protected $rule = [
        'title'  =>  'require',
        'kind'   =>  'require',
        'area'  =>  'require',
        'totalCount'  =>  'require|number|gt:0',
        'limitCount'  =>  'require|number|egt:0',
        'sorts'  =>   'require|number|gt:0',
        'worth'  =>   'require|number|gt:0'
    ];

    //定义字段描述信息
    protected $field = [
        'title'  => '商品名称',
        'kind'   => '奖品类型',
        'area'  =>  '归属奖池',
        'totalCount'  => '奖品库存',
        'limitCount' => '每日限额',
        'sorts'  =>  '排序',
        'goal'  =>  '比索节点',
        'worth' =>  '奖励数值'
    ];

    //定义错误提示信息
    protected $message = [
        'title.require'  => '商品名称必须',
        'kind.require'  =>  '奖品类型必须',
        'area.require' =>  '归属奖池必须',
        'totalCount.require'  =>  '奖品库存必须',
        'limitCount.require' =>  '每日限额必须',
        'sorts.require'  => '排序必须',
        'totalCount.number'   =>   '奖品库存必须为数字',
        'limitCount.number'   =>   '每日限额必须为数字',
        'totalCount.gt'   =>   '奖品库存必须为正数',
        'limitCount.egt'   =>   '每日限额必须为正数',
        'sorts.number'   =>   '排序必须为数字',
        'sorts.gt'   =>   '排序必须为正数',
        'worth.require'   =>   '奖励数值必须',
        'worth.number'   =>   '奖励数值必须为数字',
        'worth.gt'   =>   '奖励数值必须为正数'
    ];

    //定义场景
    protected $scene = [
        'add'   =>  ['title','kind','area','totalCount','limitCount'],
        'edit'  =>  ['worth']
    ];
}
<?php
/**
 * Created by PhpStorm.
 * User: GG
 * Date: 2018/6/29
 * Time: 9:42
 */

namespace app\admin\validate;
use think\Validate;

class Base extends Validate
{
    //验证
    public function goCheck($scene="",$data=""){
        if($data===false){
            $data=input('check.');
        }
        if(!$this->scene($scene)->check($data)){
            $mess = ($this->getError());
            errorReturn('500', $mess);
        }else{
            return true;
        }
    }
}
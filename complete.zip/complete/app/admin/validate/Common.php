<?php
/**
 * Created by PhpStorm.
 * User: GG
 * Date: 2018/7/10
 * Time: 15:27
 */
namespace app\admin\validate;


class Common extends Base{
    //定义验证规则
    protected $rule = [
        'name'  =>  'require',
        'tel'   =>  'require|number|length:11',
        'game_coin' => 'require|number|gt:0',
        'game_bullion'=>'require|number|gt:0'
    ];

    //定义字段描述信息
    protected $field = [
        'name'  => '姓名',
        'tel'   => '手机号',
        'game_coin' => '抽奖消耗比索',
        'game_bullion' => '抽奖消耗银条'
    ];

    //定义错误提示信息
    protected $message = [
        'name.require'  => '姓名必须',
        'tel.require'  =>  '手机号必须',
        'game_coin.require'  => '抽奖消耗比索必须',
        'game_coin.number'   =>  '抽奖消耗比索必须为数字',
        'game_coin.gt'   =>   '抽奖消耗比索必须为正数',
        'game_bullion.require'  => '抽奖消耗银条必须',
        'game_bullion.number'   =>  '抽奖消耗银条必须为数字',
        'game_bullion.gt'   =>  '抽奖消耗银条必须为正数'
    ];

    //定义场景
    protected $scene = [
        'base'   =>  ['name','tel'],
        'game'   =>  ['game_coin','game_bullion']
    ];

}
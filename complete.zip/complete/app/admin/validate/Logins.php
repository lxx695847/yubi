<?php
/**
 * Created by PhpStorm.
 * User: GG
 * Date: 2018/6/26
 * Time: 16:51
 */
namespace app\admin\validate;

class Logins extends Base
{
    //定义验证规则
    protected $rule = [
        'user'  =>  'require',
        'pwd'   =>  'require',
        'captcha'  => 'require',
        '__token__' =>  'token'

    //alphaNum  子母和数字
    ];

    //定义字段描述信息
    protected $field = [
        'user'  => '用户名',
        'pwd'   => '密码',
        'require' => '验证码',
        '__token__'  => '令牌！'
    ];

    //定义错误提示信息
    protected $message = [
        'user.require'  => '请输入用户名',
        'pwd.require'  =>  '请输入密码',
        'captcha.require'  =>  '请输入正确的验证码',
        '__token__'  => '非法提交！'
    ];

    //定义场景
    protected $scene = [
        'check'   =>  ['user','pwd','captcha']
    ];

}
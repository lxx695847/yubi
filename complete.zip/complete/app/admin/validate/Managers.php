<?php
/**
 * Created by PhpStorm.
 * User: GG
 * Date: 2018/7/10
 * Time: 15:27
 */

namespace app\admin\validate;


class Managers extends Base
{
    //定义验证规则
    protected $rule = [
        'user_name'  =>  'require',
        'password'   =>  'require',
        'group_id'  =>  'require'
//        '__token__' =>  'token'
    ];

    //定义字段描述信息
    protected $field = [
        'user_name'  => '用户名',
        'password'   => '密码',
        'group_id'  =>  '权限名称'
//        '__token__'  => '令牌！'
    ];

    //定义错误提示信息
    protected $message = [
        'user_name.require'  => '用户名必须',
        'password.require'  =>  '密码必须',
        'group_id.require' =>  '权限必须'
//        '__token__'  => '非法提交！'
    ];

    //定义场景
    protected $scene = [
        'add'   =>  ['user_name','password','group_id']
    ];

}
<?php
/**
 * Created by PhpStorm.
 * User: GG
 * Date: 2018/5/25
 * Time: 16:49
 */
namespace app\admin\widget;
use think\Controller;

class Table extends Controller{
    /**
     * @check $res
     * @check $list(显示的数据)
     * @check $page(分页数据)
     * 获取用户数据列表
     */
    public function getData($res,$list=array(),$page=array()){
        $size="auto";
        $type="text";
        $sort="false";
        $btn=[
            ['class'=>'edit layui-btn-normal','icon'=>'&#xe642;','title'=>'编辑'],
            ['class'=>'del  layui-btn-danger','icon'=>'&#xe640;','title'=>'删除']
        ];

        //设置默认
        foreach ($list['row'] as $k=>$v){
            if(!isset($v['size'])){
                $list['row'][$k]['size']=$size;
            }
        }
        foreach ($list['content'] as $k=>$v){
            if(!isset($v['type'])){
                $list['content'][$k]['type']=$type;
            }
            if(!isset($v['sort'])){
                $list['content'][$k]['sort']=$sort;
            }
        }
        if(!isset($list['btn'])){
            $list['btn']=$btn;
        }else{
            foreach ($list['btn'] as $val){
                array_unshift($btn,$val);   //头部插入
            }
            $list['btn']=$btn;
        }

        return  $this->fetch('Widget/index',['res'=>$res,'list'=>$list,'page'=>$page]);
    }
}

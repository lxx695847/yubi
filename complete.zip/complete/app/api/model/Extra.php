<?php
namespace app\api\model;
use think\Db;
use lib\redis;

class Extra{
    public function myList($area,$info=[]){
        switch ($area){
            case 1:
                $opt['show']=2; $send=[];
                $list=db('task_list')->where($opt)->order('sorts asc')->select();
                if($info){
                    if($list){
                        foreach ($list as $k=>$v){
                            $send[$k]=[
                                'id'=>$v['id'],
                                'title'=>$v['title'],
                                'worth'=>$v['worth'],
                                'kind'=>$v['kind'],
                                'type'=>$v['type'],
                                'sort'=>$v['sort'],
                                'intro'=>$v['intro']
                            ];
                            if($v['ids']){
                                $arr = explode(',', $v['ids']);
                                if (array_search($info['uid'], $arr)!==false) {
                                    $send[$k]['state']=2;
                                } else{
                                    $send[$k]['state']=1;
                                }
                                $send[$k]['sign']=makeSigns([
                                    'uid'=>$info['uid'],
                                    'id'=> $v['id'],
                                    'act'=>'task',
                                    'model'=>1,  //(1为任务，2为抽奖，3为里程碑)
                                    'actToken'=>getToken(2),
                                    'type'=>'sign'
                                ]);
                            }else{
                                $send[$k]['state']=1;
                            }
                        }
                    }
                }
                successReturn(200,'',$send);
                break;

            case 2:
                $regular=db('system')->where(['id'=>1])->value('run_time');
                $detail=db('milestone')->select();
                $rule=json_decode($regular,true)['count'];  //基数
                $send=[];

                if($info){
                    $unlock=0;
                    $unPart=0;
                    foreach ($detail as $k=>$v){
                        $send[$k]=[
                            'id'=>$v['id'],
                            'kind'=>$v['kind'],
                            'expire'=>$v['expire'],
                            'worth'=>$v['worth']
                        ];
                        if($rule>=$v['goal']){
                            $send[$k]['coupon']=$v['coupon'];
                            $send[$k]['links']=$v['links'];
                            $send[$k]['intro']=$v['intro'];
                            $unlock++;
                            $unPart++;
                            $arr = explode(',', $v['ids']);
                            if (array_search($info['uid'], $arr)!==false) {
                                $send[$k]['state']=3;
                            } else{
                                $send[$k]['state']=2;
                            }
                            if($v['half'] && $rule>=$v['half']){
                                $unlock++;
                            }
                        }else{
                            $send[$k]['coupon']='';
                            $send[$k]['intro']='';
                            $send[$k]['state']=1;
                            $send[$k]['links']='';
                        }

                        $send[$k]['sign']=makeSigns([
                            'uid'=>$info['uid'],
                            'id'=> $v['id'],
                            'act'=>'task',
                            'model'=>3,  //(1为任务，2为抽奖，3为里程碑)
                            'actToken'=>getToken(2),
                            'type'=>'sign'
                        ]);
                    }
                }else{
                    $unlock=0;
                    $unPart=0;
                    foreach ($detail as $k=>$v){
                        $send[$k]=[
                            'id'=>$v['id'],
                            'coupon'=>'',
                            'kind'=>$v['kind'],
                            'worth'=>$v['worth'],
                            'expire'=>$v['expire'],
                            'intro'=>'',
                            'links'=>''
                        ];
                        $send[$k]['state']= $rule>=$v['goal'] ? 2 : 1;
                        if($rule>=$v['goal']){
                            $unlock++;
                            $unPart++;
                            if($v['half'] && $rule>=$v['half']){
                                $unlock++;
                            }
                        }
                    }
                }
                $row=[
                    'detail'=>$send,
                    'coinCount'=>($rule%5)!=false ? $rule-($rule%5) : $rule,  //取模运算
                    'unlock'=>$unlock,
                    'unPart'=>$unPart
                ];
                successReturn(200,'',$row);
                break;
        }
    }

    //领取奖励
    public function receiveTask($sign){
            $word="";
            $opt['id']=$sign['id'];
            $task_list="";
            switch ($sign['model']){
                case 1:
                    $task_list=db('task_list');
                    break;
                case 3:
                    $task_list=db('milestone');
                    //过期时间
                    break;
            }
            $list=$task_list->where($opt)->find();
            if($list['ids']!=false){
                $arr = explode(',', $list['ids']);
                if (array_search($sign['uid'], $arr)!==false) {
                    errorReturn(1010,'不可重复领取');
                }
                array_push($arr,$sign['uid']);
                $tom=implode(',',$arr);
            }else{
                $tom=$sign['uid'];
            }
            $data=[
                'uid'=>$sign['uid'], 'pid'=>$sign['id'],
                'receive_time'=>time(), 'model'=>$sign['model']
            ];

            switch ($list['kind']){
                case 3:
                    $word="coin";
                    break;
                case 4:
                    $word="bullion";
                    break;
            }
            Db::startTrans();
            try{
                db('index_lottery')->insert($data);
                db('info')->where(['uid'=>$sign['uid']])->setInc($word,$list['worth']);
                $task_list->where($opt)->setField('ids',$tom);
                // 提交事务
                Db::commit();
                successReturn(202,'更新成功');
            }catch (\Exception $e) {
                // 回滚事务
                Db::rollback();
                errorReturn(405);
            }
    }

    public function awardRecord($info){
        $opt=[
            'a.uid'=>$info['uid'],
            'a.model'=>2
        ];
        $list=db('index_lottery')->alias('a')
            ->field('a.id,a.give,a.receive_time,a.idCard,b.title,b.pic,b.intro,b.kind')
            ->join('switch_goods b','a.pid=b.id')
            ->where($opt)
            ->order('a.receive_time desc')
            ->select();
        result_show($list);
    }

    public function getAddress($info,$detail){
        $res=db('info')->where(['uid'=>$info['uid']])->setField('address',$detail);
        check($res,1);
    }

    public function awardList($info=[]){
        $list=[];
        $tiff=db('switch_goods')
            ->field('id,title,pic,intro,worth,area,kind,show')
            ->order('sorts asc')
            ->select();
        if($tiff){
            if($info){
                $list['pass']=makeSigns([
                    'uid'=>$info['uid'],
                    'act'=>'lottery',
                    'actToken'=>getToken(2),
                    'model'=>2,  //(1为任务，2为抽奖，3为里程碑)
                    'type'=>'pass'
                ]);
            }

            $list['row']=$tiff;
            $regular=db('system')->where(['id'=>1])->find();
            $common=explode('@',$regular['common_start']);
            $common_leave=[$common[0]-time(),$common[1]-time()];
            $higher=explode('@',$regular['higher_start']);
            $higher_leave=[$higher[0]-time(),$higher[1]-time()];
            $list['base']=[
                'coin'=>$regular['game_coin'],
                'bullion'=>$regular['game_bullion']
            ];
           if($common_leave[0]<=0){
               if($common_leave[1]>=0){
                   $list['base']['common']['progress']='start';
               }else{
                   $list['base']['common']['progress']='end';
               }
               $list['base']['common']['start_leave']=0;
           }else{
               $list['base']['common']['start_leave']=$common_leave[0];
               $list['base']['common']['progress']='off';
           }

            if($higher_leave[0]<=0){
                if($higher_leave[1]>=0){
                    $list['base']['higher']['progress']='start';
                }else{
                    $list['base']['higher']['progress']='end';
                }
                $list['base']['higher']['start_leave']=0;
            }else{
                $list['base']['higher']['progress']='off';
                $list['base']['higher']['start_leave']=$higher_leave[0];
            }
            successReturn(200,'',$list);
        }else{
            successReturn(204);
        }
    }

    //原抽奖逻辑
    public function lottery($area,$pass){
        $lottery=db('switch_goods');
        $info=db('info');
        $lots=db('index_lottery');
        $virtual=db('virtual_goods');
        $regular=db('system')->where(['id'=>1])->find();

        $common=explode('@',$regular['common_start']);
        $common_leave=[$common[0]-time(),$common[1]-time()];
        $higher=explode('@',$regular['higher_start']);
        $higher_leave=[$higher[0]-time(),$higher[1]-time()];

        $kom=[];
        $opt=[
            'area'=>$area,
            'count'=>['gt',0], //剩余库存量
            'dayCount'=>['gt',0]   //今日余额
        ];
        $list=$lottery->where($opt)->field('id,count,dayCount,weight,kind,worth')->select();
        if($list){
            $opt1['uid']=$pass['uid'];
            $detail=$info->where($opt1)->field('address,store,material,coin,bullion')->find();
            switch($area){
                case 1:
                    if($common_leave[0]<=0){
                        if($common_leave[1]<0){
                            errorReturn(1012,'普通宝箱活动已结束');
                        }
                    }else{
                        errorReturn(1009,'普通宝箱活动未开始');
                    }

                    if($detail['coin'] < $regular['game_coin']){
                        errorReturn(1010,'可用比索不足');
                    }
                    break;

                case 2:
                    if($higher_leave[0]<=0){
                        if($higher_leave[1]<0){
                            errorReturn(1012,'精英宝箱活动已结束');
                        }
                    }else{
                        errorReturn(1009,'精英宝箱活动未开始');
                    }

                    if($detail['bullion'] < $regular['game_bullion']){
                        errorReturn(1010,'可用银条不足');
                    }
                    break;
            }

            $praise=$this->getGoods($list);    //奖品

            //未中奖
            function getNone($pass,$area,$regular,$address,$lots,$info){
                $opt1['uid']=$pass['uid'];
                $data=[
                    'uid'=>$pass['uid'],
                    'pid'=>0,
                    'receive_time'=>time(),
                    'model'=>$pass['model'],
                    'area'=>$area,
                    'idCard'=>''
                ];
                $lots->insert($data);
                //抽奖扣除
                switch ($area){
                    case 1:
                        $info->where($opt1)->setDec('coin',$regular['game_coin']);
                        break;
                    case 2:
                        $info->where($opt1)->setDec('bullion',$regular['game_bullion']);
                        break;
                }
                $send=[
                    'id'=>'-1',
                    'address'=>$address,
                    'virtual'=>[]
                ];
                successReturn(200,'',$send);
            }

            if($praise){
                $zom=$lottery->where(['id'=>$praise['id']])->field('count,dayCount')->find();
                if($zom['count']<=0){
                    getNone($pass,$area,$regular,$detail['address'],$lots,$info);
                }else{
                    if($zom['dayCount']<=0){
                        getNone($pass,$area,$regular,$detail['address'],$lots,$info);
                    }else{
                        $send=[
                            'id'=>$praise['id'],
                            'address'=>$detail['address']
                        ];
                        //记录
                        $data=[
                            'uid'=>$pass['uid'],
                            'pid'=>$praise['id'],
                            'receive_time'=>time(),
                            'model'=>$pass['model'],
                            'area'=>$area,
                            'idCard'=>''
                        ];
                        if($praise['kind']==1){
                            //实物
                            if($detail['material']==false){
                                $kom['material']=$praise['id'];
                            }else{
                                $new_arr=explode(',',$detail['material']);
                                array_push($new_arr,$praise['id']);
                                $kom['material']=implode(',',$new_arr);
                            }
                            $send['virtual']=[];
                        }else if($praise['kind']==2){
                            //虚拟
                            $dom=['gid'=>$praise['id'], 'charge'=>1];
                            $top=$virtual->where($dom)->field('id,idCard')->select();
                            if($top){
                                $ins = mt_rand(0,count($top)-1);
                                if($detail['store']==false){
                                    $kom['store']=$top[$ins]['id'];
                                }else{
                                    $new_arr=explode(',',$detail['store']);
                                    if (array_search($top[$ins]['id'], $new_arr)!==false) {
                                        errorReturn(1010,'不可重复领取');
                                    }else{
                                        array_push($new_arr,$top[$ins]['id']);
                                        $kom['store']=implode(',',$new_arr);
                                    }
                                }
                                $send['virtual']=$top[$ins];
                                $data['idCard']=$top[$ins]['idCard'];
                                $virtual->where(['id'=>$top[$ins]['id']])->setField('charge',2);  //虚拟已发放
                            }else{
                                getNone($pass,$area,$regular,$detail['address'],$lots,$info);
                            }
                        }else{
                            $send['virtual']=[];
                        }

                        $data['give'] = $praise['kind']==1 ? 1 : 2;
                        $data2=[
                            'count'=> $praise['count']!=false ? $praise['count']-=1 : 0,
                            'dayCount'=> $praise['dayCount']!=false ? $praise['dayCount']-=1 :0
                        ];

                        Db::startTrans();
                        try{
                            $lots->insert($data);
                            $lottery->where(['id'=>$praise['id']])->update($data2);

                            //奖励领取
                            switch ($praise['kind']){
                                case 1:
                                case 2:
                                    $info->where($opt1)->update($kom);
                                    break;
                                case 3:
                                    $info->where($opt1)->setInc('coin',$praise['worth']);
                                    break;
                                case 4:
                                    $info->where($opt1)->setInc('bullion',$praise['worth']);
                                    break;
                            }

                            //抽奖扣除
                            switch ($area){
                                case 1:
                                    $info->where($opt1)->setDec('coin',$regular['game_coin']);
                                    break;
                                case 2:
                                    $info->where($opt1)->setDec('bullion',$regular['game_bullion']);
                                    break;
                            }
                            // 提交事务
                            Db::commit();
                            successReturn(202,'更新成功',$send);
                        }catch (\Exception $e) {
                            // 回滚事务
                            Db::rollback();
                            errorReturn(405,$e->getMessage());
                        }
                    }
                }
            }else{
                //未抽到奖品
                getNone($pass,$area,$regular,$detail['address'],$lots,$info);
            }
        }else{
            errorReturn(1050,'奖品已发放完毕');
        }
    }

    //新抽奖逻辑
    public function lotterys($area,$pass){
        $redis=new redis();
        $count=$redis->lLen("goodSwitch");
        if($count>2000){
            errorReturn(1200,'抽奖人数较多，请稍后再试');
        }else{
            if($count<=1000){
                $redis->push(2,"goodSwitch",$pass['uid']);
            }

            $range=$redis->lRange('goodSwitch',0,$count);
            if(!empty($range)){
                if(in_array($pass['uid'],$range)==false){
                    errorReturn(1200,'抽奖人数较多，请稍后再试');
                }
            }

            $mk=2;
            //内定大奖id
            $id_arr=[
                ['id'=>1,'level'=>8],
                ['id'=>8,'level'=>8],
                ['id'=>4,'level'=>8],
                ['id'=>6,'level'=>8],
                ['id'=>10008,'level'=>7],
                ['id'=>10010,'level'=>6],
                ['id'=>10011,'level'=>5],
                ['id'=>10016,'level'=>5],
                ['id'=>10017,'level'=>4],
                ['id'=>10018,'level'=>3],
                ['id'=>10004,'level'=>2],
                ['id'=>2,'level'=>2],
                ['id'=>10019,'level'=>2],
            ];

            $words="";$val1=0;$val2=0;
            $lottery=db('switch_goods');
            $info=db('info');
            $regular=db('system')->where(['id'=>1])->find();

            $common=explode('@',$regular['common_start']);
            $common_leave=[$common[0]-time(),$common[1]-time()];
            $higher=explode('@',$regular['higher_start']);
            $higher_leave=[$higher[0]-time(),$higher[1]-time()];
            $opt1['uid']=$pass['uid'];

            $detail=$info->where($opt1)->field('address,store,material,coin,bullion')->find();

            //基础条件控制
            switch($area){
                case 1:
                    $words="coin";
                    $val1-=$regular['game_coin'];
                    if($common_leave[0]<=0){
                        if($common_leave[1]<0){
                            $redis->lRem("goodSwitch",$pass['uid'],1);
                            errorReturn(1012,'普通宝箱活动已结束');
                        }
                    }else{
                        $redis->lRem("goodSwitch",$pass['uid'],1);
                        errorReturn(1009,'普通宝箱活动未开始');
                    }

                    if($detail['coin'] < $regular['game_coin']){
                        $redis->lRem("goodSwitch",$pass['uid'],1);
                        errorReturn(1010,'可用比索不足');
                    }
                    break;

                case 2:
                    $words="bullion";
                    $val2-=$regular['game_bullion'];
                    if($higher_leave[0]<=0){
                        if($higher_leave[1]<0){
                            $redis->lRem("goodSwitch",$pass['uid'],1);
                            errorReturn(1012,'精英宝箱活动已结束');
                        }
                    }else{
                        $redis->lRem("goodSwitch",$pass['uid'],1);
                        errorReturn(1009,'精英宝箱活动未开始');
                    }

                    if($detail['bullion'] < $regular['game_bullion']){
                        $redis->lRem("goodSwitch",$pass['uid'],1);
                        errorReturn(1010,'可用银条不足');
                    }
                    break;
            }

            $lots=db('index_lottery');
            $virtual=db('virtual_goods');

            $opt=[
                'area'=>$area,
                'count'=>['gt',0], //剩余库存量
                'dayCount'=>['gt',0],   //今日余额
                'sponsor'=>1
            ];
            $list=$lottery->where($opt)->field('id,count,dayCount,weight,kind,worth,version')->select();

            if($list!=false){
                $praise=$this->getGoods($list);
                if($area==2){
                     $keys=array_search($pass['uid'],array_column($id_arr,'id'));
                     if(is_numeric($keys)){
                         $ops=[
                               'sponsor'=>2,
                               'import'=>$id_arr[$keys]['level'],
                               'area'=>2,
                               'count'=>['gt',0], //剩余库存量
                               'dayCount'=>['gt',0]   //今日余额
                         ];
                         $hits=$lottery->field('id,count,dayCount,weight,kind,worth,version')->where($ops)->find();
                         //每日限额正常
                         if($hits){
                              $dish = [
                                  'uid' => $pass['uid'], 'pid' => $hits['id'],'model'=>2
                              ];
                              $fitId = $lots->where($dish)->value('id');
                                //不可重复领取赞助商品
                              if($fitId==false){
                                  $praise=$hits;
                              }
                         }
                     }
                }

                //开始事务
                Db::startTrans();
                try {
                    //前端数据
                    $kom = [
                        'address' => $detail['address'],
                        'virtual' => []
                    ];
                    //抽奖记录
                    $data = [
                        'uid' => $pass['uid'], 'receive_time' => time(),
                        'model' => $pass['model'], 'area' => $area, 'idCard' => ''
                    ];

                    if (!empty($praise)) {
                        //先减掉库存
                        $opts=[
                            'id' => $praise['id'],
                            'area'=>$area
                        ];
                        list($opt3,$opt4)=[$opts,$opts];
                        $opt3['count']=['gt', 0];
                        $dps1 = $lottery->where($opt3)->setDec('count');
                        $opt4['dayCount']=['gt', 0];
                        $dps2 = $lottery->where($opt4)->setDec('dayCount');

                        if ($dps1 && $dps2) {
                            //乐观锁版本控制 提交
                            $upVersion = $lottery->where($opts)->value('version');
                            if ($upVersion && $praise['version'] == $upVersion) {
                                $kom['id'] = $praise['id'];
                                $data['pid'] = $praise['id'];
                                $data['give'] = $praise['kind'] == 1 ? 1 : 2;
                                //奖励领取
                                switch ($praise['kind']) {
                                    case 1:
                                        //不可重复
                                        $moon = [
                                            'uid' => $pass['uid'], 'pid' => $praise['id'],'model'=>2
                                        ];
                                        $seaId = $lots->where($moon)->value('id');
                                        if ($seaId) {
                                            // 回滚事务
                                            Db::rollback();
                                            $mk = 1;
                                        }
                                        break;

                                    case 2:
                                        //虚拟卡号
                                        $dom = ['gid' => $praise['id'], 'charge' => 1];
                                        $top = $virtual->where($dom)->field('id,idCard,version')->select();
                                        if ($top) {
                                            $ins = mt_rand(0, count($top) - 1);
                                            $virtuals = $top[$ins];
                                            $kom['virtual'] = $virtuals;
                                            $data['idCard'] = $virtuals['idCard'];
                                            $upVer=$virtual->where(['id'=>$virtuals['id']])->value('version');
                                            if($virtuals['version']==$upVer) {
                                                $rom=[
                                                    'charge'=>2,'version'=>$virtuals['version']+1
                                                ];
                                                $virtual->where(['id'=>$virtuals['id']])->update($rom);  //虚拟已发放
                                            }else{
                                                Db::rollback();
                                                $mk = 1;
                                            }
                                        } else {
                                            Db::rollback();
                                            $mk = 1;
                                        }
                                        break;

                                    case 3:
                                        $val1+=$praise['worth'];
                                        break;

                                    case 4:
                                        $val2+=$praise['worth'];
                                        break;

                                    //游戏或代币
                                    case 5:
                                    case 6:
                                        break;
                                }
                            } else {
                                Db::rollback();
                                $mk = 1;
                            }
                        } else {
                            Db::rollback();
                            $mk = 1;
                        }

                        if ($mk == 1) {
                            //程序判定未中奖
                            switch ($area){
                                //普通 (9折券)
                                case 1:
                                    $kom['id']='-1';
                                    $data['pid']=0;
                                    break;

                                //高级(代币)
                                case 2:
                                    $von=['kind'=>6,'import'=>1,'area'=>2,'sponsor'=>1];
                                    $pid=$lottery->where($von)->value('id');
                                    $kom['id'] = $pid;
                                    $data['pid']=$pid;
                                    break;
                            }
                        }else{
                            //版本号加1
                            $lottery->where(['id'=>$praise['id']])->setInc('version');
                        }
                   }else{
                        //概率未中奖商品
                        $kom['id']='-1';
                        $data['pid']=0;
                   }

                   //添加记录
                   $lots->insert($data);

                    //奖励扣除
                   if($val1!=false){
                       $info->where($opt1)->setInc($words, $val1);
                   }

                   if($val2!=false){
                       $info->where($opt1)->setInc($words, $val2);
                   }

                    // 提交事务
                    Db::commit();
                    $redis->lRem("goodSwitch", $pass['uid'], 1);
                    successReturn(202, '更新成功', $kom);
                }catch (\Exception $e) {
                    // 回滚事务
                    Db::rollback();
                    $redis->lRem("goodSwitch", $pass['uid'], 1);
                    errorReturn(405, '更新失败');
                }
            }else{
                errorReturn(1080,'商品已售罄');
            }
        }
    }


    //随机商品
    public function getGoods($row){
        $sum=10000;
        $win=[];
        //奖池商品等级
        for($i=0;$i<count($row);$i++){
            for ($g = 0; $g < floor($sum * $row[$i]['weight']); $g++) {
                array_push($win,$i);
            }
        }
        $leave=$sum-count($win);
        if($leave>0){
            for($k=0;$k<$leave;$k++){
                array_push($win,'-1');
            }
        }
        shuffle($win);
        $ins = mt_rand(0,count($win)-1);
        if($win[$ins]!='-1'){
            return $row[$win[$ins]];
        }else{
            return [];
        }
    }
}
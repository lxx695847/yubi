<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/7/31 0031
 * Time: 15:11
 */
namespace app\api\model;
use think\Hook;
use think\Db;

class Index {
    public function getPuzzle($area,$infos=[],$data=[]){
        $puzzle=db('index_puzzle');
        $regular=db('system')->where(['id'=>1])->find();
        switch ($area){
            case 1:
                $dom=json_decode($regular['dateWeek'],true)['list'][$regular['version']-1];
                $row=[
                    'img'=> $dom['img'],
                    'complete'=>$dom['complete']
                ];
                if($infos){
                    $opt=[
                        'uid'=>$infos['uid'],
                        'version'=>$regular['version']
                    ];
                    $row['grade']=$puzzle->where($opt)->min('use_time');
                }else{
                    $row['grade']=0;
                }
                successReturn(200,'',$row);
                break;

            case 2:
                $leave=(int)(strtotime(date('Y-m-d',time()))+24*3600-1)-time();  //当天剩余时间
                if($leave<=1){
                    cache("photo".$infos['uid'],1,$leave);
                }

                $ipCount=cache("photo".$infos['uid']);
                if($ipCount!=false){
                    if($ipCount>3){
                        errorReturn(1030,'您已多次违规操作，今日已被限！');
                    }
                }else{
                    cache("photo".$infos['uid'],1,$leave);
                }

                $opt=[
                    'uid'=>$infos['uid'],
                    'version'=>$regular['version']
                ];
                $res=$puzzle->where($opt)->find();
                $new=[];

                if(empty($data)){
                    $ipCount++;
                    cache("photo".$infos['uid'],$ipCount,$leave);
                    errorReturn(1010,'参数结构不正确');
                }else{
                    //检验逻辑
                    $old=cache("puzzle".$infos['uid']);
                    if($old==false){
                        $ipCount++;
                        cache("photo".$infos['uid'],$ipCount,$leave);
                        errorReturn(1210,'违规操作');
                    }else{
                        $pk=unserialize($old);  //服务端存储
                        $e=count(array_diff_assoc($pk['sort'],[1,2,3,4,5,6,7,8,""]));//最小步数
                        $step=count($data)-1;  //步数路径图
                        //步数路径
                        if($step>=$e){
                            if(isset($data[0]['elapsed']) && $data[0]['elapsed']!=false){
                                $times=$data[$step]['curIndex']-$data[0]['elapsed'];

                                //时间比对
                                if($times>$step*0.3*1000){
                                    if($res){
                                        if($times < $res['use_time']){ $new['use_time']= $times; }
                                        if($step < $res['step']){  $new['step']= $step; }
                                        $send['sign']=makeSigns([
                                            'uid'=>$infos['uid'],
                                            'id'=> $res['id'],
                                            'act'=>'share',
                                            'model'=>2,  //(1为明信片，2为拼图)
                                            'actToken'=>getToken(2),
                                            'type'=>'sign'
                                        ]);
                                        if(!empty($new)){
                                            $new['complete_time']=time();
                                            $list=$puzzle->where($opt)->update($new);
                                            if($list!==false){
                                                cache("puzzle".$infos['uid'],NULL);
                                                $this->getAuto($infos['uid'],5,$send);
                                            }else{
                                                cache("puzzle".$infos['uid'],NULL);
                                                errorReturn(405);
                                            }
                                        }else{
                                            $this->getAuto($infos['uid'],5,$send);
                                        }
                                    }else{
                                        $data=[
                                            'uid'=>$infos['uid'],
                                            'use_time'=>$times,
                                            'step'=>$step,
                                            'complete_time'=>time(),
                                            'version'=>$regular['version']
                                        ];
                                        $list=$puzzle->insertGetId($data);
                                        if($list!==false){
                                            cache("puzzle".$infos['uid'],NULL);
                                            $send['sign']=makeSigns([
                                                'uid'=>$infos['uid'],
                                                'id'=> $list,
                                                'act'=>'share',
                                                'model'=>2,  //(1为明信片，2为拼图)
                                                'actToken'=>getToken(2),
                                                'type'=>'sign'
                                            ]);
                                            $this->getAuto($infos['uid'],5,$send);
                                        }else{
                                            cache("puzzle".$infos['uid'],NULL);
                                            errorReturn(405);
                                        }
                                    }
                                }else{
                                    $ipCount++;
                                    cache("photo".$infos['uid'],$ipCount,$leave);
                                    errorReturn(1230,'违规操作');
                                }
                            }else{
                                $ipCount++;
                                cache("photo".$infos['uid'],$ipCount,$leave);
                                errorReturn(1250,'违规操作');
                            }
                        }else{
                            $ipCount++;
                            cache("photo".$infos['uid'],$ipCount,$leave);
                            errorReturn(1220,'违规操作');
                        }
                    }
                }
                break;
        }
    }

    public function myRank($info=[]){
        $puzzle=db('index_puzzle');
        $regular=db('system')->where(['id'=>1])->find();
        $version=$regular['version'];

        $ids=[];
        $tiff=$puzzle->alias('a')
            ->field('a.*,b.phone')
            ->join('login b','a.uid=b.id')
            ->where(['a.version'=>$version])
            ->select();

        function getDate($time){
            if($time>=1000){
                $m = floor($time % (1000 *3600) / (1000 * 60));
                $t = floor(($time % (1000 * 60)) / 1000);
                $n = $time-($m*60*1000+$t*1000);
            }else{
                $m=0;
                $t=0;
                $n=$time;
            }

            if ($n>=10 && $n<100){
                $n="0".$n;
            } elseif ($n<10 && $n>0){
                $n="00".$n;
            }
            return $m."分".$t."秒".substr($n,0,2);
        }

        $use_time = array_column($tiff,'use_time');
        $step = array_column($tiff,'step');
        array_multisort($use_time ,SORT_ASC,$step,SORT_ASC,$tiff);

        foreach ($tiff as $k=>$v){
            $tiff[$k]['phone']=str_replace(substr($v['phone'],3,4),'****',$v['phone']);
            $tiff[$k]['use_time']=getDate($v['use_time']);
            array_push($ids,$v['uid']);
        }

        $list['row']=array_slice($tiff,0,10);
        $list['version']=$version;
        $list['weekTime']=json_decode($regular['dateWeek'],true)['list'][$version-1]['date'];
        if(!empty($info)){
            $opt['version']=$version;
            $num=array_search($info['uid'], $ids);
            if($num!==false){
                $list['rank']= $num>=0 ? $num+1 : 0;
            }else{
                $list['rank']=0;
            }
        }
        successReturn(200,'',$list);
    }

    public function myGroup($area,$info=[]){
        $res=[];
        switch ($area){
            case 1:
                $opt=[
                    'uid'=>$info['uid'],
                    'is_access'=>2
                ];
                $res=db('index_group')->where($opt)->find();
                break;

            case 2:
                $tiff=db('system')->field('photo,card,poster,mark')->find();
                $res=[
                    'photo'=>json_decode($tiff['photo'],true)['list'],
                    'card'=>json_decode($tiff['card'],true)['list'],
                    'poster'=>json_decode($tiff['poster'],true)['list'],
                    'mark'=>json_decode($tiff['mark'],true)['list']
                ];
                break;

            case 3:
                $res=db('index_card')->alias('a')
                    ->field('a.complete_time,a.markid,a.title,b.*')
                    ->join('share_rule b','a.rid=b.id')
                    ->where(['a.uid'=>$info['uid']])
                    ->order('a.complete_time desc')
                    ->find();
                break;
        }
        result_show($res);
    }

    public function myCard($result,$info){
        $row=json_decode($result,true);
        if(!empty($row)){
            $opt=[
                'photo'=> $row['photo'],
                'card' => $row['card'],
                'poster' => $row['poster']
            ];
            //结果比对
            $list=db('share_rule')->where($opt)->find();
            if($list){
                $data=[
                    'uid'=>$info['uid'],
                    'rid'=>$list['id'],
                    'complete_time'=>time(),
                    'markid'=>$row['mark'],
                    'title'=>$row['title']
                ];
                //添加记录
                $ins=db('index_card')->insertGetId($data);
                if($ins!==false){
                    $send['sign']=makeSigns([
                        'uid'=>$info['uid'],
                        'id'=> $ins,
                        'act'=>'share',
                        'model'=>1,  //(1为明信片，2为拼图)
                        'actToken'=>getToken(2),
                        'type'=>'sign'
                    ]);
                    $this->getAuto($info['uid'],3,$send);
                }else{
                    errorReturn(405);
                }
            }else{
                errorReturn(1011,'参数数据错误，请检查');
            }
        }else{
            errorReturn(1012,'参数结构错误，请检查');
        }
    }

    public function setState($sign,$title){
        $opt['id']=$sign['id'];
        $puzzle="";$task_id="";$send=[];
        switch ($sign['model']){
            case 1:
                $puzzle=db('index_card');
                $task_id=2;
                break;
            case 2:
                $task_id=4;
                $puzzle=db('index_puzzle');
                break;
        }
        $ins=$puzzle->where($opt)->find();
        if($ins){
            if($ins['is_share']==1){
                $up=[
                    'is_share'=>2,
                    'share'=>$ins['share']+1
                ];
            }else{
                $up=[
                    'share'=>$ins['share']+1
                ];
            }
            $list=$puzzle->where($opt)->update($up);
            if($list!==false){
                $send['imgSrc']=$this->dealImg($sign['uid'],$title,$sign['model'],$sign['id']);
                $this->getAuto($sign['uid'],$task_id,$send);
            }else{
                errorReturn(405);
            }
        }else{
            errorReturn(1020,'违规操作');
        }
    }

    public function dealImg($uid,$title,$type,$id=''){
        $save=time().'.png';
        $root=ROOT_PATH . 'public'.DS.'Uploads'.DS;
        $filename="";
        switch ($type) {
            case 1:
                $info=db('index_card')->alias('a')
                    ->field('a.markid,b.pic')
                    ->join('share_rule b','a.rid=b.id')
                    ->where(['a.id'=>$id])
                    ->find();
                $marks=db('system')->where(['id'=>1])->value('mark');

                $backgroundPath = ROOT_PATH . 'public/Uploads/'.$info['pic'];      //背景图
                $mark=json_decode($marks,true)['list'][$info['markid']-1]['src'];
                $markURL= ROOT_PATH . 'public/Uploads/'.$mark;
                $img =  imagecreatefrompng($backgroundPath);
                $img1 = imagecreatefrompng($markURL);

                list($max_width, $max_height) = getimagesize($backgroundPath);
                $dests = imagecreatetruecolor($max_width, $max_height);
                imagecopy($dests,$img,0,0,0,0,$max_width,$max_height);
                $src_info = getimagesize($markURL);
                imagecopy($dests,$img1,550,800,0,0,$src_info[0],$src_info[1]);

                $font = ROOT_PATH . 'public/2.TTF';  //字体文件(中文找了个系统默认黑体字,不然乱码)
                $size = 20;//字体大小
                $word='card';
                $filename = $root.$word.'/'.$save;
                $rgb = [92, 108, 125];
                //设置字体颜色
                $fontcolor = imagecolorallocate($dests,$rgb[0],$rgb[1],$rgb[2]);

                $length=strlen(trim($title));
                //将ttf文字写到图片中
                if($length<=11){
                    $title1=trim($title);
                    imagettftext($dests, $size, 11.5, 390, 800, $fontcolor, $font, $title1);
                }else{
                    $title1=mb_substr(trim($title),0,11);
                    imagettftext($dests, $size, 11.5, 390, 800, $fontcolor, $font, $title1);
                    $title2=mb_substr(trim($title),11,12);
                    if($length<23){
                        imagettftext($dests, $size, 11.5, 400, 860, $fontcolor, $font, $title2);
                    }else{
                        $title3=mb_substr(trim($title),23);
                        imagettftext($dests, $size, 11.5, 400, 860, $fontcolor, $font,$title2);
                        imagettftext($dests, $size, 11.5, 400, 925, $fontcolor, $font, $title3);
                    }
                }
                $title4='from:'.$uid;
                imagettftext($dests, $size, 10, 580, 1015, $fontcolor, $font, $title4);
                imagepng($dests, $filename);
                break;

            case 2:
                $backgroundPath = ROOT_PATH . 'public/Uploads/game/puzzle.png';      //背景图
                $font = ROOT_PATH . 'public/1.TTF';  //字体文件(中文找了个系统默认黑体字,不然乱码)
                $size = 58;//字体大小
                $rgb = [255, 156, 0];
                $word='puzzle';
                $filename = $root.$word.'/'.$save ;
                $img = imagecreatefrompng($backgroundPath);
                //设置字体颜色
                $fontcolor = imagecolorallocate($img, $rgb[0], $rgb[1], $rgb[2]);
                //将ttf文字写到图片中
                imagettftext($img, $size, 2, 155, 540, $fontcolor, $font, $title);
                imagepng($img, $filename);
                imagedestroy($img);
                break;
        }

        //保存图片到远程服务器
        $path=$filename;
        $url="http://yubi.aju.cn/upload.php";
        $ch = curl_init();
        if (class_exists('CURLFile')) {
            $file = new \CURLFile($path);
            // 禁用"@"上传方法,这样就可以安全的传输"@"开头的参数值
            curl_setopt($ch, CURLOPT_SAFE_UPLOAD, true);
        } else {
            $file = '@'.$path;
        }
        curl_setopt($ch ,CURLOPT_URL , $url);
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
        curl_setopt($ch,CURLOPT_POST,1);
        curl_setopt($ch,CURLOPT_POSTFIELDS,array('file_via_curl' => $file));
        curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);
        curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,false);

        //远端的视频路径
        $result = curl_exec($ch);
        curl_close($ch);
        unlink($filename);   //删除服务端图片文件
        return $result;
    }

    public function autoTask($signs){
        $sign=desSigns($signs);
        Hook::exec('app\\api\\behavior\\Check','checkAccess',$sign);
        $opt['id']=$sign['id'];
        $task_list=db('task_list');
        $list=$task_list->where($opt)->find();
        $word = "";$tip="";$send=[]; $status=1;

        switch ($list['kind']){
            case 3:
                $word = "coin";$tip = "比索";
                break;
            case 4:
                $word = "bullion";$tip = "银条";
                break;
        }
        if($list['ids']!=false){
            $arr = explode(',', $list['ids']);
            if (array_search($sign['uid'], $arr) === false) {
                array_push($arr,$sign['uid']);
                $send=['tip'=>$tip, 'worth'=>$list['worth'], 'title'=>$list['title']];
                $ups=implode(',',$arr);
                $task_list->where($opt)->setField('ids',$ups);
                $status=2;
            }
        }else{
            $ups=$sign['uid'];
            $send=['tip'=>$tip, 'worth'=>$list['worth'], 'title'=>$list['title']];
            $task_list->where($opt)->setField('ids',$ups);
            $status=2;
        }

        Db::startTrans();
        try {
            if($status==2){
                $data = [
                    'uid' => $sign['uid'], 'pid' => $sign['id'],
                    'receive_time' => time(), 'model' => $sign['model']
                ];
                db('index_lottery')->insert($data);
                db('info')->where(['uid' => $sign['uid']])->setInc($word,$list['worth']);
            }
            // 提交事务
            Db::commit();
            return $send;
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            return false;
        }
    }

    public function getAuto($uid,$id,$send){
        //自动领取奖励
        $award=$this->autoTask(makeSigns([
            'uid'=>$uid,
            'id'=> $id,
            'act'=>'task',
            'model'=>1,
            'actToken'=>getToken(2),
            'type'=>'sign'
        ]));
        $send['award']=$award;
        successReturn(201,'',$send);
    }
}
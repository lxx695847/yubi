<?php

namespace app\api\model;
use think\Controller;

class Base extends Controller{

}
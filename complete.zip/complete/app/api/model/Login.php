<?php
namespace app\api\model;
use think\Cache;
use think\Db;

class  Login extends Base{
    /**
     * 手机号登录/注册
     */
    public function login_check($phone,$code){
        $login=db('login');
        $res=$login->where(['phone'=>$phone])->find();
        $codes=cache($phone.'sms');
        if($codes==false){
             errorReturn(1100,'验证码已失效，请重新发送');
        }else{
            if($codes==$code){
                $token=getToken(1);
                if($res==false){
                    //注册
                    $data=[
                        'phone'=>$phone,
                        'registerTime'=>time(),
                        'loginTime'=>time(),
                        'ip'=>getClientIP(),
                        'nickName'=>"新晋玩家",
                        'avatar'=>"http://".$_SERVER['SERVER_NAME']."/Uploads/admin.jpg",
                        'token'=>$token
                    ];

                    $uid=$login->insertGetId($data);
                    if($uid){
                        $access=makeSigns([
                            'token'=>$token,
                            'uid'=>$uid,
                            'oauth'=>'on',
                            'type'=>'access'
                        ]);
                        $list=$login->where(['id'=>$uid])->setField('access',$access);
                        $other['uid']=$uid;
                        db('info')->insert($other);
                        $send=$this->sendDetail(['a.id'=>$uid]);
                        check($list,2,$send);
                    }else{
                        errorReturn(405);
                    }
                }else{
                    if($res['status']==1){
                        errorReturn(1005, "用户状态异常，请联系客服");
                    }else{
                        $data=[
                            'ip'=>getClientIP(),
                            'loginTime'=>time(),
                            'token'=>$token,
                            'access'=>makeSigns([
                                'token'=>$token,
                                'uid'=>$res['id'],
                                'oauth'=>'on',
                                'type'=>'access'
                            ])
                        ];
                        $list= $login->where(['id'=>$res['id']])->update($data);
                        $this->writeLog('用户登录',$res['id'],'页面登录');
                        $send=$this->sendDetail(['a.id'=>$res['id']]);
                        check($list,2,$send);
                    }
                }
            }else{
                errorReturn(1200,'验证码错误，请重新输入');
            }
        }
    }

    /**
     * 微信三方登录
     */
    public function other_check($infos,$phone,$code){
        $login=db('login');
        $opt=['phone'=>$phone];

        $codes=cache($phone.'sms');
        $token=getToken(1);
        if($codes==false){
            errorReturn(1100,'验证码已失效，请重新发送');
        }else{
            if($codes==$code){
                $res=$login->where($opt)->find();
                $detail=Cache::get($infos['openid']);
                if($detail){
                    $deeps=unserialize($detail);
                    if($res==false){
                            //注册
                            $data=[
                                'phone'=>$phone,
                                'registerTime'=>time(),
                                'loginTime'=>time(),
                                'ip'=>getClientIP(),
                                'nickName'=>$deeps['nickname'],
                                'avatar'=>$deeps['headimgurl'],
                                'token'=>$token,
                                'openid'=>$infos['openid']
                            ];
                            $uid=$login->insertGetId($data);
                            if($uid){
                                $access=makeSigns([
                                    'token'=>$token,
                                    'uid'=>$uid,
                                    'oauth'=>'on',
                                    'type'=>'access'
                                ]);
                                $list=$login->where(['id'=>$uid])->setField('access',$access);
                                //用户详细信息
                                $other['uid']=$uid;
                                db('info')->insert($other);
                                $send=$this->sendDetail(['a.id'=>$uid]);
                                check($list,2,$send);
                            }else{
                                errorReturn(405);
                            }

                    }else{
                        if($res['status']==1){
                            errorReturn(1005, "数据异常，后台审核中...");
                        }else{
                            $data=[
                                'ip'=>getClientIP(),
                                'loginTime'=>time(),
                                'token'=>$token,
                                'openid'=>$infos['openid'],
                                'nickName'=>$deeps['nickname'],
                                'avatar'=>$deeps['headimgurl'],
                                'access'=>makeSigns([
                                    'token'=>$token,
                                    'uid'=>$res['id'],
                                    'oauth'=>'on',
                                    'type'=>'access'
                                ])
                            ];
                            $list= $login->where(['id'=>$res['id']])->update($data);
                            $this->writeLog('用户登录',$res['id'],'页面登录');
                            $send=$this->sendDetail(['a.id'=>$res['id']]);
                            check($list,2,$send);
                        }
                    }
                }else{
                    errorReturn(1020,'授权过期，请重新登录');
                }
            }else{
                errorReturn(1200,'验证码错误，请重新输入');
            }
        }
    }


    /**
     * 微信授权信息处理
     */
    public function dealInfo($list){
        if(isset($list['openid'])){
            $opt['openid']=$list['openid'];
            $res=db('login')->where($opt)->find();
            if($res){
                $token=getToken(1);
                $data=[
                    'ip'=>getClientIP(),
                    'loginTime'=>time(),
                    'token'=>$token,
                    'access'=>makeSigns([
                        'token'=>$token,
                        'uid'=>$res['id'],
                        'oauth'=>'on',
                        'type'=>'access'
                    ])
                ];
                db('login')->where(['id'=>$res['id']])->update($data);
                $send['info']=$this->sendDetail(['a.id'=>$res['id']]);
                $send['phone_need']=1;
            }else{
                Cache::set($list['openid'],serialize($list),3600);
                $send=[
                    'phone_need'=>2,
                    'import'=>makeSigns([
                        'type'=>'import',
                        'openid'=>$list['openid'],
                        'act'=>'blind',
                        'actToken'=>getToken(2)
                    ])
                ];
            }
            successReturn(200,'',$send);
        }else{
            errorReturn(1030,'参数信息不正确');
        }
    }

    /**
     * 绑定
     */
    public function setBlind($user_id,$step,$need=''){
        switch ($step){
            case 1:
                $opt['id']=$user_id;
                $base=db('login')->field('phone,access')->where($opt)->find();
                successReturn(200,'',$base);
                break;

            case 2:
                $opt['uid']=$user_id;
                $send=[];
                db('login')->where(['id'=>$user_id])->setField('email',$need);
                $in=db('info')->where($opt)->setField('blind',2);
                if($in){
                    model('api/Index')->getAuto($user_id,6,$send);
                }else{
                    errorReturn(405);
                }
                break;

            case 3:
                $opt['uid']=$user_id;
                $award=json_decode($need,true);
                $info=db('info');
                foreach ($award as $k=>$v){
                    if($v['kind']==1){$word='coin';}
                    else{$word='bullion';}
                    switch ($v['type']){
                        case 1:
                            $info->where($opt)->setInc($word,$v['worth']);
                            break;
                        case 2:
                            $info->where($opt)->setDec($word,$v['worth']);
                            break;
                    }
                }
                successReturn(202);
                break;
        }
    }

    /**
     * 返回用户基本信息
     */
    public function sendDetail($opt){
       $res= db('login')->alias('a')
            ->field('a.id,a.phone,a.nickName,a.avatar,a.status,a.access,a.email,b.coin,b.bullion,b.blind,b.address')
            ->join('info b','a.id=b.uid')
            ->where($opt)
            ->find();
       $res['phone']=str_replace(substr($res['phone'],3,4),'****',$res['phone']);
       return $res;
    }

    public function useInfo($data){
        $send=$this->sendDetail(['a.id'=>$data['uid']]);
        if($send){
            model('api/Index')->getAuto($data['uid'],1,$send);
        }else{
            errorReturn(401);
        }
    }

    /**
     * 组队状态
     */
    public function setGroup($uid,$pay_uid,$type,$link=""){
        $regular=db('system')->find();
        $info=db('info');
        $group=db('index_group');
        $opt['uid']=$uid;
        $access=db('login')->where(['id'=>$uid])->value('access');
        $gather=$group->where($opt)->field('ids,refund_ids')->find();
        $new_id=""; $news_id="";
        switch ($type){
            case 1:
                if($uid==$pay_uid){
                    $data=[
                        'uid'=>$uid,
                        'link'=>$link,
                        'group_time'=>time()
                    ];
                    $ins=$group->insert($data);
                    check($ins,1,$access);
                }else{
                    errorReturn(1020,'操作违规!');
                }
                break;

            case 2:
                if($uid!=$pay_uid) {
                    if ($gather['ids']) {
                        $arr = explode(',', $gather['ids']);
                        if (array_search($pay_uid, $arr) === false) {
                            array_push($arr, $pay_uid);
                            $new_id = implode(',', $arr);
                        }
                    } else {
                        $new_id = $pay_uid;
                    }
                    try {
                        Db::startTrans();
                        $group->where($opt)->setField('ids', $new_id);
                        $info->where($opt)->setInc('bullion', $regular['refund_bullion']);
                        // 提交事务
                        Db::commit();
                        successReturn(202,'更新成功');
                    } catch (\Exception $e) {
                        // 回滚事务
                        Db::rollback();
                        errorReturn(405);
                    }
                }else{
                    errorReturn(1020,'操作违规!');
                }
                break;

            case 3:
                if($uid==$pay_uid){
                    $group->where($opt)->setField('is_access',1);  //链接失效
                }else{
                    errorReturn(1020,'操作违规!');
                }
                break;

            case 4:
                if($uid!=$pay_uid) {
                    //购买人员中剔除
                    if ($gather['ids']) {
                        $arr = explode(',', $gather['ids']);
                        if (array_search($pay_uid, $arr) !== false) {
                            array_splice($arr, array_search($pay_uid, $arr), 1);   //移除指定元素
                            if ($arr == null) {$new_id = null;}
                            else {
                                $new_id = implode(",", $arr);
                            }
                        } else {
                            errorReturn(1010, '操作违规,暂无该预购');
                        }
                    } else {
                        errorReturn(1020, '操作违规,暂无该预购');
                    }

                    if($gather['refund_ids']){
                        $arr1 = explode(',', $gather['refund_ids']);
                        if (array_search($pay_uid, $arr1) === false) {
                            array_push($arr, $pay_uid);
                            $news_id = implode(',', $arr1);
                        }
                    }else{
                        $news_id = $pay_uid;
                    }

                    try {
                        Db::startTrans();
                        $win_arr=[
                            'ids'=>$new_id, 'refund_ids'=>$news_id
                        ];
                        $group->where($opt)->update($win_arr);
                        $info->where($opt)->setDec('bullion', $regular['refund_bullion']);
                        // 提交事务
                        Db::commit();
                        successReturn(202,'更新成功');
                    } catch (\Exception $e) {
                        // 回滚事务
                        Db::rollback();
                        errorReturn(405);
                    }
                }else{
                    errorReturn(1020,'操作违规!');
                }
                break;
        }
    }


    /**
     * 日志
     */
    public function writeLog($model,$aid,$detail){
        $send=[
            'aid'=>$aid,
            'model'=>$model,
            'detail'=>$detail,
            'area'=>2,
            'edit_time'=>time()
        ];
        db('admin_act')->insert($send);
    }
}
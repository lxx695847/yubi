<?php
namespace app\api\model;

class Ys extends Base{
    /**
     * 手机号登录/注册
     */
    public function login_check($phone,$code){
        $login=db('ys_login');
        $res=$login->where(['phone'=>$phone])->find();
        $codes=cache("sms".$phone);
        if($codes==false){
            errorReturn(1100,'验证码已失效，请重新发送');
        }else{
            if($codes==$code){
                if($res==false){
                    //注册
                    $data=[
                        'phone'=>$phone,
                        'registerTime'=>time(),
                        'loginTime'=>time(),
                        'ip'=>getClientIP()
                    ];

                    $uid=$login->insertGetId($data);
                    check($uid,1);
                }else{
                    if($res['status']==1){
                        errorReturn(1005, "用户状态异常");
                    }else{
                        $data=[
                            'ip'=>getClientIP(),
                            'loginTime'=>time(),
                        ];
                        $list= $login->where(['id'=>$res['id']])->update($data);
                        check($list,2);
                    }
                }
            }else{
                errorReturn(1200,'验证码错误，请重新输入');
            }
        }
    }
}
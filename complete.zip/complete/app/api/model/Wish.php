<?php
namespace app\api\model;
use think\Cache;


class Wish extends Base {
    /**
     * 手机号登录/注册
     */
    public function login_check($phone,$code){
        $login=db('dream_user');
        $res=$login->where(['phone'=>$phone])->find();
        $codes=cache($phone.'sms');
        if($codes==false){
            errorReturn(1100,'验证码已失效，请重新发送');
        }else{
            if($codes==$code){
                if($res==false){
                    //注册
                    $data=[
                        'phone'=>$phone,
                        'register'=>time(),
                        'ip'=>getClientIP()
                    ];

                    $uid=$login->insertGetId($data);
                    if($uid){
                        $send=[
                            'uid'=>$uid,
                            'phone'=>str_replace(substr($phone,3,4),'****',$phone)
                        ];
                        check($uid,2,$send);
                    }else{
                        errorReturn(405);
                    }
                }else{
                    if($res['status']==1){
                        errorReturn(1005, "用户状态异常，请联系客服");
                    }else{
                        $list= $login->where(['id'=>$res['id']])->setField('ip',getClientIP());
                        $send=[
                            'uid'=>$res['id'],
                            'phone'=>str_replace(substr($phone,3,4),'****',$phone)
                        ];
                        check($list,2,$send);
                    }
                }
            }else{
                errorReturn(1200,'验证码错误，请重新输入');
            }
        }
    }

    public function other_login($phone){
        $login=db('dream_user');
        $res=$login->where(['phone'=>$phone])->find();
        if($res==false){
            //注册
            $data=[
                'phone'=>$phone,
                'register'=>time(),
                'ip'=>getClientIP()
            ];

            $uid=$login->insertGetId($data);
            if($uid){
                $send=[
                    'uid'=>$uid,
                    'phone'=>str_replace(substr($phone,3,4),'****',$phone)
                ];
                check($uid,2,$send);
            }else{
                errorReturn(405);
            }
        }else{
            if($res['status']==1){
                errorReturn(1005, "用户状态异常，请联系客服");
            }else{
                $list= $login->where(['id'=>$res['id']])->setField('ip',getClientIP());
                $send=[
                    'uid'=>$res['id'],
                    'phone'=>str_replace(substr($phone,3,4),'****',$phone)
                ];
                check($list,2,$send);
            }
        }

    }

}
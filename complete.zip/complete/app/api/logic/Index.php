<?php
namespace app\api\logic;
use think\Model;

class Index extends Model{
    public function test1(){
        $res=model("api/Index")->test1();
        return get_menu($res);
    }
}
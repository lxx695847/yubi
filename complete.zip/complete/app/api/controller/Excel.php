<?php
namespace app\api\controller;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;

class Excel extends Base{
    public function intToChr($index, $start = 65){
        $str = '';
        if (floor($index / 26) > 0) {
            $str .= $this->intToChr(floor($index / 26)-1);
        }
        return $str . chr($index % 26 + $start);
    }


    public function excelExport($fileName = '', $headArr = [], $data = []) {
        $spreadsheet    = new Spreadsheet();   //获取创建文档
        $objPHPExcel    = $spreadsheet->getActiveSheet();  //获取操作文档
        $header = array_values($headArr);
        $data = array_values($data);
        $objPHPExcel->setTitle('测试表');
        $objPHPExcel->getDefaultColumnDimension()->setWidth(20);//设置默认列宽为12

        $col = [];
        //获取初始列和最终列
        foreach ($header as $k => $item) {
            $col[$k] = $this->intToChr($k);
        }
        $firstColumn = $col[0];
        $lastColumn = $col[count($col) - 1];
        $row=1;

        $headerStyle = [
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER,
            ],
            'font' => [
                'bold' => true,
                'size' => 14,
            ],
        ];

        $cellStyle = [
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER,
            ],
            'borders' => [
                'allBorders' => [
                    'borderStyle' => Border::BORDER_THIN,
                    'color' => ['argb' => 'FF000000'],
                ]
            ],
            'font' => [
                'size' => 10,
            ],
        ];

        $objPHPExcel->getStyle("{$firstColumn}:{$lastColumn}")->getAlignment()
            ->setVertical(Alignment::VERTICAL_CENTER) //设置垂直居中
            ->setHorizontal(Alignment::HORIZONTAL_CENTER) //设置水平居中
            ->setWrapText(true); //设置自动换行

        //设置头信息样式
        $objPHPExcel->getRowDimension($row)->setRowHeight(30);//设置行高
        $objPHPExcel->getStyle("{$firstColumn}{$row}:{$lastColumn}{$row}")->applyFromArray($headerStyle);
        //设置头信息
        foreach ($header as $key => $item) {
            $objPHPExcel->setCellValue("{$col[$key]}{$row}", $item);
        }
        $row++;
        foreach ($data as $key => $model) {
            $objPHPExcel->getRowDimension($row)->setRowHeight(30);//设置行高
            $objPHPExcel->getStyle("{$firstColumn}{$row}:{$lastColumn}{$row}")->applyFromArray($cellStyle);
            $i = 0;
            foreach ($model as $value) {
                $objPHPExcel->setCellValue("{$col[$i]}{$row}", $value);
                $i++;
            }
            $row++;
        }

        header('Content-Type: application/vnd.ms-excel');
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="'.$fileName.'.xlsx"');
        header('Cache-Control: max-age=0');

        //浏览器输出
        $objWriter = IOFactory::createWriter($spreadsheet, 'Xlsx');
        $objWriter->save('php://output');

        //下载到服务器
//        $writer = IOFactory::createWriter($spreadsheet, 'Xlsx');
//        $writer->save($fileName.'Xlsx');
    }


    //excel 导入
    public function excelImport(){
        header("content-type:text/html;charset=utf-8");
        $title = [];//excel工作表标题
        $infos = [];//excel内容
        //上传excel文件
        $file = request()->file('file');
        $roots=ROOT_PATH . 'public' . DS . 'Uploads';
        $info = $file->validate(['size' => 1048576, 'ext' => 'xls,xlsx'])
            ->move($roots);
        if ($info) {
            //获取上传到后台的文件名
            $fileName = $info->getSaveName();
            //获取文件路径
            $filePath=ROOT_PATH . 'public' . DS . 'Uploads' . DS . $fileName;
            //获取文件后缀
            $suffix = $info->getExtension();
            //判断哪种类型
            if ($suffix == "xlsx") {
                $reader = IOFactory::createReader('Xlsx');
            } else {
                $reader = IOFactory::createReader('Xls');
            }
        } else {
            return json(['status' => '1', 'message' => '文件过大或格式不正确导致上传失败-_-!']);
        }
        //载入excel文件
//        $reader = IOFactory::createReader('Xlsx');
        $excel = $reader->load($filePath, $encode = 'utf-8');
        //读取第一张表
        $sheet = $excel->getSheet(0);
        $spreadsheet = $reader->load($filePath);
        $sheetAllCount = $spreadsheet->getSheetCount(); // 工作表总数
        for ($index = 0; $index < $sheetAllCount; $index++) {   //工作表标题
            $title[] = $spreadsheet->getSheet($index)->getTitle();
        }

        $highest_row = $sheet->getHighestRow(); // 取得总行数
        $highest_column = $sheet->getHighestColumn(); ///取得列数  字母abc...
        $highestColumnIndex = Coordinate::columnIndexFromString($highest_column);  //转化为数字;

        //列
        for ($i = 1; $i <= $highestColumnIndex; $i++) {
            //第一行为标题
            for ($j = 2; $j <= $highest_row; $j++) {
                $infos[$j][$i] = $sheet->getCellByColumnAndRow($i, $j)->getCalculatedValue();
            }
        }
        print_r($infos);
    }

}
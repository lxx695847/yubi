<?php
namespace app\api\controller;

class LV extends Base {
    //用户
    public function getCustomer(){
        try{
            $param=input('get.');
            $opt['id']=['gt',0];
            if(isset($param['uid'])){
                $opt['uid']=$param['uid'];
            }
            if(isset($param['mobile'])){
                $opt['mobile']=['like', "%" . $param['mobile'] . "%"];
            }
            if(isset($param['is_vip'])){
                $opt['is_vip']=$param['is_vip'];
            }

            //会员开始时间
            if(isset($param['vipStarts'])){
                $ss=explode('@',$param['vipStarts']);
                $start=strtotime($ss[0]);
                $end=(int)strtotime($ss[1])+(3600*24-1);
                $opt['vipStart']=[['>=',$start],['<=',$end],'and'];
            }

            //会员注册时间
            if(isset($param['registers'])){
                $st=explode('@',$param['registers']);
                $starts=strtotime($st[0]);
                $ends=(int)strtotime($st[1])+(3600*24-1);
                $opt['register']=[['>=',$starts],['<=',$ends],'and'];
            }

            $res=db('lv_bags_user')->where($opt)->select();
            foreach ($res as $k=>$v){
                $g=explode(',',$v['order']);
                $res[$k]['orderCount']=count($g);
//                $res[$k]['mobile']=substr_replace($v['mobile'], '****', 3, 4);
                if($v['is_vip']==2){
                    $res[$k]['vipStart']=date('Y-m-d H:i:s',$v['vipStart']);
                }
                $res[$k]['register']=date('Y-m-d H:i:s',$v['register']);
            }
            $res ?  successReturn(200,"",$res) : successReturn(204);
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }

    //获取商品
    public function getGoods(){
        try{
            $sort=['时尚手袋','小型皮具'];
            $copy1=db('lv_bags_copy1');
            $param=input('get.');
            $opt['id']=['gt',0];
            if(isset($param['pid'])){
                $opt['pid']=$param['pid'];
            }
            if(isset($param['is_update'])){
                $start=strtotime($param['is_update']);
                $end=$start+3600*24-1;
                $opt['is_update']=[['>=',$start],['<=',$end],'and'];
            }
            if(isset($param['is_show'])){
                $opt['is_show']=$param['is_show'];
            }
            $bags=$copy1->field('id,times',true)->where($opt)->order('times desc')->select();
            $arr=[];
            foreach ($bags as $k=>$v){
                $ko=explode(',',$v['area']);
                $title='';
                for ($i=0;$i<count($ko);$i++){
                    $title.='-'.$sort[$ko[$i]-1];
                }
                $bags[$k]['sort']=$title;
                $bags[$k]['kind']=json_decode($v['kind'],true);
                if($v['is_update']){
                    $bags[$k]['is_update']=date("Y-m-d",$v['is_update']);
                }

                if(isset($param['area'])){
                    if(in_array($param['area'],$ko)==true){
                        array_push($arr,$bags[$k]);
                    }
                }
            }

            if(isset($param['area'])){
                successReturn(200,'',$arr);
            }else{
                successReturn(200,'',$bags);
            }
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }

    //获取商品(新api)
    public function newGood(){
        try{
            $sort=['时尚手袋','小型皮具'];
            $copy1=db('lv_bags_copy1');
            $param=input('get.');
            $opt['id']=['gt',0];
            $arr=[];
            //spu,title搜索
            if(isset($param['search'])){
                $opt['pid|title']=['like',"%" .$param['search'] . "%"];
            }
            //最后更新
            if(isset($param['is_update'])){
                $start=strtotime($param['is_update']);
                $end=$start+3600*24-1;
                $opt['is_update']=[['>=',$start],['<=',$end],'and'];
            }
            //在售状态
            if(isset($param['is_show'])){
                $opt['is_show']=$param['is_show'];
            }

            $bags=$copy1->field('id,times',true)->where($opt)->order('times desc')->select();

            foreach ($bags as $k=>$v){
                $kind=json_decode($v['kind'],true);
                $ko=explode(',',$v['area']);
                $title='';
                for ($i=0;$i<count($ko);$i++){
                    $title.='-'.$sort[$ko[$i]-1];
                }
                foreach ($kind as $ks=>$vs){
                    array_push($arr,[
                        'img'=> $vs['img'],
                        'inStock'=>$vs['inStock'],
                        'sku'=>$vs['skuId'],
                        'material'=>isset($vs['material']) ? $vs['material'] : '',
                        'color'=>isset($vs['color']) ? $vs['color'] : '',
                        'variantName'=>$vs['variantName']=='default' ? '默认' : $vs['variantName'],
                        'pid'=>$v['pid'],
                        'title'=>$v['title'],
                        'price'=>$v['price'],
                        'area'=>$v['area'],
                        'sort'=>$title,
                        'is_show'=>$v['is_show'],
                        'is_update'=>date("Y-m-d",$v['is_update']),
                        'detailUrl'=>$v['detailUrl']."#".$vs['skuId']
                    ]);
                }
            }

            $ops1=[];$ops2=[];$sta=1;
            foreach ($arr as $ee=>$tt){
                //sku搜索
                if(isset($param['sku'])){
                    if($tt['sku']==$param['sku']){
                        successReturn(200,'',[$arr[$ee]]);
                    }else{
                        successReturn(204);
                    }
                }

                if(isset($param['area']) || isset($param['inStock'])){
                    $sta=2;
                    $ko=explode(',',$tt['area']);
                    if(isset($param['area'])){
                        if(in_array($param['area'],$ko)==true){
                            array_push($ops1,$tt);
                        }
                    }

                    if(isset($param['inStock'])){
                        if($tt['inStock']==$param['inStock']){
                            array_push($ops2,$tt);
                        }
                    }
                }
            }
            if($sta==2){
                if($ops1 && $ops2){
                    $kp=[];
                    foreach ($ops1 as $mm=>$nn){
                        if(in_array($nn,$ops2)){
                            array_push($kp,$nn);
                        }
                    }
                    successReturn(200,'',$kp);
                }else{
                    if($ops1){successReturn(200,'',$ops1);};
                    if($ops2){successReturn(200,'',$ops2);};
                }
            }else{
                successReturn(200,'',$arr);
            }

        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }

    //记录
    //库存相关
    public function getRecords(){
        $param=input('get.');
        $times=input('get.timing')!=false ? input('get.timing') : date("Y-m-d",time());
        $start=strtotime($times);
        $end=$start+3600*24-1;
        $opt['a.times']=[['>=',$start],['<=',$end],'and'];

        if(isset($param['search'])){
            $opt['a.pid|a.sku|b.title']=['like',"%" .$param['search'] . "%"];
        }

        if(isset($param['in_stock'])){
            $opt['a.in_stock']=$param['in_stock'];
        }

        $bags=db('lv_logs')->alias('a')
            ->field('a.*,b.title,b.price,b.kind,b.detailUrl,b.times as inTimes')
            ->join('lv_bags_copy1 b','a.pid=b.pid')
            ->order('a.times desc')
            ->where($opt)
            ->select();

        $arr=[];
        foreach ($bags as $k=>$v){
            $bags[$k]['changeTimes']=date('H:i:s',$v['times']);
            $bags[$k]['insTimes']=date('Y-m-d H:i:s',$v['inTimes']);
            $kind=json_decode($v['kind'],true);
            foreach ($kind as $vs){
                if($v['sku']==$vs['skuId']){
                    $bags[$k]['kind']=$vs;
                }
            }
        }

        foreach ($bags as $k=>$v){
            $arr[$v['sku']]['pid']=$v['pid'];
            $arr[$v['sku']]['title']=$v['title'];
            $arr[$v['sku']]['kind']=$v['kind'];
            $arr[$v['sku']]['price']=$v['price'];
            $arr[$v['sku']]['times']=$v['times'];
            $arr[$v['sku']]['inTimes']=$v['inTimes'];
            $arr[$v['sku']]['insTimes']=$v['insTimes'];
            $arr[$v['sku']]['detailUrl']=$v['detailUrl']."#".$v['sku'];

            $arr[$v['sku']]['detail'][]=[
                'in_stock'=>$v['in_stock'],
                'changeTimes'=>$v['changeTimes'],
                'times'=>$v['times']
            ];
        }


        if(isset($param['extra'])){
            $push=[];
            foreach ($arr as $kk=>$yy){
                $detail=$yy['detail'];
                switch ($param['extra']){
                    case 1:
                        //首条记录有库存
                        if($detail[count($detail)-1]['in_stock']==2){
                            $push[$kk]=$arr[$kk];
                        }
                        break;
                    case 2:
                        //当前有库存
                        if($detail[0]['in_stock']==2){
                            $push[$kk]=$arr[$kk];
                        }
                        break;
                }
            }
            $arr=$push;
        }

        $send=[];
        foreach ($arr as $hh=>$ss){
            $eo=[
                'pid'=>$ss['pid'],
                'sku'=>$hh,
                'title'=>$ss['title'],
                'insTimes'=>$ss['insTimes'],
                'inTimes'=>$ss['inTimes'],
                'price'=>$ss['price'],
                'detailUrl'=>$ss['detailUrl'],
                'variantName'=>$ss['kind']['variantName']=='default' ? '默认' : $ss['kind']['variantName'],
                'material'=>isset($ss['kind']['material']) ? $ss['kind']['material'] : '',
                'color'=>isset($ss['kind']['color']) ? $ss['kind']['color'] : '',
                'img'=>$ss['kind']['img'],
                'local'=>isset($ss['kind']['local']) ? $ss['kind']['local'] : '',
                'detail'=>$ss['detail']
            ];
            $detail=$ss['detail'];
            foreach ($detail as $pp=>$qq){
                $eo['stock']=$detail[0]['in_stock'];
                $eo['changeTimes']=$detail[0]['changeTimes'];
                $eo['times']=$detail[0]['times'];
                $eo['change']=count($detail);
            }
            array_push($send,$eo);
        }
        successReturn(200,"",$send);
    }

    //订阅消息
    public function orderNews(){
        $param=input('get.');
        $opt['id']=['>',0];
        if(isset($param['timing'])){
            $ss=explode('@',$param['timing']);
            $start=strtotime($ss[0]);
            $end=(int)strtotime($ss[1])+(3600*24-1);
            $opt['times']=[['>=',$start],['<=',$end],'and'];
        }

        if(isset($param['uid'])){
            $opt['uid']=$param['uid'];
        }

        if(isset($param['area'])){
            $opt['area']=$param['area'];
        }

        $bags=db('lv_bags_news')->where($opt)->order('times desc')->select();

        foreach ($bags as $k=>$v){
//            $bags[$k]['mobile']=substr_replace($v['mobile'], '****', 3, 4);
            $bags[$k]['times']=date('Y-m-d H:i:s',$v['times']);
        }

        successReturn(200,"",$bags);
    }

    //支付订单
    public function payNews(){
        $param=input('get.');
        $opt['id']=['>',0];
        if(isset($param['timing'])){
            $ss=explode('@',$param['timing']);
            $start=strtotime($ss[0]);
            $end=(int)strtotime($ss[1])+(3600*24-1);
            $opt['time_end']=[['>=',$start],['<=',$end],'and'];
        }

        if(isset($param['transaction_id'])){
            $opt['a.transaction_id']=$param['transaction_id'];
        }
        if(isset($param['type'])){
            $opt['type']=$param['type'];
        }
        $res=db('pay_order')->where($opt)->order('time_end desc')->select();
        successReturn(200,'',$res);
    }

    //在售变化
    public function storeChange(){
        $param=input('get.');
        $opt['a.id']=['gt',0];

        //会员开始时间
        if(isset($param['timing'])){
            $ss=explode('@',$param['timing']);
            $start=strtotime($ss[0]);
            $end=(int)strtotime($ss[1])+(3600*24-1);
            $opt['a.times']=[['>=',$start],['<=',$end],'and'];
        }


        if(isset($param['search'])){
            $opt['a.pid|a.sku|b.title']=['like',"%" .$param['search'] . "%"];
        }

        if(isset($param['in_stock'])){
            $opt['a.in_stock']=$param['in_stock'];
        }

        $bags=db('lv_product_logs')->alias('a')
            ->field('a.*,b.title,b.price,b.kind,b.detailUrl,b.times as inTimes')
            ->join('lv_bags_copy1 b','a.pid=b.pid')
            ->order('a.times desc')
            ->where($opt)
            ->select();

        $arr=[];
        foreach ($bags as $k=>$v){
            $bags[$k]['times']=date('Y-m-d',$v['times']);
            $bags[$k]['inTimes']=date('Y-m-d H:i:s',$v['inTimes']);
            $kind=json_decode($v['kind'],true);
            foreach ($kind as $vs){
                if($v['sku']==$vs['skuId']){
                    $bags[$k]['kind']=$vs;
                }
            }
        }

        foreach ($bags as $k=>$v){
            $arr[$v['sku']]['pid']=$v['pid'];
            $arr[$v['sku']]['title']=$v['title'];
            $arr[$v['sku']]['kind']=$v['kind'];
            $arr[$v['sku']]['price']=$v['price'];
            $arr[$v['sku']]['inTimes']=$v['inTimes'];
            $arr[$v['sku']]['detailUrl']=$v['detailUrl']."#".$v['sku'];

            $arr[$v['sku']]['detail'][]=[
                'in_stock'=>$v['in_stock'],
                'times'=>$v['times']
            ];
        }

        $send=[];
        foreach ($arr as $hh=>$ss){
            $eo=[
                'pid'=>$ss['pid'],
                'sku'=>$hh,
                'title'=>$ss['title'],
                'inTimes'=>$ss['inTimes'],
                'price'=>$ss['price'],
                'detailUrl'=>$ss['detailUrl'],
                'variantName'=>$ss['kind']['variantName']=='default' ? '默认' : $ss['kind']['variantName'],
                'img'=>$ss['kind']['img'],
                'local'=>isset($ss['kind']['local']) ? $ss['kind']['local'] : '',
                'detail'=>$ss['detail']
            ];
            $detail=$ss['detail'];
            foreach ($detail as $pp=>$qq){
                $eo['stock']=$detail[0]['in_stock'];
                $eo['times']=$detail[0]['times'];
                $eo['change']=count($detail);
            }
            array_push($send,$eo);
        }
        successReturn(200,"",$send);
    }
}
<?php
namespace app\api\controller;
use think\Hook;
use sms\SmsSingleSender;

class Login extends Base {
        /**
         * @method post
         * 手机号验证码
         */
        public function sendReport(){
            $phoneNumbers=input('param.phone');
            Hook::exec('app\\api\\behavior\\Check','run',$phoneNumbers);
            $res=checkPhone($phoneNumbers);
            if($res==true) {
                try {
                    $leave=(int)(strtotime(date('Y-m-d',time()))+24*3600-1)-time();  //当天剩余时间
                    if($leave<=0){
                        cache(getClientIP(), NULL);
                        cache($phoneNumbers, NULL);
                    }
                    //防刷机制 (ip)
                    $ipCount=cache(getClientIP());
                    if($ipCount!=false){
                        if($ipCount>100){
                            errorReturn(1030,'不可频繁操作,明日再申请');
                        }else{
                            $ipCount++;
                            cache(getClientIP(),$ipCount,$leave);
                        }
                    }else{
                        cache(getClientIP(),1,$leave);
                    }

                    //(验证次数)
                    $num=cache($phoneNumbers);
                    if($num!=false){
                        $lom=unserialize($num);
                        if($lom['total']==false){
                            errorReturn(1020,'今日手机验证次数不足，明日再来');
                        }else{
                            if(time()-$lom['sendTime']<60){
                                errorReturn(1030,'不可频繁发送验证码');
                            }else{
                                $kos=[
                                    'total'=>$lom['total']--,
                                    'sendTime'=>time()
                                ];
                                cache($phoneNumbers,serialize($kos),$leave);
                            }
                        }
                    }else{
                        $kos=[
                            'total'=>19,
                            'sendTime'=>time()
                        ];
                        cache($phoneNumbers,serialize($kos),$leave);
                    }

                    $res=sendMsg(1,$phoneNumbers);
//                    $param=[getRand(),1];  //验证码
//                    $ssender = new SmsSingleSender(config("sms.appid"), config("sms.appkey"));
//                    $result = $ssender->sendWithParam("86",$phoneNumbers,config("sms.templateId"),
//                       $param,config("sms.smsSign"), "", "");
//                    $rsp = json_decode($result,true);
//                    if($rsp['result']!=false){
//                        errorReturn($rsp['result'],$rsp['errmsg']);
//                    }else{
//                        $rsp['sendCode']=$param[0];
//                        successReturn(200,"",$rsp);
//                    }

                    cache($phoneNumbers."sms",$res['sendCode'],5*60);
                    successReturn(200);
                } catch(\Exception $e) {
                    errorReturn(1050,$e->getMessage());
                }
            }else{
                errorReturn(1060,'手机号格式不正确');
            }
        }

        /**
         * @param $phone
         * @method post
         * 检测手机号注册/登录
         */
        public function getLogin(){
            try{
                $phone=input("param.phone");
                $code=input("param.code");
                $tag=[$phone,$code];
                Hook::exec('app\\api\\behavior\\Check','run',$tag);
                $res=checkPhone($phone);
                if($res==true){
                    model('api/Login')->login_check($phone,$code);
                }else{
                    errorReturn(1060,'手机号格式不正确');
                }
            }catch (\Exception $e){
                errorReturn(500,$e->getMessage());
            }
        }


        public function switchCheck(){
            $sessionId=input("param.csessionId");
            $Token=input("param.Token");
            $sig=input("param.sig");
            $tag=[$sessionId,$Token,$sig];
            Hook::exec('app\\api\\behavior\\Check','run',$tag);
            getAsf($sessionId,$Token,$sig);
        }

        /**
         * 微信三方手机绑定登录
         */
        public function otherLogin(){
            try{
                $import=input("param.import");
                $phone=input("param.phone");
                $code=input("param.code");
                $tag=[$import,$phone,$code];
                Hook::exec('app\\api\\behavior\\Check','run',$tag);
                $res=checkPhone($phone);
                if($res==true){
                    //签名解密
                    $infos=desSigns($import);
                    Hook::exec('app\\api\\behavior\\Check','checkAccess',$infos);
                    model('api/Login')->other_check($infos,$phone,$code);
                }else{
                    errorReturn(1060,'手机号格式不正确');
                }
            }catch (\Exception $e){
                errorReturn(500,$e->getMessage());
            }
        }

        /**
         * 育碧微信三方登录
         */
        public function moreLogin(){
            try{
                $detail=input('param.detail');
                Hook::exec('app\\api\\behavior\\Check','run',$detail);
                $aos = json_decode($detail, true);
                model('api/Login')->dealInfo($aos);
            }catch (\Exception $e){
                errorReturn(500,$e->getMessage());
            }
        }

        /**
         * 微信三方授权获取信息(暂不需要)
         */
        public function getTokens(){
            try{
                $code=input('param.code');
                Hook::exec('app\\api\\behavior\\Check','run',$code);
                $url=config('wx.tokenUrl')."?appid=".config('wx.appid')."&secret=".config('wx.secret')."&code=".$code."&grant_type=".config('wx.grant_type');
                $result=http_curl($url);
                $list = json_decode($result, true);
                if(isset($list['errcode'])) {
                    errorReturn($list['errcode'], $list['errmsg']);
                }else{
                    $src=config('wx.infoUrl')."?access_token=".$list['access_token']."&openid=".$list['openid']."&lang=".config('wx.lang');
                    $row=http_curl($src);
                    $aos = json_decode($row, true);
                    if(isset($aos['errcode'])){
                        errorReturn($aos['errcode'], $aos['errmsg']);
                    }else{
                        model('api/Login')->dealInfo($aos);
                    }
                }
            }catch (\Exception $e){
                errorReturn(500,$e->getMessage());
            }
        }


        /**
         * 获取用户基本信息
         */
        public function getDetail(){
            try{
                $access=input('param.access');
                Hook::exec('app\\api\\behavior\\Check','run',$access);
                //签名解密
                $infos=desSigns($access);
                Hook::exec('app\\api\\behavior\\Check','checkAccess',$infos);
                model('api/Login')->useInfo($infos);
            }catch (\Exception $e){
                errorReturn(500,$e->getMessage());
            }
        }

        /**
         * 育碧绑定
         * 1.获取用户手机  2.账号绑定
         * @param user_id
         * @param step
         * @param sign(签名 step为2,3时传递)
         * @param access(秘钥 step为2时传递)
         * @param email (邮箱 step为2时传递)
         * @param award json字符串(奖励 step为3时传递)  类似 [{'worth': 2,'type':1,'kind':1},{'worth': 3,'type':1,'kind':2}]
         * @return mixed
         */
        public function getBlind(){
            try{
                $user_id=input('post.user_id');
                $step=input('post.step');
                $tag=[$user_id,$step];
                $need="";
                Hook::exec('app\\api\\behavior\\Check','run',$tag);
                if($step==2){
                    $access=input('post.access');
                    $need=input('post.email');
                    $sign=input('post.sign');
                    $tags=[$access,$need,$sign];
                    Hook::exec('app\\api\\behavior\\Check','run',$tags);

                    //秘钥解密
                    $infos=desSigns($access);
                    Hook::exec('app\\api\\behavior\\Check','checkAccess',$infos);
                    //签名解密
                    $signs=desSigns($sign);
                    Hook::exec('app\\api\\behavior\\Check','checkAccess',$signs);
                }elseif ($step==3){
                    $access=input('post.access');
                    $need=input('post.award');
                    $sign=input('post.sign');
                    $tags=[$access,$need,$sign];
                    Hook::exec('app\\api\\behavior\\Check','run',$tags);

                    //秘钥解密
                    $infos=desSigns($access);
                    Hook::exec('app\\api\\behavior\\Check','checkAccess',$infos);
                    //签名解密
                    $signs=desSigns($sign);
                    Hook::exec('app\\api\\behavior\\Check','checkAccess',$signs);
                }
                model('api/Login')->setBlind($user_id,$step,$need);
            }catch (\Exception $e){
                errorReturn(500,$e->getMessage());
            }
        }

        /**
         * 组队状态返回
         * @param uid
         * @param pay_uid
         * @param type(1组队链接，2购买状态，3退款状态)
         * @param link(type为1时必须)
         * @param access(秘钥，type为2,3,4时必须)
         * @return mixed
         */
        public function groupStatus(){
            try{
                //模块是否开启
                $model='is_group';
                Hook::exec('app\\api\\behavior\\Check','checkModel',$model);
                $uid=input('post.uid');
                $pay_uid=input('post.pay_uid');
                $type=input('post.type');
                $tag=[$uid,$pay_uid,$type];
                Hook::exec('app\\api\\behavior\\Check','run',$tag);
                if($type==1){
                    $link=input('post.link');
                    Hook::exec('app\\api\\behavior\\Check','run',$link);
                    model('api/Login')->setGroup($uid,$pay_uid,$type,$link);
                }else{
                    $access=input('post.access');
                    Hook::exec('app\\api\\behavior\\Check','run',$access);

                    //签名解密
                    $infos=desSigns($access);
                    Hook::exec('app\\api\\behavior\\Check','checkAccess',$infos);
                    model('api/Login')->setGroup($uid,$pay_uid,$type);
                }
            }catch (\Exception $e){
                errorReturn(500,$e->getMessage());
            }
        }
}
<?php
namespace app\api\controller;
use lib\redis;
header('Access-Control-Allow-Origin:*');

class Test extends Base{
    //库存队列
    public function Prepare(){
        $num=100;
        $redis = new redis();
        for($i=0;$i<$num;$i++){
            $redis->push(2,"goodStore",$i);
        }
        echo "已准备就绪";
        exit;
    }

    public function Buy(){
        $uid=uniqid();
        $redis = new redis();

        //集合唯一性
        if($redis->sisMember('userList',$uid)){
            echo "不可重复抢购";
            exit;
        }else{
            if($uid!=false && is_string($uid)) {
                 $count=$redis->lLen("goodStore");
                 if ($count!=0) {
                    $aop1=$redis->pop(1,"goodStore");
                    //插入集合抢购数据
                    $aop2=$redis->sAdd("userList", $uid);   //抢购集合
                    if(!$aop1 && $aop2==1){
                        echo "抢购成功！<br/>";
//                      var_dump($redis->sMembers("userList"));
                        //订单操作
                        $con=[
                            'uid'=>$uid,
                            'order'=>getOrderId(),
                            'time'=>time(),
                            'gid'=>15
                        ];
                        $redis->push('2','orderList',json_encode($con));
                    } else {
                        echo "手气不好，请重新抢购！";
                        exit;
                    }
                }else {
                    echo "已售罄,秒杀结束";
                    exit;
                }
            }else{
                echo "用户信息错误";
                exit;
            }
        }
    }


    /**
     * @param start,end,month,type,area
     * 切游网收录
     */
    public function getReceive(){
        $param=input('post.');
        $base="";$main="";
        //不同端
        switch ($param['area']){
            case 1:
                $main="http://www.qieyou.com";
                $api = 'http://data.zz.baidu.com/urls?site=www.qieyou.com&token=KhF4pJOCRajiLk7M';
                break;
            case 2:
                $main="http://m.qieyou.com";
                $api = 'http://data.zz.baidu.com/urls?site=m.qieyou.com&token=KhF4pJOCRajiLk7M';
                break;
        }
        //不同分类
        switch ($param['type']){
            case 1:
                $base=$main."/ku";
                break;
            case 2:
                $base=$main."/content";
                break;
            case 3:
                $base=$main."/wzry";
                break;
            case 4:
                $base=$main."/lscs";
                break;
            case 5:
                $base=$main.'/cfm';
                break;
            case 6:
                $base=$main.'/qqdzz';
                break;
            case 7:
            case 8:
                break;
            case 9:
                $base=$main.'/harrypotter';
                break;
            case 10:
                $base=$main.'/lolm';
                break;
            case 11:
                $base=$main.'/jcc';
                break;
        }

        $urls=[];
        for ($i=$param['start'];$i<=$param['end'];$i++){
            if($param['type']==1){
                $vips=$base.'/'.$i.'.html';
                array_push($urls,$vips);
            }else{
                $time=date('Y',time()).$param['month'];
                $vip=$base.'/'.$time.'/'.$i.'.html';
                array_push($urls,$vip);
            }
        }


        $ch = curl_init();
        $options =  array(
            CURLOPT_URL => $api,
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POSTFIELDS => implode("\n", $urls),
            CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
        );
        curl_setopt_array($ch, $options);
        $result = curl_exec($ch);
        echo $result;
    }
}
<?php
namespace app\api\controller;
use phpmailer\Exception;
use phpmailer\PHPMailer;
Vendor('Weixinpay.Weixinpay');
vendor('Alipay.alipay');
Vendor('Alipay.AlipayTradeService');

class Order extends Base{
    public $copy1;
    public $logs;
    public $product;

    public function __construct(){
        $this->copy1=db('lv_bags_copy1');
        $this->logs=db('lv_logs');
        $this->product=db('lv_product_logs');
    }

    //获取accessToken
    public function getAccess($type){
        $config=config('companyWx');
        $secret="";$area="";
        switch ($type){
            case 1:
                $area='custom';
                $secret=$config['corpsecret_custom'];
                break;
            case 2:
                $area='user';
                $secret=$config['corpsecret_user'];
                break;
            case 3:
                $area='app';
                $secret=$config['corpsecret_app'];
                break;
        }
        $token=cache($area);
        if($token!=false){
            return $token;
        }else{
            $url=$config['tokenUrl'].'?corpid='.$config['corpid'].'&corpsecret='.$secret;
            $data=http_curl($url);
            $row=json_decode($data,true);
            if($row['errcode']!=0){
                return false;
            }else{
                cache($area,$row['access_token'],$row['expires_in']);
                return $row['access_token'];
            }
        }
    }

    //获取客户列表
    public function getCustomList(){
        $config=config('companyWx');
        $token=$this->getAccess(1);
        if($token!=false){
            $url=$config['listUrl'].'?access_token='.$token.'&userid='.$config['userid'];
            $data=http_curl($url);
            $row=json_decode($data,true);
            if($row['errcode']!=0){
                return false;
            }else{
                return $row['external_userid'];
            }
        }else{
            return false;
        }
    }

    //获取/修改部门成员以及订阅状态
    public function getPartMent(){
        $config=config('companyWx');
        $token=$this->getAccess(2);
        if($token!=false){
            $url=$config['PartMentUrl'].'?access_token='.$token.'&department_id=2';
            $data=http_curl($url);
            $row=json_decode($data,true);
            if($row['errcode']!=0){
                return false;
            }else{
                //部门用户入库
                if(!empty($row['userlist'])){
                    $user=db('lv_bags_user');
                    $ids=$user->column('uid');
                    $goal=[];
                    foreach ($row['userlist'] as $k=>$v){
                        $goal[$k]=[
                            'uid'=>$v['userid'],
                            'mobile'=>$v['mobile'],
                            'avatar'=>$v['avatar']
                        ];
                        $extra=$v['extattr']['attrs'];
                        if(!empty($extra)){
                            foreach ($extra as $pp=>$oo){
                                //订阅
                                if($oo['name']=='sku_lv'){
                                    if($extra[$pp]['value']!=false) {
                                        $goal[$k]['order'] = $extra[$pp]['value'];
                                    }
                                }

                                //会员
                                if($oo['name']=='vip_xz'){
                                    if($extra[$pp]['value']!=false){
                                        $goal[$k]['vip']=$extra[$pp]['value'];
                                        $goal[$k]['vipStart']=time();
                                    }
                                }
                            }
                        }
                    }

                    $status=1;
                    foreach ($goal as $ks=>$vs) {
                        if (!empty($ids)) {
                            $status = in_array($vs['uid'], $ids) == true ? 2 : 1;
                        }

                        switch ($status) {
                            //添加
                            case 1:
                                $vs['register']=time();
                                //是否开通vip
                                if (isset($vs['vip']) && $vs['vip'] != false) {
                                    $vs['newsCount'] = 2;
                                    $vs['is_vip'] = 2;
                                    $vs['runDay'] = 1;

                                    //会员相关操作
                                    $this->vipPre($vs['vipStart'], $vs['vip'], $vs['uid'], 1);
                                }

                                //是否选购
                                if (isset($vs['order'])) {
                                    $sm = explode(",", $vs['order']);
                                    $cont = [];

                                    //选购消息
                                    foreach ($sm as $th) {
                                        $dps = $this->getUserOrder(1, $th);
                                        if($dps){
                                            array_push($cont, $dps['title'] . "-" . $dps['variantName']);
                                        }
                                    }

                                    //发送商品订阅消息
                                    if(!empty($cont)){
                                        $this->setMsg(1, $vs['uid'], implode(",", $cont));
                                    }

                                    sleep(1);
                                    foreach ($sm as $tm) {
                                        $dp = $this->getUserOrder(1, $tm);
                                        if ($dp && $dp['inStock'] != false) {
                                            //发送sku品图文消息
                                            $this->setMsg(3, $vs['uid'], '', $dp['pid'], $tm, 3);
                                        }
                                    }
                                }
                                $user->insert($vs);
                                break;


                            //更新订阅字段
                            case 2:
                                $opt['uid'] = $vs['uid'];
                                $states=1;  //是否会员有效期发送消息
                                $ups=1; //是否需要更新
                                $ins=$user->field('vip,vipStart,newsCount,is_vip')->where($opt)->find();
                                # 会员开通或续费
                                if (isset($vs['vip']) && $vs['vip'] != false) {
                                    $states=2;
                                    $ups=2;

                                    $newVip=(int)$vs['vip']+(int)$ins['vip'];
                                    $vs['newsCount']=2;
                                    $vs['vip']=$newVip;

                                    //重新续费
                                    if($ins['is_vip']==1 || $ins['is_vip']==3){
                                        $vs['is_vip'] = 2;
                                        $vs['runDay'] = 1;
                                    }

                                    $toff=$ins['vipStart']!=false ? $ins['vipStart'] : $vs['vipStart'];
                                    //会员相关操作
                                    $this->vipPre($toff,$newVip,$vs['uid'],1);
                                }else{
                                    if ($ins['vip']>=1) {
                                            $states=2;
                                    }else{
                                        //无续费会员需求
                                        //是否有购买会员
                                        if($ins['is_vip']==2){
                                            $ups=2;
                                            //权益判断
                                            if($ins['newsCount']>0){
                                                $states=2;
                                                //自动续费
                                                $vs['vip']=30;
                                                $vs['runDay']=1;
                                                $vs['newsCount']=2;
                                                $vs['vipStart']=time();

                                                $this->vipPre(time(),30,$vs['uid'],2);
                                            }else{
                                                // 发送到期提醒
                                                $this->setMsg(2, $vs['uid'], "您的订阅服务已到期,有任何问题请联系小V ！");
                                                //更新用户企业微信
                                                $this->upPartMent($vs['uid'], [
                                                        ['name' => 'vip_xz', 'value' => ''],
                                                        ['name' => 'vip_left', 'value' => 0],
                                                        ['name' => 'vip', 'value' => '订阅服务已到期']
                                                    ]
                                                );
                                                $vs['is_vip']=3;
                                                $vs['run_day']=0;
                                                $vs['vipStart']='';
                                            }
                                        }
                                    }
                                }

                                if (isset($vs['order'])) {
                                    $old = $user->where($opt)->value('order');
                                    $new = explode(',', $vs['order']);
                                    $pp = array_diff($new, explode(',', $old));
                                    if (!empty($pp)) {
                                        $ups=2;
                                        if($states==2){
                                            $cont = [];
                                            foreach ($pp as $kk) {
                                                $dps = $this->getUserOrder(1, $kk);
                                                if($dps){
                                                    array_push($cont, $dps['title'] . "-" . $dps['variantName']);
                                                }
                                            }
                                            //发送订阅消息
                                            if(!empty($cont)){
                                                $this->setMsg(1, $vs['uid'], implode(",", $cont));
                                            }

                                            sleep(1);
                                            foreach ($pp as $kv) {
                                                $dp = $this->getUserOrder(1, $kv);
                                                array_push($cont, $dp['title'] . "-" . $dp['variantName']);
                                                if ($dp && $dp['inStock'] != false) {
                                                    //发送不同sku品图文消息
                                                    $this->setMsg(3, $vs['uid'], '', $dp['pid'], $kv,3);
                                                }
                                            }
                                        }
                                    }
                                }

                                if($ups==2){
                                    $user->where($opt)->update($vs);
                                }
                            break;
                        }
                    }
                }
            }
        }else{
            return false;
        }
    }

    # 会员权益
    public function vipPre($start,$vip,$uid,$area){
        //添加记录
        $pay= db('lv_bags_pay');
        $pay->insert([
            'uid'=>$uid,
            'days'=>$vip,
            'startTimes'=>$start,
            'area'=>$area
        ]);

        //续费新增提醒
        $end = (int)$start + 3600 * 24 * (int)$vip;

        $kf = '服务期为' . date("Y-m-d H:i:s",$start) . '-' . date("Y-m-d H:i:s",$end);
        //vip 开通消息
        $this->setMsg(2, $uid, "恭喜您成功购买订阅服务！".$kf.",有任何问题请联系小V ！");

        //更新用户企业微信
        $this->upPartMent($uid, [
                ['name' => 'vip_xz', 'value' => null],
                ['name' => 'vip_left', 'value' => $vip],
                ['name' => 'vip', 'value' => $kf]
            ]
        );
    }

    #定时任务监控用户会员权益时间
    public function setVipTimes(){
        $user=db('lv_bags_user');
        $row=$user->select();
        foreach ($row as $k=>$v){
            $opt['uid']=$v['uid'];

            if($v['vip']>0){
                if(time()>($v['runDay']*3600*24+$v['vipStart'])){
                    $user->where($opt)->setInc('runDay',1);
                    $user->where($opt)->setDec('vip',1);
                    //更新用户企业微信
                    $this->upPartMent($v['uid'], [
                            ['name' => 'vip_left', 'value' => $v['vip']-1],
                        ]
                    );
                }
            }else{
                switch ($v['is_vip']){
                    case 1:
                    case 3:
                        break;
                    //待续费
                    case 2:
                        $rt=[
                            'is_vip'=>3,
                            'runDay'=>0,
                            'vipStart'=>''
                        ];
                        $user->where($opt)->update($rt);
                        break;
                }
            }
        }
    }


    # 企业微信用户附加信息数据更新
    public function upPartMent($uid,$data){
        $config=config('companyWx');
        $token=$this->getAccess(2);
        if($token!=false){
            $tiff=[];
            foreach ($data as $v){
                array_push($tiff,[
                    "type"=>0,
                    "name"=>$v['name'],
                    "value"=>$v['value'],
                    "text"=>[
                        "value"=>$v['value']
                    ]
                ]);
            }
            $param=[
                "userid"=>$uid,
                "extattr"=>[
                    "attrs"=>$tiff
                ]
            ];
            $url=$config['upPartMent'].'?access_token='.$token;
            http_curl($url,'post',urldecode(json_encode($param,JSON_UNESCAPED_UNICODE)));
        }
    }


    //根据sku 获取已订阅的用户和库存状态以及pid
    public function getUserOrder($area,$sku){
        $data=db('lv_bags_copy1')->field('title,pid,kind')->select();

        switch ($area){
            case 1:
                $arr=[];
                foreach($data as $k=>$v){
                    $list=json_decode($v['kind'],true);
                    foreach ($list as $vs){
                        if($vs['skuId']==$sku){
                            $arr['inStock']=$vs['inStock'];
                            $arr['variantName']=$vs['variantName']=='default' ? '' : $vs['variantName'];
                            $arr['title']=$data[$k]['title'];
                            $arr['pid']=$data[$k]['pid'];
                            break;
                        }
                    }
                }
                return $arr;
                break;

            case 2:
                //python脚本 api调用
                $row=db('lv_bags_user')->field('uid,order')->select();
                $fit=[];
                foreach ($row as $kk=>$vv){
                    if($vv['order']){
                        $aop=explode(",",$vv['order']);
                        if(in_array($sku,$aop)){
                            array_push($fit,$row[$kk]['uid']);
                        }
                    }
                }
                return $fit;
                break;
        }
    }


    //应用成员发送消息
    public function setMsg($area,$userid,$content='',$pid='',$sku='',$first=1){
        $config=config('companyWx');
        $token=$this->getAccess(3);
        if($token!=false){
            $user=db('lv_bags_user');
            $vip=$user->field('is_vip,newsCount')->where(['uid'=>$userid])->find();
            $url=$config['newsUrl'].'?access_token='.$token;

            switch ($area){
                case 1:
                    //订阅成功文本类
                    $param=[
                        'touser'=>$userid,
                        'msgtype'=>'text',
                        'agentid'=> 1000002,
                        'text'=>[
                            'content'=>"恭喜您成功订阅lv".$content."!,官网放货后小V将会在第一时间通知您！"
                        ],
                        'enable_id_trans'=>0,
                        'enable_duplicate_check'=>0,
                        'duplicate_check_interval'=>1800
                    ];
                    break;

                case 2:
                    //会员开通文本类
                    $param=[
                        'touser'=>$userid,
                        'msgtype'=>'text',
                        'agentid'=> 1000002,
                        'text'=>[
                            'content'=>$content
                        ],
                        'enable_id_trans'=>0,
                        'enable_duplicate_check'=>0,
                        'duplicate_check_interval'=>1800
                    ];
                    break;

                case 3:
                    $info=db('lv_bags_copy1')->field('title,kind,detailUrl')->where(['pid'=>$pid])->find();
                    $row=json_decode($info['kind'],true);

                    $send=[];
                    foreach ($row as $k=>$v){
                        if($v['skuId']==$sku){
                            $send=$row[$k];
                            $send['variantName']=$v['variantName']=='default'? '' : $v['variantName'];
                            $send['inStock'] = $v['inStock']!=1 ? '已放货' : '当前已售罄';
                            $send['stockInfo'] = $v['inStock']!=1 ? '已补充库存！点此前往下单！' : '当前已售罄！不知此轮放货小主是否已成功毕业！点此查看取消订阅和换款订阅指导';
                        }
                    }
                    //图文类
                    $param=[
                        'touser'=>$userid,
                        'msgtype'=>'news',
                        'agentid'=>1000002,
                        'news'=>[
                            'articles'=>[
                                [
                                    'title'=>'您订阅的商品'.$send['inStock'],
                                    'description'=>'您订阅的商品'.$info['title'].$send['variantName'].$send['stockInfo'],
                                    'url'=>$info['detailUrl']."#".$sku,
                                    'picurl'=>trim($send['img'])."?wid=150&hei=150"
                                ]
                            ]
                        ],
                        'enable_id_trans'=>0,
                        'enable_duplicate_check'=>0,
                        'duplicate_check_interval'=>1800
                    ];

                    $news=db('lv_bags_news');
                    $kop=[
                        'uid'=>$userid,
                        'pid'=>$pid,
                        'times'=>time(),
                        'sku'=>$sku,
                        'stock'=>$send['inStock']
                    ];
                    switch ($first){
                        case 2:
                            $kop['area']=2;
                            if($vip['is_vip']==2){
                                $news->insert($kop);
                            }
                            break;
                        case 3:
                            $kop['area']=1;
                            $news->insert($kop);
                            break;
                    }
                    break;
            }


            if($first!=2){
                http_curl($url,'post',urldecode(json_encode($param,JSON_UNESCAPED_UNICODE)));
            }else{
                //python脚本 运行无会员不通知
                if($vip['is_vip']==2){
                    if($vip['newsCount']>0){
                        $user->where(['uid'=>$userid])->setDec('newsCount',1);
                    }
                    http_curl($url,'post',urldecode(json_encode($param,JSON_UNESCAPED_UNICODE)));
                }
            }
        }else{
            errorReturn(1020,'凭证缺失');
        }
    }


    //发送消息测试
    public function setMsgs($userid){
        $config=config('companyWx');
        $token=$this->getAccess(3);
        if($token!=false){
            $url=$config['newsUrl'].'?access_token='.$token;
            //图文类
            $param=[
                'touser'=>$userid,
                'msgtype'=>'news',
                'agentid'=>1000002,
                'news'=>[
                    'articles'=>[
                        [
                            'title'=>'您订阅的商品发货了',
                            'description'=>'您订阅的商品发货了',
                            'url'=>'',
                            'picurl'=>'http://ybadmin.aju.cn/Uploads/test.jpg'
                        ]
                    ]
                ],
                'enable_id_trans'=>0,
                'enable_duplicate_check'=>0,
                'duplicate_check_interval'=>1800
            ];
            http_curl($url,'post',urldecode(json_encode($param,JSON_UNESCAPED_UNICODE)));
        }else{
            errorReturn(1020,'凭证缺失');
        }
    }


    //发送客户消息(单客户每天只能一条)
    public function getMsg(){
        $config=config('companyWx');
        $token=$this->getAccess(1);
        if($token!=false){
            if($this->getCustomList()!=false){
                $url=$config['msgUrl'].'?access_token='.$token;
                $param=[
                    'chat_type'=>'single',
                    'external_userid'=>$this->getCustomList(),
                    "sender"=>$config['userid'],
                    "text"=>[
                        "content"=>"欢迎回来!"
                    ],
                    "attachments"=>[
                        [
                            'msgtype'=>'link',
                            "link"=>[
                                "title"=>"抢到啦",
                                "picurl“"=>"https://example.pic.com/path",
                                "desc"=>"你在该平台订购的已抢到啦",
                                "url"=>"https://www.louisvuitton.cn/zhs-cn/women/handbags/all-handbags/_/N-1ouyuai"
                            ]
                        ]
                    ]
                ];
                $data=http_curl($url,'post',json_encode($param,JSON_UNESCAPED_UNICODE));
                if($data==false){
                    errorReturn(1040,'请求失败');
                }else{
                    $row=json_decode($data,true);
                    if($row['errcode']!=0){
                        errorReturn(1030,$row['errmsg']);
                    }else{
                        successReturn(200,'发送消息成功');
                    }
                }
            }else{
                errorReturn(1020,'暂无客户');
            }
        }else{
            errorReturn(1020,'凭证缺失');
        }
    }


//python 脚本数据更新
#pid,sku,in_stock
    public function newPostData($data){
        $copy1=$this->copy1;
        $row=json_decode($data,true);
        try{
            foreach ($row as $ks=>$vs){
                if(!empty($vs)){
                    foreach ($vs as $k=>$v){
                        $ser=2;
                        $eu=explode("@",$v);
                        $single=[
                            'pid'=>$eu[0],
                            'sku'=>$eu[1],
                            'in_stock'=>$eu[2],
                            'times'=>time()
                        ];

                        //列表数据
                        $oh['pid']=$single['pid'];
                        $kind=$copy1->where($oh)->value('kind');
                        $json=json_decode($kind,true);
                        $tu=1;
                        foreach ($json as $kk=>$vv){
                            if($vv['skuId']==$single['sku']){
                                if($vv['inStock']!=$single['in_stock']){
                                    $tu=2;
                                    $json[$kk]['inStock']=$single['in_stock'];
                                }
                            }
                        }
                        if($tu==2){
                            $res=$copy1->where($oh)->setField('kind',json_encode($json,JSON_UNESCAPED_UNICODE));
                            if($res){
                                $os['sku']=$single['sku'];
                                $stocks=$this->logs->where($os)->column('in_stock');
                                //记录重复性
                                if($stocks!=false){
                                    if($stocks[count($stocks)-1]==$single['in_stock']){
                                        $ser=1;
                                    }
                                }

                                if($ser==2) {
                                    $this->logs->insert($single);
                                }

                                //消息记录以及消息发送
                                $uid=$this->getUserOrder(2,$single['sku']);
                                if(!empty($uid)){
                                    foreach ($uid as $u){
                                        $this->setMsg(3,$u,'',$single['pid'],$single['sku'],2);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            successReturn(202);
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }

    //传输数据测试
    public function dataTest(){
        $copy1=$this->copy1;
        $data=[
            '010578@M61276@1'
        ];

        foreach ($data as $k=>$v){
            $eu=explode("@",$v);
            $single=[
                'pid'=>$eu[0],
                'sku'=>$eu[1],
                'in_stock'=>$eu[2],
                'times'=>time()
            ];

            //列表数据
            $oh['pid']=$single['pid'];
            $kind=$copy1->where($oh)->value('kind');
            $json=json_decode($kind,true);
            $tu=1;
            foreach ($json as $kk=>$vv){
                if($vv['skuId']==$single['sku']){
                    if($vv['inStock']!=$single['in_stock']){
                        $tu=2;
                        $json[$kk]['inStock']=$single['in_stock'];
                    }
                }
            }

            if($tu==2){
                $res=$copy1->where($oh)->setField('kind',json_encode($json,JSON_UNESCAPED_UNICODE));
                dump($res);
            }
        }
    }

    //python 脚本列表更新数据
    public function getPostList($data='',$area='',$kind='',$part=''){
        if($data){
            $copy1=$this->copy1;
            $product=$this->product;
            switch ($area){
                case 1:
                    $row=explode(",",$data);
                    $opt['pid']=['in',$row];
                    $diff=$copy1->where($opt)->field('pid,is_show,area,kind')->select();

                    foreach ($diff as $vh){
                        $opts['pid']=$vh['pid'];
                        $tik=[
                            'is_update'=>time()
                        ];
                        //分类
                        if($vh['area']==false){
                            $tik['area']=$part;
                        }else{
                            $er=explode(',',$vh['area']);
                            if(in_array($part,$er)==false){
                                array_push($er,$part);
                                $tik['area']=implode(',',$er);
                            }
                        }
                        //是否下架的商品有更新
                        if($vh['is_show']==1){
                            //上架
                            $tik['times']=time();
                            $tik['is_show']=2;

                            $op=json_decode($vh['kind'],true);
                            $ups=[];
                            foreach ($op as $kv){
                                array_push($ups,[
                                    'pid'=>$vh['pid'],
                                    'in_stock'=>2,
                                    'sku'=>$kv['skuId'],
                                    'times'=>time()
                                ]);
                            }
                            $product->insertAll($ups);
                            $copy1->where($opts)->update($tik);
                        }else{
                            $copy1->where($opts)->update($tik);
                        }
                    }
                    $pid_arr=$copy1->column('pid');
                    $pp = array_diff($row,$pid_arr);
                    if(!empty($pp)){
                        $res=array_values($pp);
                        successReturn(200,'',$res);
                    }else{
                        successReturn(204);
                    }
                    break;

                case 2:
                    try{
                        $at=explode("@",$kind);
                        $kinds=[];$ups=[];
                        $datas=json_decode($data,true);
                        foreach ($at as $k=>$v){
                            $uu=explode(",",$v);

                            $kinds[$k]=[
                                'variantName'=>$uu[0],
                                'skuId'=>$uu[1],
                                'img'=>$uu[2],
                                'color'=>$uu[3],
                                'material'=>$uu[4],
                                'inStock'=>$uu[5],
                                'local'=>$uu[6]
                            ];

                            array_push($ups,[
                                'pid'=>$datas['pid'],
                                'in_stock'=>2,
                                'sku'=>$uu[1],
                                'times'=>time()
                            ]);
                        }

                        $datas['kind']=json_encode($kinds);
                        $datas['times']=time();
                        $datas['is_update']=time();
                        $opt['pid']=$datas['pid'];
                        $ins=$copy1->where($opt)->find();
                        if($ins==false){
                            $product->insertAll($ups);
                            $copy1->insert($datas);
                            successReturn(202);
                        };
                    }catch (\Exception $e){
                        errorReturn(500,$e->getMessage());
                    }
                    break;
            }
        }
    }

    //23:50上下架状态处理
    public function getStore(){
        $list=$this->copy1->field('pid,is_update,kind')->where(['is_show'=>2])->select();
        $today=date("Y-m-d",time());
        foreach ($list as $k=>$v){
            $ups=date("Y-m-d",$v['is_update']);
            //已下架
            if($today!=$ups){
                $op=json_decode($v['kind'],true);
                $ups=[];
                foreach ($op as $kv){
                    array_push($ups,[
                        'pid'=>$v['pid'],
                        'in_stock'=>2,
                        'sku'=>$kv['skuId'],
                        'times'=>time()
                    ]);
                }
                $this->product->insertAll($ups);
                $this->copy1->where(['pid'=>$v['pid']])->update([
                    'times'=>time(),
                    'is_show'=>1
                ]);
            }
        }
    }

    //获取最近7天的时间日期
    public function get_weeks(){
        //获取当前周几
        $date = [];
        $date[0] = date('Y-m-d', time()-3600*10);
        for ($i=1; $i<7; $i++){
            $date[$i] = date('Y-m-d' ,strtotime( '-' . $i .' days', time()-3600*10));
        }
        $row=array_reverse($date);
        return $row;
    }

    //邮件00:30定时任务数据统计
    public function updateCount(){
        $totalDate=$this->get_weeks();
        $newDate=array_reverse($totalDate);
        $top=[];
        $users=db('lv_bags_user');
        $ns=db('lv_bags_news');

        $bugs=0;
        $bug=[35,25,16,28,23,19,21];
        $spider=[1030,2160,2160,2160,2160,2160,2160];
        $now=date('Y-m-d', time()-3600*10);
        foreach ($newDate as $ik=>$today){
            //更新记录 （sku、次数）
            $bag=[];$count=0;
            $log=$this->logs->select();
            if($log){
                foreach ($log as $k=>$v){
                    if(date("Y-m-d",$v['times'])==$today){
                        $bag[$v['sku']][]=[
                            'in_stock'=>$v['in_stock'],
                            'times'=>date("H:i:s",$v['times'])
                        ];
                    }
                }

                foreach ($bag as $ks1=>$vs1){
                    $count+=count($vs1);
                };
            }

            //客户记录（总数、新增、到期）
            $user_add=[];$user_expire=[];
            $user=$users->select();
            if($user){
                foreach ($user as $ks=>$vs){
                    if(date("Y-m-d",$vs['register'])==$today){
                        array_push($user_add,$vs);
                        if($vs['is_vip']==1){
                            array_push($user_expire,$vs);
                        }
                    }
                }
            }

            //列表更新统计
            $sku=0;
            $th['times']=['elt',strtotime($today)+86399];
            $items=$this->copy1->where($th)->select();
            foreach ($items as $kp=>$vp){
                $lp=explode(',',$vp['sku']);
                $sku+=count($lp);
            }

            //消息推送记录(人数，条数  (默认、脚本))
            $base=[];$run=[];$base_count=0;$run_count=0;
            $news=$ns->select();
            if($news){
                foreach ($news as $kk=>$vv){
                    if(date('Y-m-d',$vv['times'])==$today){
                        switch ($vv['area']){
                            case 1:
                                $base[$vv['uid']][]=$vv;
                                break;
                            case 2:
                                $run[$vv['uid']][]=$vv;
                                break;
                        }
                    }
                }
            }

            foreach ($base as $vv1){
                $base_count+=count($vv1);
            }
            foreach ($run as $vv2){
                $run_count+=count($vv2);
            }


            if($today==$now){
                $bugs=$bug[0];
            }

            $top[$ik]=[
                'time'=>$today,
                'spider'=>count($bag)>0 ? $spider[$ik] : 0,
                'list'=>[
                    'spu'=>count($items),
                    'sku'=>$sku
                ],
                'product'=>[
                    'pro_sku'=>count($bag),
                    'pro_change'=>$count
                ],
                'user'=>[
                    'user_total'=>count($user),
                    'user_add'=>count($user_add),
                    'user_expire'=>count($user_expire)
                ],
                'news'=>[
                    'run'=>[
                        'run_total'=>count($run),
                        'run_count'=>$run_count
                    ],
                    'base'=>[
                        'base_total'=>count($base),
                        'base_count'=>$base_count
                    ]
                ],
                'bug'=>count($bag)>0 ? $bug[$ik] : 0
            ];

        }

        //今日列表更新统计
        $up=[];
        $kps=$this->copy1->select();
        foreach ($kps as $kp=>$vp){
            $insTimes=date('Y-m-d',$vp['times']);
            $os=$vp['is_show']==2 ? '上架' : '下架';
            $ops=[
                'id'=>$vp['id'],
                'is_show'=>$os,
                'pid'=>$vp['pid'],
                'sku'=>$vp['sku']
            ];
            if($insTimes==$now){
                array_push($up,$ops);
            }
        }

        $res=[
            'change'=>$up,
            'record'=>$top,
            'warn'=>"Max retries exceeded with url...,(Caused by ProxyError('Cannot connect to proxy.', RemoteDisconnected('Remote end closed connection without response')))",
            'now'=>$now,
            'bugs'=>$bugs
        ];

        successReturn(200,'',$res);
    }

    //微信.支付宝二维码支付
    public function payOrder($area){
        try{
            $wxpay=new \Weixinpay();
            $price=39;$title="";$origin=49;
            switch ($area){
                case 1:
                    $origin=49;
                    $price=39;
                    $title="月会员";
                    break;
                case 2:
                    $origin=90;
                    $price=72;
                    $title="两月会员";
                    break;
                case 3:
                    $origin=130;
                    $price=99;
                    $title="季度会员";
                    break;
            }
            $detail=[
                'cost_price'=>$origin,
                'goods_detail'=>[
                    'goods_id'=>$area,
                    'goods_name'=>$title,
                    'quantity'=>1,
                    'price'=>$price
                ]
            ];
            $order = array(
                'body'         => 'Lv即时订阅'.$title,
                'total_fee'    => $price * 100, //分
                'out_trade_no' => getOrderId(),   //获取变量的字符串值
                'product_id'   => $area,
                'trade_type'   => 'NATIVE',
                'detail'=>json_encode($detail)
            );
            $wxpay->pay($order,2);
        }catch (\Exception $e){
            errorReturn(1020,$e->getMessage());
        }
    }

    //支付宝二维码支付
    public function aliPay($area){
        try{
            $aly=new \alipay();
            $price=39;$title="";$origin=49;
            switch ($area){
                case 4:
                    $origin=49;
                    $price=39;
                    $title="月会员";
                    break;
                case 5:
                    $origin=90;
                    $price=72;
                    $title="两月会员";
                    break;
                case 6:
                    $origin=130;
                    $price=99;
                    $title="季度会员";
                    break;
            }
            $data = array(
                'out_trade_no' => strval(getOrderId()),
                'total_amount'  =>  $price,
                'subject'      =>   'Lv即时订阅',
                'body'     =>   $title
            );

            $aly->pc_pay($data);
        }catch (\Exception $e){
            errorReturn(1020,$e->getMessage());
        }
    }
}
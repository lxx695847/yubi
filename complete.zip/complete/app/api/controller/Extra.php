<?php
namespace app\api\controller;
use think\Hook;
header('Access-Control-Allow-Origin:*');


class Extra extends Base{
    /**
     * 任务状态
     * area(1为任务，2为里程碑)
     */
    public function getList(){
        try{
            $area=input('param.area');
            Hook::exec('app\\api\\behavior\\Check','run',$area);

            $access=input('param.access');
            if($access){
                //签名解密
                $infos=desSigns($access);
                Hook::exec('app\\api\\behavior\\Check','checkAccess',$infos);
                model('api/Extra')->myList($area,$infos);
            }else{
                model('api/Extra')->myList($area);
            }
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }


    /**
     * 模块领取奖励
     */
    public function receiveAward(){
        try{
            $access=input('param.access');
            $sign=input('param.sign');
            $tag=[$access,$sign];
            Hook::exec('app\\api\\behavior\\Check','run',$tag);

            //签名解密
            $infos=desSigns($access);
            Hook::exec('app\\api\\behavior\\Check','checkAccess',$infos);

            $signs=desSigns($sign);
            Hook::exec('app\\api\\behavior\\Check','checkAccess',$signs);
            model('api/Extra')->receiveTask($signs);
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }


//抽奖相关
    /**
     * 抽奖中奖记录
     */
    public function getRecord(){
        try{
            $access=input('param.access');
            Hook::exec('app\\api\\behavior\\Check','run',$access);
            //签名解密
            $infos=desSigns($access);
            Hook::exec('app\\api\\behavior\\Check','checkAccess',$infos);
            model('api/Extra')->awardRecord($infos);
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }


    /**
     * 抽奖奖池信息
     */
    public function lotteryAward(){
        try{
            $access=input('param.access');
            if($access){
                //签名解密
                $infos=desSigns($access);
                Hook::exec('app\\api\\behavior\\Check','checkAccess',$infos);
                model('api/Extra')->awardList($infos);
            }else{
                model('api/Extra')->awardList();
            }
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }


    /**
     * 实物地址绑定
     */
    public function blindAddress(){
        try{
            $access=input('param.access');
            //详情地址 json字符串  包括(resName,phone,address)
            $detail=input('param.detail');
            $tag=[$access,$detail];
            Hook::exec('app\\api\\behavior\\Check','run',$tag);
            //签名解密
            $infos=desSigns($access);
            Hook::exec('app\\api\\behavior\\Check','checkAccess',$infos);
            model('api/Extra')->getAddress($infos,$detail);
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }


    /**
     * 抽奖+领奖
     */
    public function lotteryReceive(){
        try{
            $access=input('param.access');
            $pass=input('param.pass');
            $area=input('param.area');
            $tag=[$access,$pass,$area];
            Hook::exec('app\\api\\behavior\\Check','run',$tag);

            //签名解密
            $infos=desSigns($access);
            Hook::exec('app\\api\\behavior\\Check','checkAccess',$infos);

            $passer=desSigns($pass);
            Hook::exec('app\\api\\behavior\\Check','checkAccess',$passer);
            switch ($area){
                case 1:
                    $model='is_common';
                    break;
                case 2:
                    $model='is_higher';
                    break;
            }
            Hook::exec('app\\api\\behavior\\Check','checkModel',$model);
            model('api/Extra')->lotterys($area,$passer);
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }


    /**
     * 系统定时任务
     */
    public function autoTask(){
        date_default_timezone_set('PRC');
        $type=input('get.type');
        $task=db('task_list');
        $shop=db('switch_goods');
        $opt['type']=1;
        switch ($type){
            case "day":
                //(分，小时，天，月，周)
//                "0 0 * * * /usr/bin/wget -q -O temp.txt http://ybadmin.aju.cn/task?type=day";
                $now=time();
                $list=explode("-",date("Y-m-d",$now));
                $check_time = mktime(0,0,0,$list[1],$list[2],$list[0]);
                if(($now-$check_time)<-30 || ($now-$check_time)>30){
                    errorReturn(1100,date("Y-m-d H:i:s",$now).":违规操作");
                }

                $task->where($opt)->setField("ids","");
                $goods=$shop->select();

                foreach ($goods as $k=>$v){
                    //剩余库存
                    if($v['count']>0){
                        //每日限额
                        if($v['count']>$v['limitCount']){
                            //今日余额
                            $goods[$k]['dayCount']=$v['limitCount'];
                        }else{
                            $goods[$k]['limitCount']=$v['count'];
                            $goods[$k]['dayCount']=$v['count'];
                        }
                    }else{
                        $goods[$k]['count']=0;
                        $goods[$k]['dayCount']=0;
                    }
                    $shop->where(['id'=>$v['id']])->update($goods[$k]);
                }
                break;

            case "week":
//                "* * * * 1 /usr/bin/wget -q -O temp.txt http://ybadmin.aju.cn/task?type=day";
                $now=time();
                $list=explode("-",date("Y-m-d",$now));
                $check_time = mktime(0,0,0,$list[1],$list[2],$list[0]);
                if(($now-$check_time)<-30 || ($now-$check_time)>30){
                    errorReturn(1100,date("Y-m-d H:i:s",$now).":违规操作");
                }
                $top=date("w",time());   //星期   (0为星期天)
                if($top!=1){errorReturn(1100,"违规操作");}

                $start=strtotime('2021-09-06 00:00:00');
                if(time()>=$start){
                    db('system')->where(['id'=>1])->setInc("version");
                }
                break;

            case 'minute':
                //每1分钟更新一次  (定时任务)

                //{"week":1,"day":1,"count":1000,"part":1,"type":1,"add":0}
                //开始时间限制
                $system=db('system');
                $pre=strtotime('2021-08-29 00:00:00');
                $start=strtotime('2021-08-29 00:01:00');
                $endTime=strtotime('2021-10-21 00:00:00');
                if(time()==$pre){
                    $base=[
                        "week"=>1,"day"=>1,"count"=>1000,"part"=>1,"type"=>1,"add"=>0
                    ];
                    $system->where(['id'=>1])->setField('run_time',json_encode($base));
                }
                if(time()>=$start){
                    $arr=$system->where(['id'=>1])->value('run_time');
                    $count=[49000,100000,100000,150000,200000,200000,200000,200000];   //每周总量
                    $ranges=[0.15,0.15,0.15,0.15,0.15,0.15,0.1];   //每日概率
                    $time=json_decode($arr,true);

                    $ins1=$time['week']-1;  //第几期
                    $ins2=$time['day']-1;   //第几天

                    //每天生成总量
                    $dayCount=$count[$ins1] * $ranges[$ins2];
                    if($time['type']==1){
                        //夜间0.1 (0-8)
                        $end=480;
                        $base=$dayCount*0.1;   //每日夜间生成总量
                    }else{
                        //白天 0.9 (9-24)
                        $end=960;
                        $base=$dayCount*0.9;   //每日白天生成总量
                    }
                    $part_base=ceil($base/$end);  //每时间段基准量

                    if(time()<=$endTime){
                        if($time['part']==1439){
                            //每天补漏
                            $time['count']=$time['count']+$dayCount-$time['add'];
                            $time['add']=0;
                            $time['part']=0;  $time['type']=1;
                            if($time['day']==7){
                                $time['day']=1;
                                $time['week']+=1;
                            }else{
                                $time['day']+=1;
                            }

                        }else{
                            $add=rand($part_base*0.9,$part_base*1.1);   //每时间段随机量
                            //每天补漏
                            $time['count']=$time['count']+$add;
                            $time['add']=$time['add']+$add;
                            $time['part']+=1;
                            $time['type'] = $time['part']>=480 ? 2 : 1;
                        }

                        $system->where(['id'=>1])->setField('run_time',json_encode($time));
                    }
                }
                break;
        }
    }
}
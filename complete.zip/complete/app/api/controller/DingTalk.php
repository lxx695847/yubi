<?php
namespace app\api\controller;


class DingTalk extends Base {
    public $config;

    public function __construct(){
        $this->config=config('dingding');
    }

    //获取accessToken
    public function getAccess(){
        $token=cache('dingTalk');
        if($token!=false){
            return $token;
        }else{
            $url=$this->config['accessUrl'].'?appkey='.$this->config['AppKey'].'&appsecret='.$this->config['AppSecret'];
            $data=http_curl($url);
            $row=json_decode($data,true);
            if($row['errcode']!=0){
                return false;
            }else{
                cache('dingTalk',$row['access_token'],$row['expires_in']);
                return $row['access_token'];
            }
        }
    }


    //获取部门列表id
    public function dingParts(){
        $token=$this->getAccess();
        if($token!=false){
            $url=$this->config['partUrl'].'?access_token='.$token;
            $data=http_curl($url,'post');
            $row=json_decode($data,true);
            if($row['errcode']!=0){
                return false;
            }else{
                $arr=[];
                foreach ($row['result'] as $k=>$v){
                    $arr[$k]=[
                       'name'=>$v['name'],
                       'dept_id'=>$v['dept_id'],
                       'area'=>$k+1
                    ];
                    //子部门
                    $send['dept_id']=$v['dept_id'];
                    $datas=$this->curl($url,$send);
                    $rows=json_decode($datas,true);
                    if(empty($rows['result'])){
                        $arr[$k]['sub']=[];
                    }else{
                        foreach ($rows['result'] as $ks=>$vs){
                            $arr[$k]['sub'][$ks]=[
                                'name'=>$vs['name'],
                                'dept_id'=>$vs['dept_id'],
                                'area'=>$ks+1
                            ];
                        }
                    }
                }
                return $arr;
            }
        }else{
            return false;
        }
    }


    //获取部门用户列表基础信息
    public function dingUsers(){
        $list=$this->dingParts();
        if($list){
            $token=$this->getAccess();

            $url=$this->config['userList'].'?access_token='.$token;
            $send=[
                "cursor"=>0,
                "size"=>100
            ];
            foreach ($list as $ks=>$vs){
                $send['dept_id']=(int)$vs['dept_id'];
                $data=$this->curl($url,$send);
                $row=json_decode($data,true);
                if($row['errcode']!=0){
                    $list[$ks]['people']=[];
                }else {
                    $detail=$row['result']['list'];
                    foreach ($detail as $h=>$f){
                        $list[$ks]['people'][$h]=[
                            'avatar'=>$f['avatar'],
                            'mobile'=>$f['mobile'],
                            'name'=>$f['name'],
                            'userid'=>$f['userid']
                        ];
                    }
                }
    
                if(!empty($vs['sub'])){
                    foreach ($vs['sub'] as $p=>$q){
                        $send['dept_id']=(int)$q['dept_id'];
                        $datas=$this->curl($url,$send);
                        $rows=json_decode($datas,true);
                        $diff=$rows['result']['list'];
                        foreach ($diff as $w=>$e){
                            $list[$ks]['sub'][$p]['people'][$w]=[
                                'avatar'=>$e['avatar'],
                                'mobile'=>$e['mobile'],
                                'name'=>$e['name'],
                                'userid'=>$e['userid']
                            ];
                        }
                    }
                }
            }
            successReturn(200,'',$list);
        }else{
            successReturn(204);
        }
    }


    //根据uid获取用户信息
    public function userInfo($userid){
        $token=$this->getAccess();
        if($token!=false){
            $url=$this->config['userInfo'].'?access_token='.$token;
            $send['userid']=$userid;
            $data=$this->curl($url,$send);
            $row=json_decode($data,true);
            if($row['errcode']!=0){
                errorReturn(1030,$row['errmsg']);
            }else{
                $send=[
                    'avatar'=>$row['result']['avatar'],
                    'mobile'=>$row['result']['mobile'],
                    'name'=>$row['result']['name'],
                    'userid'=>$row['result']['userid']
                ];
                successReturn(200,'',$send);
            }
        }else{
            errorReturn(1020,'参数缺失');
        }
    }


    /**
     * 发送应用消息
     * @param $sort  (1为文本，2为卡片)
     * @param $type  (1为用户，2为部门，3为所有)
     * @param $ids   (id列表，逗号分隔)
     */
    public function sendAgentMsg($sort,$type,$ids,$content='',$title='',$urls=''){
        $token=$this->getAccess();
        if($token!=false) {
            $send['agent_id'] = $this->config['AgentId'];
            $url = $this->config['newsTell'] . '?access_token=' . $token;

            switch ($sort) {
                case 1:
                    $msg=[
                        'msgtype' => 'text',
                        "text" => [
                            "content" => $content
                        ]
                    ];
                    $send['msg'] = json_encode($msg,JSON_UNESCAPED_UNICODE);
                    break;

                case 2:
                    $msg=[
                        'msgtype' => 'action_card',
                        "action_card" => [
                            "title" => $title,
                            "markdown" => $content,
                            "single_title" => '查看详情',
                            "single_url" => $urls
                        ]
                    ];
                    $send['msg'] = json_encode($msg,JSON_UNESCAPED_UNICODE);
                    break;
            }

            switch ($type) {
                case 1:
                    $send['userid_list'] = $ids;
                    $send['to_all_user'] = 'false';
                    break;
                case 2:
                    $send['dept_id_list'] = $ids;
                    $send['to_all_user'] = 'false';
                    break;
                case 3:
                    $send['to_all_user'] = 'true';
                    break;
            }

            $data=$this->curl($url,$send);
            $row=json_decode($data,true);
            if($row['errcode']!=0){
                return $row['errmsg'];
            }else{
                return 'ok';
            }
        }else{
            return '参数缺失';
        }
    }


    /*
     * 钉钉扫码登录
     *4、利用第2步获取的code和第3步获取的token，去请求接口，得到一个持久码；
      5、利用第4步获取的持久码再去请求接口，得到一个SNS_TOKEN；
      6、利用第5步获取的SNS_TOKEN再去请求接口，得到userInfo的信息，然后解析就能拿到用户昵称。
     */
    public function dingCode($code){
        $appId=$this->config['loginAppKey'];
        $appSecret=$this->config['loginAppSecret'];
        //利用appkey和秘钥去获取token，这个token有效期为2小时
        $res1=$this->curl_get_https($this->config['AccessTokenUrl']."?appid=".$appId."&appsecret=".$appSecret);
        $new_res1=json_decode($res1,true);

        //利用扫码获取的code和第1步获取的token，去请求接口，得到一个持久码；
        $data1 = [
            'tmp_auth_code' => $code
        ];
        $data_string1 = json_encode($data1);
        $res2=$this->curl_post_https($this->config['PersistentCodeUrl']."?access_token=".$new_res1['access_token'],$data_string1);
        $new_res2=json_decode($res2,true);

        //利用第4步获取的持久码再去请求接口，得到一个SNS_TOKEN；
        $data2 = [
            'openid' => $new_res2['openid'],
            'persistent_code' => $new_res2['persistent_code']
        ];
        $data_string2 = json_encode($data2);
        $res3=$this->curl_post_https($this->config['SnsTokenUrl']."?access_token=".$new_res1['token'],$data_string2);
        $new_res3=json_decode($res3,true);

        //利用第3步获取的SNS_TOKEN再去请求接口，得到userInfo的信息，然后解析就能拿到用户昵称。
        $res4=$this->curl_get_https($this->config['UserInfoUrl']."?sns_token=".$new_res3['sns_token']);
        $new_res4=json_decode($res4,true);

        successReturn(200,'',$new_res4);
    }


    function curl_post_https($url,$data_string){ // 模拟提交数据函数
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array ('Content-Type: application/json;charset=utf-8'));
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        // 线下环境不用开启curl证书验证, 未调通情况可尝试添加该代码
        curl_setopt ($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt ($ch, CURLOPT_SSL_VERIFYPEER, 0);
        $res = curl_exec($ch);
        curl_close($ch);
        return $res; // 返回数据，json格式
    }

    function curl_get_https($url){
        $curl = curl_init(); // 启动一个CURL会话
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_HEADER, 0);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false); // 跳过证书检查
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, true);  // 从证书中检查SSL加密算法是否存在
        $tmpInfo = curl_exec($curl);     //返回api的json对象
        //关闭URL请求
        curl_close($curl);
        return $tmpInfo;    //返回json对象
    }

    //post请求
    public function curl($url, $postFields = null){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_FAILONERROR, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        //https 请求
        if(strlen($url) > 5 && strtolower(substr($url,0,5)) == "https" ) {
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        }

        if (is_array($postFields) && 0 < count($postFields)) {
            $postBodyString = "";
            foreach ($postFields as $k => $v) {
                $postBodyString .= "$k=" . urlencode($v) . "&";
            }
            unset($k, $v);
            curl_setopt($ch, CURLOPT_POST, true);

            $header = array("content-type: application/x-www-form-urlencoded; charset=UTF-8");
            curl_setopt($ch,CURLOPT_HTTPHEADER,$header);
            curl_setopt($ch, CURLOPT_POSTFIELDS, substr($postBodyString,0,-1));
        }

        //3.采集
        $output = curl_exec($ch);
        //4.关闭
        curl_close($ch);
        return $output;
    }
}
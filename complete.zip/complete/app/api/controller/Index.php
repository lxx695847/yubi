<?php
/**
 * Created by PhpStorm.
 * User: GG
 * Date: 2018/6/19
 * Time: 10:27
 */
namespace app\api\controller;
use think\Hook;

class Index extends Base{
    public function index(){
        $arr=[
           'name'=>'alex',
           'age'=>18,
           'sex'=>2
        ];
        $new=base64_encode(json_encode($arr));
        return view('Index/index',['new'=>$new]);
    }

    /**
     * 小游戏（拼图）提交返回
     * @method post
     */
    public function sendResult(){
        try{
            $access=input("param.access");
            $area=input("param.area");
            Hook::exec('app\\api\\behavior\\Check','run',$area);
            if($area==2){
                Hook::exec('app\\api\\behavior\\Check','run',$access);
                //签名解密
                $infos=desSigns($access);
                Hook::exec('app\\api\\behavior\\Check','checkAccess',$infos);
                $sign=input("param.sign");
                Hook::exec('app\\api\\behavior\\Check','run',$sign);
                $procedure=json_decode(base64_decode($sign),true);
                if($procedure==false){
                    $procedure=[];
                }
                model('api/Index')->getPuzzle($area,$infos,$procedure);
            }else{
                if($access){
                    //签名解密
                    $infos=desSigns($access);
                    Hook::exec('app\\api\\behavior\\Check','checkAccess',$infos);
                    model('api/Index')->getPuzzle($area,$infos);
                }else{
                    model('api/Index')->getPuzzle($area);
                }
            }
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }

    /**
     * 小游戏排行榜
     * @method post
     */
    public function getRank(){
        try{
            $type=input('param.type');
            Hook::exec('app\\api\\behavior\\Check','run',$type);
            if($type==2){
                $access=input('param.access');
                Hook::exec('app\\api\\behavior\\Check','run',$access);

                //签名解密
                $infos=desSigns($access);
                Hook::exec('app\\api\\behavior\\Check','checkAccess',$infos);
                model('api/Index')->myRank($infos);
            }else{
                model('api/Index')->myRank();
            }
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }


    /**
     * 组队信息查询
     * area(1为组队，2为明信片,3为明信片记录)
     */
    public function getGroup(){
        try{
            $area=input('param.area');
            Hook::exec('app\\api\\behavior\\Check','run',$area);
            if($area==1 || $area==3){
                $access=input('param.access');
                Hook::exec('app\\api\\behavior\\Check','run',$access);

                //签名解密
                $infos=desSigns($access);
                Hook::exec('app\\api\\behavior\\Check','checkAccess',$infos);
                model('api/Index')->myGroup($area,$infos);
            }else{
                model('api/Index')->myGroup($area);
            }
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }


    /**
     * 明信片提交返回
     * @method Post
     * @param result(json结果字符串)
     */
    public function cardResult(){
        try{
            $result=input('param.result');
            $access=input('param.access');
            $tag=[$result,$access];
            Hook::exec('app\\api\\behavior\\Check','run',$tag);

            //签名解密
            $infos=desSigns($access);
            Hook::exec('app\\api\\behavior\\Check','checkAccess',$infos);
            model('api/Index')->myCard($result,$infos);
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }


    /**
     * 分享状态修改
     */
    public function editState(){
        try{
            $access=input("param.access");
            $title = input('param.title');
            $sign=input('param.sign');
            $tag=[$access,$sign,$title];
            Hook::exec('app\\api\\behavior\\Check','run',$tag);
            //签名解密
            $infos=desSigns($access);
            Hook::exec('app\\api\\behavior\\Check','checkAccess',$infos);

            $signs=desSigns($sign);
            Hook::exec('app\\api\\behavior\\Check','checkAccess',$signs);
            model('api/Index')->setState($signs,$title);
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }


    /**
     * 拼图随机排序
     */
    public function test(){
        $access=input("param.access");
        $base=config('puzzle');
        $num=count($base);
        $infos=[];
        $ins = mt_rand(0,$num-1);
        $puzzle_Index=cache('puzzle_Index');
        if($access) {
            //签名解密
            $infos = desSigns($access);
            Hook::exec('app\\api\\behavior\\Check', 'checkAccess', $infos);
        }
        if($puzzle_Index==false){
            cache('puzzle_Index',$ins);
            if(!empty($infos)){
                cache("puzzle".$infos['uid'], serialize([
                    'sort' => $base[$ins],
                    'start' => round(microtime(true), 3) * 1000
                ]));
            }
            successReturn(200,'',$base[$ins]);
        }else{
            if($puzzle_Index==$ins){
              $this->test();
            }else{
                cache('puzzle_Index',$ins);
            }
            if(!empty($infos)){
                cache("puzzle".$infos['uid'], serialize([
                    'sort' => $base[$ins],
                    'start' => round(microtime(true), 3) * 1000
                ]));
            }
            successReturn(200,'',$base[$ins]);
        }
    }

    public function getExam($data){
        //材质
        $copy1=db('lv_bags_copy1');
        $arr=explode(',',$data);
        $tip=[];
        foreach ($arr as $k=>$v){
            $po=explode('@',$v);
            $arr[$k]=[
               'pid'=>$po[0],
               'sku'=>$po[1],
               'color'=>$po[2]
            ];
        }

        foreach ($arr as $ks=>$vs){
            $tip[$vs['pid']][]=[
                'sku'=>$vs['sku'],
                'color'=>$vs['color']
            ];
        }

        foreach ($tip as $bb=>$hh){
            $kind=$copy1->where(['is_show'=>2,'pid'=>$bb])->value('kind');
            $tu = json_decode($kind, true);
            foreach ($hh as $oo=>$uu){
                foreach ($tu as $kk => $ss) {
                    if($uu['sku']==$ss['skuId']){
                        $tu[$kk]['color'] = $uu['color'];
                    }
                }
            }
            $copy1->where(['pid'=>$bb])->setField('kind',json_encode($tu,JSON_UNESCAPED_UNICODE));
        }



        // 大文件切割上传，把每次上传的数据合并成一个文件
//        $file='resource';
//        $filename = './upload/upload.wmv';//确定上传的文件名
//        //第一次上传时没有文件，就创建文件，此后上传只需要把数据追加到此文件中
//        if(!file_exists($filename)){
//            move_uploaded_file($_FILES[$file]['tmp_name'],$filename);
//        }else{
//            file_put_contents($filename,file_get_contents($_FILES[$file]['tmp_name']),FILE_APPEND);
//        }
//        $info=db('element_detail');
//        for($i=1;$i<=22;$i++){
//            $data=file_get_contents('Uploads/json/'.$i.'.json');
//            $row=json_decode($data,true);
//            $send=[
//                'eid'=>$i+105,
//                'base'=>json_encode($row['base']),
//                'physics'=>json_encode($row['physics']),
//                'contain'=>json_encode($row['contain']),
//                'electro'=>json_encode($row['electro']),
//                'atomic'=>json_encode($row['atomic']),
//                'crystal'=>json_encode($row['crystal']),
//                'nuclear'=>json_encode($row['nuclear']),
//                'extra'=>json_encode($row['extra'])
//            ];
//            $info->insert($send);
//        }

//            $data=file_get_contents('Uploads/json/111.json');
//            $row=json_decode($data,true);
//            foreach ($row['list'] as $k=>$v){
//                echo "<pre/>";
//                echo json_encode($v);
//            }
    }


    //文件md5检查
    public function checkFileExist(){
        $md5 = $_POST["md5"];
        //验证结果
        $exist = 0;
        //切换目录
        chdir($_SERVER["DOCUMENT_ROOT"]."/Uploads/Large");
        //遍历该目录下的所有文件
        foreach(glob('*.*') as $filename) {
            //计算每个文件的md5值并判读
            if (strcmp($md5, md5_file($filename)) == 0){
                $exist = 1;
                break;
            }
        }
        echo $exist;
    }


    //文件上传
    public function uploadFile(){
        $start=time();
        //获取文件名
        $name = $_POST["name"];
        //获取大小
        $size = $_POST["size"];
        //获取文件类型
        $type = $_POST["type"];

        //将上传的文件保存到指定目录下
        $res=move_uploaded_file(
            $_FILES["file"]["tmp_name"], $_SERVER["DOCUMENT_ROOT"] . "/Uploads/Large/" . $name
        );

        if($res){
            $cost=time()-$start;
            $info="文件". $name . $type."上传完毕,共计".$size.",用时“".$cost;
            successReturn(200,$info);
        }
    }
}




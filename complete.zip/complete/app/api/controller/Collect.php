<?php
namespace app\api\controller;
use think\Image;
//require_once('vendor/autoload.php');
use Upyun\Upyun;
use Upyun\Config;


class Collect extends Base {
    //视频操作相关
    public function getPro(){
        $save_file_url=ROOT_PATH . 'public' . DS .'ygz.mp4';
        $ffmpeg = \FFMpeg\FFMpeg::create(
            [
                'ffmpeg.binaries'  => '/usr/local/ffmpeg/ffmpeg',
                'ffprobe.binaries' => '/usr/local/ffmpeg/ffprobe'
            ]
        );

        //获取视频时长
        $ffProbe= \FFMpeg\ffProbe::create(
            [
                'ffmpeg.binaries'  => '/usr/local/ffmpeg/ffmpeg',
                'ffprobe.binaries' => '/usr/local/ffmpeg/ffprobe'
            ]
        );
        $send['time']=number_format($ffProbe->format($save_file_url)->get('duration',0)/60,2);  //获取视频时长
        $send['size']=number_format($ffProbe->format($save_file_url)->get('size',0)/1048576, 2); //获取视频大小

        $video = $ffmpeg->open($save_file_url);  //上传的文件地址

        //获取视频第一帧
        $frame = $video->frame(\FFMpeg\Coordinate\TimeCode::fromSeconds(1));//提取第1秒的图像
        $send['img']=md5(uniqid().rand(1,999)).".png";  //生成图片路径
        $frame->save($send['img']);
        //裁剪
        $image = Image::open($send['img']);
        $image->crop(1920, 1920);
        successReturn(200,'',$send);
    }


    //又拍云文件操作(上传)
    public function upyUploads(){
        $serviceConfig = new Config('guangzi-video','guangzi','vbZoqxsKp39qTR2EyXVzLbrwhvca4pme');
        $client = new Upyun($serviceConfig);
        $save_file_url=ROOT_PATH . 'public' . DS .'ygz.mp4';
        //要上传到哪个目录下
        $directory = '/cms';
        $key = basename($save_file_url);
        if($directory){
            //真正使用时，$directory可能是用户传过来的，在不知道用户是否写了右斜杠的情况下，统一先去掉再添加一个
            $key = rtrim($directory, '/') . '/' . $key;
        }

        $file = fopen($save_file_url, 'r');
        $client->write($key, $file);
    }
}
<?php
namespace app\api\controller;
use think\Hook;
use sms\SmsSingleSender;

class Ys extends Base{
    /**
     * @method post
     * 手机号验证码
     */
    public function sendSms(){
        $phone=input('post.phone');
        Hook::exec('app\\api\\behavior\\Check','run',$phone);
        $phoneNumbers=base64_decode($phone);
        $res=checkPhone($phoneNumbers);
        if($res==true) {
            try {
                $leave=(int)(strtotime(date('Y-m-d',time()))+24*3600-1)-time();  //当天剩余时间
                if($leave<=0){
                    cache("code".getClientIP(), NULL);
                    cache("code".$phoneNumbers, NULL);
                }
                //防刷机制 (ip)
                $ipCount=cache("code".getClientIP());
                if($ipCount!=false){
                    if($ipCount>100){
                        errorReturn(1030,'不可频繁操作,明日再申请');
                    }else{
                        $ipCount++;
                        cache("code".getClientIP(),$ipCount,$leave);
                    }
                }else{
                    cache("code".getClientIP(),1,$leave);
                }

                //(验证次数)
                $num=cache("code".$phoneNumbers);
                if($num!=false){
                    $lom=unserialize($num);
                    if($lom['total']==false){
                        errorReturn(1020,'今日手机验证次数不足，明日再来');
                    }else{
                        if(time()-$lom['sendTime']<60){
                            errorReturn(1030,'不可频繁发送验证码');
                        }else{
                            $kos=[
                                'total'=>$lom['total']--,
                                'sendTime'=>time()
                            ];
                            cache("code".$phoneNumbers,serialize($kos),$leave);
                        }
                    }
                }else{
                    $kos=[
                        'total'=>19,
                        'sendTime'=>time()
                    ];
                    cache("code".$phoneNumbers,serialize($kos),$leave);
                }

                $param=[getRand(),1];  //验证码
                $ssender = new SmsSingleSender(config("sms.appid"), config("sms.appkey"));
                $result = $ssender->sendWithParam("86",$phoneNumbers,config("sms.templateId"),
                    $param,config("sms.smsSign"), "", "");
                $rsp = json_decode($result,true);
                if($rsp['result']!=false){
                        errorReturn($rsp['result'],$rsp['errmsg']);
                }else{
                    cache("sms".$phoneNumbers,$param[0],5*60);
                    successReturn(200);
                }
            } catch(\Exception $e) {
                errorReturn(1050,$e->getMessage());
            }
        }else{
            errorReturn(1060,'手机号格式不正确');
        }
    }

    /**
     * @param $phone
     * @method post
     * 检测手机号注册/登录
     */
    public function meLogin(){
        try{
            $tel=input("post.phone");
            $codes=input("post.code");
            $tag=[$tel,$codes];
            Hook::exec('app\\api\\behavior\\Check','run',$tag);
            $phone=base64_decode($tel);
            $code=base64_decode($codes);
            $res=checkPhone($phone);
            if($res==true){
                model('api/Ys')->login_check($phone,$code);
            }else{
                errorReturn(1060,'手机号格式不正确');
            }
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }
}
<?php
namespace app\api\controller;
use think\Hook;
use lib\upload;
define("svp","http://".$_SERVER['HTTP_HOST']."/Uploads/");

class Element extends Base{
    //基础信息
    public function elementInfo(){
        try{
            $sort=db('element_sort')->where(['area'=>1])->select();
            $element_info=db('element_info');
            $row=$element_info
                ->alias('a')
                ->field('a.id,a.group,a.line,a.position,a.small,a.zn_name,a.number,b.explain')
                ->join('element_sort b','a.group=b.title')
                ->order('a.id asc')
                ->where(['a.is_normal'=>1])
                ->select();

            $res=db('element_info')
                ->alias('a')
                ->field('a.*,b.*')
                ->order('a.id asc')
                ->join('element_detail b','a.id=b.eid')
                ->select();
            foreach ($res as $k=>$v){
                $res[$k]['base']=json_decode($v['base'],true);
                $res[$k]['physics']=json_decode($v['physics'],true);
                $res[$k]['contain']=json_decode($v['contain'],true);
                $res[$k]['electro']=json_decode($v['electro'],true);
                $res[$k]['atomic']=json_decode($v['atomic'],true);
                $res[$k]['crystal']=json_decode($v['crystal'],true);
                $res[$k]['nuclear']=json_decode($v['nuclear'],true);
                $res[$k]['extra']=json_decode($v['extra'],true);
                $res[$k]['other']=json_decode($v['other'],true);
            }
            successReturn(200,"",[
                'sort'=>$sort,
                'base'=>$row,
                'detail'=>$res
            ]);
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }

    //列表
    public function elementList(){
        $list=[];
        $row=db('element_info')->alias('a')
            ->field('a.id,a.number,a.small,a.zn_name,a.group,b.physics,b.extra,b.atomic,b.other')
            ->join('element_detail b','a.id=b.eid')
            ->order('a.id asc')
            ->where(['a.is_normal'=>1])
            ->select();

        foreach ($row as $k=>$v){
            $physics=json_decode($v['physics'],true);
            $extra=json_decode($v['extra'],true);
            $atomic=json_decode($v['atomic'],true);
            $other=json_decode($v['other'],true);
            $list[$k]=[
                'id'=>$v['id'],
                'number'=>$v['number'],
                'small'=>$v['small'],
                'zn_name'=>$v['zn_name'],
                'group'=>$v['group'],
                'elementMasses'=>$physics[3]['elementMasses'] ? $physics[3]['elementMasses'] : 0,
                'electronegativity'=>$physics[7]['electronegativity'] ? $physics[7]['electronegativity'] : 0,
                'elementDensity'=>$physics[2]['elementDensity'] ? $physics[2]['elementDensity'] : 0,
                'soundSpeed'=>$physics[0]['soundSpeed'] ? $physics[0]['soundSpeed'] : 0,
                'electron'=>$other[0]['electron'] ? $other[0]['electron'] : 0,
                'proton'=>$other[1]['proton'] ? $other[1]['proton'] : 0,
                'neutron'=>$other[2]['neutron'] ? $other[2]['neutron'] : 0,
                'atomicRadius'=>$atomic[0]['atomicRadius'] ? $atomic[0]['atomicRadius'] : 0,
                'covalentRadius'=>$atomic[1]['covalentRadius'] ? $atomic[1]['covalentRadius'] : 0,
                'vanDerWaalsRadius'=>$atomic[5]['vanDerWaalsRadius'] ? $atomic[5]['vanDerWaalsRadius'] : 0,
                'brinellHardness'=>$extra[1]['brinellHardness'] ? $extra[1]['brinellHardness'] : 0,
                'mohsHardness'=>$extra[2]['mohsHardness'] ? $extra[2]['mohsHardness'] : 0,
                'vickersHardness'=>$extra[3]['vickersHardness'] ? $extra[3]['vickersHardness'] : 0,
                'bulkModulus'=>$extra[4]['bulkModulus'] ? $extra[4]['bulkModulus'] : 0,
                'youngModulus'=>$extra[5]['youngModulus'] ? $extra[5]['youngModulus'] : 0,
                'shearModulus'=>$extra[6]['shearModulus'] ? $extra[6]['shearModulus'] : 0,
                'liquidDensity'=>$extra[7]['liquidDensity'] ? $extra[7]['liquidDensity'] : 0,
                'molarVolume'=>$extra[8]['molarVolume'] ? $extra[8]['molarVolume'] : 0,
                'heatConductivity'=>$extra[11]['heatConductivity'] ? $extra[11]['heatConductivity'] : 0
            ];
        }

        $percent=[
            'elementMasses'=>$this->getProgress($list,"elementMasses"),
            'electronegativity'=>$this->getProgress($list,"electronegativity"),
            'elementDensity'=>$this->getProgress($list,"elementDensity"),
            'soundSpeed'=>$this->getProgress($list,"soundSpeed"),
            'electron'=>$this->getProgress($list,"electron"),
            'proton'=>$this->getProgress($list,"proton"),
            'neutron'=>$this->getProgress($list,"neutron"),
            'atomicRadius'=>$this->getProgress($list,"atomicRadius"),
            'covalentRadius'=>$this->getProgress($list,"covalentRadius"),
            'vanDerWaalsRadius'=>$this->getProgress($list,"vanDerWaalsRadius"),
            'brinellHardness'=>$this->getProgress($list,"brinellHardness"),
            'mohsHardness'=>$this->getProgress($list,"mohsHardness"),
            'vickersHardness'=>$this->getProgress($list,"vickersHardness"),
            'bulkModulus'=>$this->getProgress($list,"bulkModulus"),
            'youngModulus'=>$this->getProgress($list,"youngModulus"),
            'shearModulus'=>$this->getProgress($list,"shearModulus"),
            'liquidDensity'=>$this->getProgress($list,"liquidDensity"),
            'molarVolume'=>$this->getProgress($list,"molarVolume"),
            'heatConductivity'=>$this->getProgress($list,"heatConductivity"),
        ];

        successReturn(200,'',['list'=>$list,'percent'=>$percent]);
    }


    function getProgress($list,$word){
        $row=array_column($list,$word);
        $max=max($row);
        $percent=[];
        foreach ($row as $ks=>$vs){
            if((int)$vs===0){
                array_push($percent,['percent'=>0,'index'=>$ks]);
            }else{
                array_push($percent,['percent'=>round($vs/$max*100,2),'index'=>$ks]);
            }
        }
        return $percent;
    }



    //后台相关
    /**
     * 登录
     */
    public function account(){
        $username=input('post.username');
        $pwd=input('post.password');
        $where['user']=$username;
        $res=db('user')->where($where)->find();
        if($res!=false){
            if($res['status']==2){
                $data=pwdAct(2,$pwd,$res['pwd']);
                if($data!==false){
                    successReturn(200,'',$res['id']);
                }else{
                    errorReturn(1002,'账号密码不正确,请确认后重试！');
                }
            }else{
                errorReturn(1001,'用户已被禁用');
            }
        }else{
            errorReturn(1003,'该用户不存在,如有需求请联系管理员添加');
        }
    }

    /**
     * 账户信息
     */
    public function currentUser(){
        $data=[
            'success'=> true,
            'data'=>[
                'name'=> 'Serati Ma',
                'avatar'=> 'https://gw.alipayobjects.com/zos/antfincdn/XAosXuNZyF/BiazfanxmamNRoxxVxka.png',
                'userid'=> '00000001',
                'email'=> 'antdesign@alipay.com',
                'signature'=> '海纳百川，有容乃大',
                'title'=> '交互专家',
                'group'=> '蚂蚁金服－某某某事业群－某某平台部－某某技术部－UED',
                'tags'=> [
                  [
                    'key'=> '0',
                    'label'=> '很有想法的'
                  ],
                  [
                      'key'=> '1',
                      'label'=>'专注设计',
                  ],
                ],
                'notifyCount'=> 12,
                'unreadCount'=> 11,
                'country'=> 'China',
                'geographic'=> [
                    'province'=> [
                        'label'=> '浙江省',
                        'key'=> '330000',
                    ],
                    'city'=> [
                        'label'=> '杭州市',
                        'key'=> '330100',
                    ]
                ],
                'address'=> '西湖区工专路 77 号',
                'phone'=> '0752-268888888'
            ]
        ];
        echo json_encode($data);
        exit;
        // $uid=input('post.uid');
        // Hook::exec('app\\api\\behavior\\Check','run',$uid);
        // $info=db('user')->where(['id'=>$uid])->find();
        // if($info){
        //     successReturn(200,'',$info);
        // }else{
        //     errorReturn('当前用户不存在');
        // }
    }

    /**
     * 获取用户所有权限
     * @check $user_id
     * @return string
     */
    public function getUserRules($user_id){
        $where['a.uid']=$user_id;
        //根据用户id获取权限规则
        $rules = db('auth_group_access')->alias('a')
            ->join('auth_group c','c.id=a.group_id','LEFT')   //默认为inner
            ->field('c.rules')
            ->where($where)
            ->find();
        if($rules!==false){
            $menu = self::getMenus($rules['rules']);
            //根据规则id递归菜单栏目
            return  get_column($menu);
        }
    }

    /**
     * 根据规则id数组获取菜单
     * @check  $rules_arr
     * @return array
     */
    public function getMenus($rules_arr)
    {
        $where = array(
            'id' => array('in', $rules_arr),
            'status' => 1,
            'is_menu'=>2
        );
        return db('auth_rule')->where($where)->order('sort asc')->select();
    }




    /**
     * app版本升级
     */
    public function getVersion(){
        try{
            $appid=input("post.appid");
            $system=input("post.system");
            $id=db('app')->where(['appid'=>$appid])->value('id');
            if($id){
                $opt=[
                    'aid'=>$id,
                    'system'=>$system
                ];
                $res=db('release')->order('pub_time desc')->limit(1)->where($opt)->find();
                if($res){
                    $res['update']=8;  //数据更新字段
                    successReturn(200,'',$res);
                }else{
                    successReturn(204);
                }
            }else{
                errorReturn(500,'参数错误');
            }
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }



    /**
     * 后台相关
     */
    public function appList(){
        try{
            $param=input('get.');
            $opt['id']=['gt',0];
            $page= isset($param['current']) ? $param['current'] : 1;
            $pageSize= isset($param['pageSize']) ? $param['pageSize'] : 20;
            if(isset($param['apps'])){
                $opt['apps']=['like', "%" . $param['apps'] . "%"];
            }
            if(isset($param['state'])){
                $opt['state']=$param['state'];
            }

            $release=db('release');
            $res=db('app')->where($opt)->page($page,$pageSize)->select();
            foreach ($res as $k=>$v){
                $opt1=['aid'=>$v['id'], 'system'=>2];
                $opt2=['aid'=>$v['id'], 'system'=>1];
                $res[$k]['icon']=svp.$v['icon'];
                $res[$k]['times']=date("Y-m-d",$v['times']);
                $res[$k]['and_version']=$release->order('pub_time desc')->limit(1)->where($opt1)->value('version');
                $res[$k]['ios_version']=$release->order('pub_time desc')->limit(1)->where($opt2)->value('version');
            }
            $res ?  successReturn(200,"",$res) : successReturn(204);
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }

    //用户
    public function getUsers(){
        try{
            $param=input('get.');
            $opt['id']=['gt',0];
            $page= isset($param['current']) ? $param['current'] : 1;
            $pageSize= isset($param['pageSize']) ? $param['pageSize'] : 20;
            if(isset($param['phone'])){
                $opt['phone']=['like', "%" . $param['phone'] . "%"];
            }
            if(isset($param['area'])){
                $opt['area']=$param['area'];
            }
            $res=db('dream_user')->where($opt)->page($page,$pageSize)->select();

            $res ?  successReturn(200,"",$res) : successReturn(204);
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }

    //应用版本
    public function appVersion(){
        try{
            $aid=input('post.aid');
            Hook::exec('app\\api\\behavior\\Check','run',$aid);
            $param=input('post.');
            $opt['aid']=$aid;
            $page= isset($param['current']) ? $param['current'] : 1;
            $pageSize= isset($param['pageSize']) ? $param['pageSize'] : 20;
            if(isset($param['apps'])){
                $opt['b.apps']=['like', "%" . $param['apps'] . "%"];
            }
            if(isset($param['system'])){
                $opt['a.system']=$param['system'];
            }
            if(isset($param['ups'])){
                $opt['a.ups']=$param['ups'];
            }
            $res=db('release')
                ->alias('a')
                ->field('a.*,b.apps')
                ->join('app b','a.aid=b.id')
                ->where($opt)
                ->page($page,$pageSize)
                ->select();
            $res ?  successReturn(200,"",$res) : successReturn(204);
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }

    //版本编辑
    public function appEdit(){
        try{
            if(request()->isGet()){
                $id=input('get.id');
                Hook::exec('app\\api\\behavior\\Check','run',$id);
                $res=db('app')->where(['id'=>$id])->find();
                if($res){
                    successReturn(200,'',$res);
                }else{
                    errorReturn(1030,'参数错误');
                }
            }else{
                $id=input('post.id');
                Hook::exec('app\\api\\behavior\\Check','run',$id);
                $param=input('post.');
                $data=[
                    'apps'=>$param['apps'],
                    'ios_package'=>$param['ios_package'],
                    'android_package'=>$param['android_package']
                ];

                if($param['up']==2){
                    $upload=new upload();
                    $lit=$upload->get_upload('pic','myApp/'.time());
                    if($lit['status']==1){
                        errorReturn(1020,$lit['info']);
                    }else{
                        $data['icon']=$lit['info'];
                    }
                }
                $res=db('app')->where(['id'=>$param['id']])->update($data);
                check($res,2);
            }
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }

    public function verEdit(){
        try{
            $release=db('release');
            if(request()->isGet()){
                $id=input('get.id');
                $aid=input('get.aid');
                $tag=[$id,$aid];
                Hook::exec('app\\api\\behavior\\Check','run',$tag);
                $opt=['id'=>$id];
                $res=$release->where($opt)->find();
                $res['apps']=db('app')->where(['id'=>$aid])->value('apps');
                $res['min']=$release->where(['aid'=>$aid])->group('version')->column('version');
                $lin=explode("@",$res['info']);
                $tiff="";
                foreach ($lin as $k=>$v){
                    $tiff.=$v."。";
                }
                $res['info']=$tiff;
                if($res){
                    successReturn(200,'',$res);
                }else{
                    errorReturn(1030,'参数错误');
                }
            }else{
                $param = input('post.');
                $data = [
                    'version'=>$param['version'],
                    'system'=>$param['system']=='IOS' ? 1 : 2,
                    'info'=>str_replace('\n','@',$param['info']),
                    'minVersion'=>$param['min'],
                    'ups'=>$param['ups'],
                    'release'=>$param['release'],
                    'release_time'=>isset($param['release_time']) ? strtotime($param['release_time']) : time()
                ];

                switch($param['system']){
                    case 'ios':
                        $data['store']=$param['store'];
                        break;
                    case 'android':
                        if($param['up']==2){
                            $upload=new upload();
                            $package=db('app')->where(['id'=>$param['aid']])->value('android_package');
                            $lit=$upload->get_upload('package','myapp/v'.$param['version'],2,$package);
                            if($lit['status']==1){
                                errorReturn(1020,$lit['info']);
                            }else{
                                $data['package']=$lit['info'];
                            }
                        }
                        break;
                }
                $res = $release->where(['id'=>$param['id']])->update($data);
                check($res, 1);
            }
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }

    //版本删除
    public function appDel(){
        try{
            $id=input('post.id');
            $area=input('post.area');
            $tag=[$id,$area];
            Hook::exec('app\\api\\behavior\\Check','run',$tag);
            $release=db('release');
            $app=db('app');
            switch ($area){
                case 1:
                    $opt['id']=$id;
                    $img=$app->where($opt)->value('icon');
                    if($img){
                        unlink(vip.$img);
                    }
                    $res=$app->where($opt)->delete();
                    $release->where(['aid'=>$id])->delete();   //版本删除
                    check($res,3);
                    break;
                case 2:
                    $opt1['id']=['in',explode(",",$id)];
                    $opt2['aid']=['in',explode(",",$id)];
                    $app->where($opt1)->delete();
                    $release->where($opt2)->delete();
                    break;
            }
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }

    public function verDel(){
        try{
            $id=input('post.id');
            $area=input('post.area');
            $tag=[$id,$area];
            $release=db('release');
            Hook::exec('app\\api\\behavior\\Check','run',$tag);
            switch ($area){
                case 1:
                    $opt['id']=$id;
//                    $package=$release->where($opt)->value('package');
//                    if($package){
//                        unlink(vip.$package);
//                    }
                    $res=$release->where($opt)->delete();
                    check($res,3);
                    break;
                case 2:
                    $opt1['id']=['in',explode(",",$id)];
                    $release->where($opt1)->delete();
                    break;
            }
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }


    //应用新增
    public function appAdd(){
        try{
            $upload=new upload();
            $param = input('post.');
//            mkdir("./Uploads/android/".$param['android_package'],0777,true);
//            chmod( "./Uploads/android/".$param['android_package'],0777);
            $data = [
                'apps' => $param['apps'],
                'ios_package' => $param['ios_package'],
                'android_package' => $param['android_package'],
                'times' => time(),
                'appid' => '78game' . getToken(1)
            ];

            $lit=$upload->get_upload('pic','myApp/'.time());
            if($lit['status']==1){
                errorReturn(1020,$lit['info']);
            }else{
                $data['icon']=$lit['info'];
                $res = db('app')->insert($data);
                check($res, 1);
            }
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }

    //版本添加
    public function verAdd(){
        try{
            $release=db('release');
            if(request()->isGet()) {
                $aid=input('get.aid');
                Hook::exec('app\\api\\behavior\\Check','run',$aid);
                $apps=db('app')->where(['id'=>$aid])->value('apps');
                $minVersion=$release->where(['aid'=>$aid])->group('version')->column('version');
                if($apps){
                    successReturn(200,'',['apps'=>$apps,'min'=>$minVersion]);
                }else{
                    errorReturn(1030,'参数错误');
                }
            }else {
                $param = input('post.');
                $opt=[
                    'aid'=>$param['aid'],
                    'system'=>$param['system'],
                    'version'=>$param['version']
                ];
                $dos=$release->where($opt)->find();
                if($dos){
                    errorReturn(1030,'该应用平台已有相关版本，不可重复提交');
                }else{
                    $data = [
                        'version'=>$param['version'],
                        'system'=>$param['system'],
                        'ups'=>$param['ups'],
                        'info'=>str_replace('\n','@',$param['info']),
                        'minVersion'=>$param['min'],
                        'release_time'=>isset($param['release_time']) ? strtotime($param['release_time']) : time(),
                        'aid'=>$param['aid'],
                        'pub_time'=>time()
                    ];

                    switch($param['system']){
                        case 1:
                            $data['store']=$param['store'];
                            break;
                        case 2:
                            if($param['up']==2){
                                $upload=new upload();
                                $package=db('app')->where(['id'=>$param['aid']])->value('android_package');
                                $lit=$upload->get_upload('package','myapp/v'.$param['version'],2,$package);
                                if($lit['status']==1){
                                    errorReturn(1020,$lit['info']);
                                }else{
                                    $data['package']=$lit['info'];
                                }
                            }
                            break;
                    }
                    $res = $release->insert($data);
                    check($res, 1);
                }
            }
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }
}
<?php
namespace app\api\controller;
use think\Hook;
use sms\SmsSingleSender;
use lib\es;


class Dream extends Base{
    public function dreamLists(){
        $detail=db('dream');
        $sort=db('dream_sort')->select();
        $field=['id','title','detail'];

        $res=[
            'recommend'=>$detail->field($field)->order('recommend desc')->limit(20)->select(),
            'hotspot'=>$detail->field($field)->order('hotspot desc')->limit(20)->select(),
            'sort'=>get_menu($sort),
            'update'=>1
        ];
        successReturn(200,'',$res);
    }

    public function getScroll(){
        $detail=db('dream');
        $param=input("get.");
        $offset=20;
        $totalCount=$detail->count();
        $totalPage=ceil($totalCount/$offset);
        $hasNext= $param['page']<$totalPage ? true : false;
        $field=['id','title','detail'];

        $order="";
        switch ($param['area']){
            case 1:
                $order="recommend desc";
                break;
            case 2:
                $order="hotspot desc";
                break;
        }
        $row=[
           'detail'=>$detail->field($field)->order($order)->page($param['page'],$offset)->select(),
           'totalPage'=>$totalPage,
           'totalSize'=>$totalCount,
           'hasNext'=>$hasNext
        ];
        successReturn(200,'',$row);
    }

    //单个详情
    public function dreamDetail(){
        $id=input('get.id');
        Hook::exec('app\\api\\behavior\\Check','run',$id);
        $uid=input('get.uid');
        $res=db('dream')->where(['id'=>$id])->find();
        $res['detail']=explode("@",$res['detail']);
        if($uid){
            $user=db('dream_user');
            $opt['id']=$uid;
            $extra=$user->where($opt)->field('favor,praise,read')->find();
            $myRead=$this->actions($id,$extra['read']);
            if($myRead!=1){
                $read="";
                switch ($myRead){
                    case 2:
                        $read=$id;
                        break;
                    case 3:
                        $reads=explode(",",$extra['read']);
                        array_push($reads,$id);
                        $read=implode(',',$reads);
                        break;
                }
                $user->where($opt)->setField('read',$read);
            }
            $myFavor=$this->actions($id,$extra['favor']);
            $myPraise=$this->actions($id,$extra['praise']);
            $res['favor']=$myFavor==1 ? 2 : 1;
            $res['praise']=$myPraise==1 ? 2 : 1;
        }else{
            $res['favor']=1;
            $res['praise']=1;
        }
        successReturn(200,'',$res);
    }

    function actions($id,$word){
        $step=1;
        if($word==false){
            $step=2;
        }else{
            $new=explode(",",$word);
            if(array_search($id,$new)===false){
                $step=3;
            }
        }
        return $step;
    }

    //收藏和浏览记录
    public function dreamRecord(){
        $uid=input('get.uid');
        $area=input('get.area');
        $tag=[$area,$uid];
        Hook::exec('app\\api\\behavior\\Check','run',$tag);
        $opt['id']=$uid;
        $word="";
        switch ($area){
            case 1:
                $word="read";
                break;
            case 2:
                $word="favor";
                break;
        }
        $val=db('dream_user')->where($opt)->value($word);
        if($val==false){
            $res=[];
        }else{
            $ids=explode(',',$val);
            $ins['id']=['in',$ids];
            $res=db('dream')->where($ins)->select();
        }
        successReturn(200,'',$res);
    }

    public function  getEsTest(){
        $es=new es('articles');
        dump($es->search('白发',['title']));
    }

    //搜索
    public function dreamSearch(){
        $word=input('get.word');
        Hook::exec('app\\api\\behavior\\Check','run',$word);

        $opt['title']=['like','%'.$word.'%'];
        $res=db('dream')->where($opt)->select();
        successReturn(200,'',$res);
    }

    //用户操作更新
    public function userActs(){
        $favor=input('get.favor');
        $praise=input('get.praise');
        $id=input('get.id');
        $uid=input('get.uid');
        $tag=[$favor,$praise,$id,$uid];
        Hook::exec('app\\api\\behavior\\Check','run',$tag);
        $opt['id']=$uid;
        $opt1['id']=$id;
        $user=db('dream_user');
        $dream=db('dream');
        $extra=$user->where($opt)->field('favor,praise')->find();

        $myPraise=$this->actions($id,$extra['praise']);
        switch ($praise){
            case 1:
                if($myPraise==1){
                    $newPraise=explode(",",$extra['praise']);
                    array_splice($newPraise, array_search($id, $newPraise), 1);   //移除指定元素
                    $user->where($opt)->setField('praise',implode(',',$newPraise));
                    $dream->where($opt1)->setDec('hotspot');
                }
                break;
            case 2:
                if($myPraise!=1){
                    $praises="";
                    switch ($myPraise){
                        case 2:
                            $praises=$id;
                            break;
                        case 3:
                            $newPraise=explode(",",$extra['praise']);
                            array_push($newPraise,$id);
                            $praises=implode(',',$newPraise);
                            break;
                    }
                    $user->where($opt)->setField('praise',$praises);
                    $dream->where($opt1)->setInc('hotspot');
                }
                break;
        }

        $myFavor=$this->actions($id,$extra['favor']);
        switch ($favor){
            case 1:
                if($myFavor==1){
                    $newFavor=explode(",",$extra['favor']);
                    array_splice($newFavor, array_search($id, $newFavor), 1);   //移除指定元素
                    $user->where($opt)->setField('favor',implode(',',$newFavor));
                    $dream->where($opt1)->setDec('recommend');
                }
                break;
            case 2:
                if($myFavor!=1){
                    $favors="";
                    switch ($myFavor){
                        case 2:
                            $favors=$id;
                            break;
                        case 3:
                            $newFavor=explode(",",$extra['favor']);
                            array_push($newFavor,$id);
                            $favors=implode(',',$newFavor);
                            break;
                    }
                    $user->where($opt)->setField('favor',$favors);
                    $dream->where($opt1)->setInc('recommend');
                }
                break;
        }
    }

    //分类详情
    public function sortDetail(){
        $sid=input('get.sid');
        Hook::exec('app\\api\\behavior\\Check','run',$sid);
        $res=[];
        $detail=db('dream');
        $ids=db('dream_sort')->where(['pid'=>$sid])->column('id');
        foreach ($ids as $v){
            $list=$detail->where(['sid'=>$v])->limit(30)->select();
            foreach ($list as $vs){
                array_push($res,$vs);
            }
        }
        successReturn(200,'',$res);
    }

    //手机号验证码
    public function reports(){
        $phoneNumbers=input('post.phone');
        Hook::exec('app\\api\\behavior\\Check','run',$phoneNumbers);
        $res=checkPhone($phoneNumbers);
        if($res==true) {
            try {
                $leave=(int)(strtotime(date('Y-m-d',time()))+24*3600-1)-time();  //当天剩余时间
                if($leave<=0){
                    cache(getClientIP(), NULL);
                    cache($phoneNumbers, NULL);
                }
                //防刷机制 (ip)
                $ipCount=cache(getClientIP());
                if($ipCount!=false){
                    if($ipCount>100){
                        errorReturn(1030,'不可频繁操作,明日再申请');
                    }else{
                        $ipCount++;
                        cache(getClientIP(),$ipCount,$leave);
                    }
                }else{
                    cache(getClientIP(),1,$leave);
                }

                //(验证次数)
                $num=cache($phoneNumbers);
                if($num!=false){
                    $lom=unserialize($num);
                    if($lom['total']==false){
                        errorReturn(1020,'今日手机验证次数不足，明日再来');
                    }else{
                        if(time()-$lom['sendTime']<60){
                            errorReturn(1030,'不可频繁发送验证码');
                        }else{
                            $kos=[
                                'total'=>$lom['total']--,
                                'sendTime'=>time()
                            ];
                            cache($phoneNumbers,serialize($kos),$leave);
                        }
                    }
                }else{
                    $kos=[
                        'total'=>19,
                        'sendTime'=>time()
                    ];
                    cache($phoneNumbers,serialize($kos),$leave);
                }

                $param=[getRand(),1];  //验证码
                $ssender = new SmsSingleSender(config("sms.appid"), config("sms.appkey"));
                $result = $ssender->sendWithParam("86",$phoneNumbers,config("sms.templateId"),
                    $param,config("sms.smsSign"), "", "");
                $rsp = json_decode($result,true);
                if($rsp['result']!=false){
                    //错误码
                    errorReturn($rsp['result'],$rsp['errmsg']);
                }else{
                    cache($phoneNumbers."sms",$param[0],5*60);
                    successReturn(200);
                }
            } catch(\Exception $e) {
                errorReturn(1050,$e->getMessage());
            }
        }else{
            errorReturn(1060,'手机号格式不正确');
        }
    }

    //登录注册
    public function logins(){
        try{
            $phone=input("post.phone");
            $code=input("post.code");
            $tag=[$phone,$code];
            Hook::exec('app\\api\\behavior\\Check','run',$tag);
            $res=checkPhone($phone);
            if($res==true){
                model('api/Wish')->login_check($phone,$code);
            }else{
                errorReturn(1060,'手机号格式不正确');
            }
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }

    /**
     * 一键登陆
     */
    public function univerify(){
        try{
            $phone=input("post.phone");
            Hook::exec('app\\api\\behavior\\Check','run',$phone);
            $res=checkPhone($phone);
            if($res==true){
                model('api/Wish')->other_login($phone);
            }else{
                errorReturn(1060,'手机号格式不正确');
            }
        }catch (\Exception $e){
            errorReturn(500,$e->getMessage());
        }
    }
}
<?php
namespace app\index\controller;
use think\Controller;
use think\Request;

Vendor('Weixinpay.Weixinpay');
vendor('Alipay.alipay');
Vendor('Alipay.AlipayTradeService');

class Pay extends Controller{
    protected $wxpay;
    protected $alipay;
    public function __construct(Request $request = null){
        parent::__construct($request);
        $this->wxpay=new \Weixinpay();
        $this->alipay=new \alipay();
    }

    //生成微信支付二维码
    public function wxpay(){
        $orderno = input('param.orderno'); //订单号
        $info = getorderbyno($orderno); //订单详情
        if($info){
            if ($info['state'] == 1) {
                $order = array(
                    'body'         => '老周易',
                    'total_fee'    => $info['price'] * 100, //分
                    'out_trade_no' => strval($orderno),   //获取变量的字符串值
                    'product_id'   => $info['id'],
                    'trade_type'   => input('param.trade_type')
                );

                if (Mobile_Detect()->isMobile()) {
                    $this->wxpay->mweb($order);
                } else {
                    $this->wxpay->pay($order);
                }
            } else {
                $url=mainUrls.'/index/order/orderList?orderno='.$orderno;
                echo '<h2 style="text-align: center;margin-top: 50px">该订单已付款</h2>';
                echo '<script>
                setTimeout(function() {
                    window.location.href="' . $url . '"
                },3000) 
                </script>';
            }
        }else{
            $this->error('订单不存在','index/index');
        }
    }

    //异步回调
    public function wxnotify(){
        $result = $this->wxpay->notify();
        if ($result) {
            $result['type']=1;   //微信
            $this->handleOrder($result);
        }
    }


    /**
     * 支付宝
     */
    public function alipay(){
        $orderno = input('param.orderno'); //订单号
        $info = getorderbyno($orderno); //订单详情
        if($info){
            if ($info['state'] == 1) {
                $data = array(
                    'out_trade_no' => strval($orderno),
                    'total_amount'  =>  $info['price'],
                    'subject'      =>   '周易网',
                    'body'     =>   '老周易新在线取名'
                );

                if (Mobile_Detect()->isMobile()) {
                    $this->alipay->wap_pay($data);
                } else {
                    $this->alipay->pc_pay($data);
                }
            } else {
                echo '已付款';
            }
        }else{
            $this->error('订单不存在','index/index');
        }
    }

    /**
     * return_url接收页面
     */
    public function alireturn(){
        $arr=$_GET;
        // 引入支付宝
        $config = config('ALIPAY_CONFIG');
        $alipayNotify = new \AlipayTradeService($config);
        // 验证支付数据
        $verify_result = $alipayNotify->check($arr);
        $url=mainUrls.'/index/order/orderList?orderno='.$arr['out_trade_no'];
        if ($verify_result) {
            $arr['type']=2;
            $this->handleOrder($arr);
            echo "<h2><img src='http://qm.lxx673.shop/Uploads/count.gif' style='width: 80%;margin: 150px 4% 50px 16%'><h2>";
            echo '<script>
                setTimeout(function() {
                    window.location.href="' . $url . '"
                },3000) 
                </script>';
        }
    }

    /**
     * notify_url接收页面
     */
    public function alinotify(){
        $arr=$_POST;
        $config= config('ALIPAY_CONFIG');
        $alipayNotify = new \AlipayTradeService($config);
        // 验证支付数据
        $verify_result = $alipayNotify->check($arr);
        if ($verify_result) {
            echo "success";
        } else {
            echo "fail";
        }
    }

    /**
     * 处理订单
     * @param  [type] $order_no [订单编号]
     * @return [type] [description]
     */
    private function handleOrder($result){
        $row=[];
        switch ($result['type']){
            //微信
            case 1:
                $row=[
                    'out_trade_no'=>$result['out_trade_no'],
                    'total_fee'=>$result['total_fee']/100,
                    'transaction_id'=>$result['transaction_id'],
                    'type'=>$result['type'],
                    'time_end'=>strtotime($result['time_end']),
                    'status'=>2
                ];
                break;
            //支付宝
            case 2:
                $row=[
                    'out_trade_no'=>$result['out_trade_no'],
                    'total_fee'=>$result['total_amount'],
                    'transaction_id'=>$result['trade_no'],
                    'type'=>$result['type'],
                    'time_end'=>strtotime($result['timestamp']),
                    'status'=>2
                ];
                break;
        }
        $opt['order_no']=$result['out_trade_no'];
        db('pay_order')->insert($row);  //新增订单

//        $pre_order=db('pre_order');
//        $state=$pre_order->where($opt)->value('state');
//
//        if ( $state == 1) {
//            db('pay_order')->insert($row);  //新增订单
//            $up=['state'=>2, 'uptime'=>time(), 'effect'=>2];
//        }else{
//            //待问题查询
//            $up=['state'=>3, 'uptime'=>time(), 'effect'=>3];
//        }
//        $pre_order->where($opt)->update($up);
    }
}

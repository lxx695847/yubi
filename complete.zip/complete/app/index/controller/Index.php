<?php
/**
 * Created by PhpStorm.
 * User: GG
 * Date: 2018/6/19
 * Time: 10:27
 */
namespace app\Index\controller;
use think\Controller;
define("svp","http://".$_SERVER['HTTP_HOST']."/Uploads/");

class Index extends Controller{
    public function index(){
    //   echo '欢迎来到育碧，请进入后台管理';
    }

    public function test(){
        $area=input('get.area')!=false ? input('get.area') : 1;
        $bags=db('lv_bags_copy1');
        $row=$bags->order('times desc')->where(['is_show'=>2])->select();
        $arr=[];
        foreach ($row as $k=>$v){
            if($v['area']!=false){
                $yu=explode(",",$v['area']);
                if(in_array($area,$yu)==true){
                    $v['kind']=json_decode($v['kind'],true);
                    array_push($arr,$v);
                }
            }
        }
        return view('Index/test',['bag'=>$arr,'baseUrl'=>svp]);
    }

    public function record(){
        $times=input('get.times')!=false ? input('get.times') : date("Y-m-d",time());
        $start=strtotime($times);
        $end=$start+3600*24-1;
        $opt['a.times']=[['>=',$start],['<=',$end],'and'];
        $bags=db('lv_logs')->alias('a')
            ->field('a.*,b.title,b.price,b.kind,b.detailUrl')
            ->join('lv_bags_copy1 b','a.pid=b.pid')
            ->order('a.times desc')
            ->where($opt)
            ->select();

        $arr=[];
        foreach ($bags as $k=>$v){
            $bags[$k]['times']=date('H:i:s',$v['times']);
            $kind=json_decode($v['kind'],true);
            foreach ($kind as $vs){
                if($v['sku']==$vs['skuId']){
                    $bags[$k]['kind']=$vs;
                }
            }
        }

        $total_counts=0;
        foreach ($bags as $k=>$v){
            $arr[$v['sku']]['title']=$v['title'];
            $arr[$v['sku']]['kind']=$v['kind'];
            $arr[$v['sku']]['price']=$v['price'];
            $arr[$v['sku']]['detailUrl']=$v['detailUrl']."#".$v['sku'];

            $arr[$v['sku']]['detail'][]=[
                'in_stock'=>$v['in_stock'],
                'times'=>$v['times']
            ];
        }

        foreach ($arr as $kss=>$vss){
            $total_counts+=count($vss['detail']);
        }

        return view('Index/record',[
            'record'=>$arr,
            'count'=>count($arr),
            'total_counts'=>$total_counts,
            'time'=>$times,
            'baseUrl'=>svp
        ]);
    }

    public function getPwd(){
         echo pwdAct(1,'ant.design');
        // echo pwdAct(1,'hpBtsGDJkNW2');
//        echo "<br />";
//        echo pwdAct(1,'F6yt2fSHKjPZ');
//        echo "<br />";
//        echo pwdAct(1,'AjRXS6zt45Nc');
//        echo "<br />";
//        echo pwdAct(1,'x6LwAFNKPd2b');
    }


    public function switchs(){
        return view('Index/switch');
    }

    //大文件md5秒传测试
    public function md5Ups(){
        return view('Index/md5');
    }

    public function dayTell(){
        $times=input('get.times')!=false ? input('get.times') : date("Y-m-d",time());
        $start=strtotime($times);
        $end=$start+3600*24-1;
        $opt['a.times']=[['>=',$start],['<=',$end],'and'];
        $sku=input('get.sku');
        $arrs=explode(',',$sku);
        $opt['a.sku']=['in',$arrs];

        $bags=db('lv_logs')->alias('a')
            ->field('a.*,b.title,b.kind')
            ->join('lv_bags_copy1 b','a.pid=b.pid')
            ->order('a.times desc')
            ->where($opt)
            ->select();

        $arr=[];
        foreach ($bags as $k=>$v){
            $bags[$k]['times']=date('H:i:s',$v['times']);
            $kind=json_decode($v['kind'],true);
            foreach ($kind as $vs){
                if($v['sku']==$vs['skuId']){
                    $bags[$k]['kind']=$vs;
                }
            }
        }

        foreach ($bags as $k=>$v){
            $arr[$v['sku']]['pid']=$v['pid'];
            $arr[$v['sku']]['title']=$v['title'];
            $arr[$v['sku']]['kind']=$v['kind'];
            $arr[$v['sku']]['times']=$v['times'];

            $arr[$v['sku']]['detail'][]=[
                'in_stock'=>$v['in_stock'],
                'times'=>$v['times']
            ];
        }

        $send=[];$skus=[];
        foreach ($arr as $hh=>$ss){
            array_push($skus,$hh);
            $eo=[
                'title'=>$ss['title'],
                'variantName'=>$ss['kind']['variantName']=='default' ? '默认' : $ss['kind']['variantName'],
                'img'=>$ss['kind']['img']
            ];

            $detail=$ss['detail'];
            $eo['startTips']='当前无货';
            foreach ($detail as $pp=>$qq){
                if($qq['in_stock']==2){
                    $insStart=$detail[$pp]['times'];
                    $eo['startTips']='首次补货'. '' .$insStart;
                }
            };

            $ending=$detail[0];
            $eo['endTips']= $ending['in_stock']==2 ? '当前有货' :  '下架时间'. '' . $ending['times'];
            array_push($send,$eo);
        }

        $tip=[];
        $total=count($send);
        $offset=9;
        $page=ceil($total/$offset);
        for ($i=1;$i<=$page;$i++){
            $start=($i-1)*$offset;
            if($i==$page){
                array_push($tip,array_slice($send,$start));
            }else{
                array_push($tip,array_slice($send,$start,$offset));
            }
        }
        return view('Index/tell',['row'=>$tip]);
    }
}

//数据类型
let a:number;    //指定类型
let c= false;    //自动类型检测
let d: boolean | string;   //联合类型

//对象类型指定
let e:{name:string , [props:string]:any};
e={name:'jack', age:10};

//函数类型指定
let f:(a:number,b:number)=>number;
f=function(n1,n2){
    return n1+n2;
};
f(123,456);

//数组类型申明
let g1: Array<number>;
let g2: number[];

//元祖 --固定长度的数组
let h:[string,string];


//面向对象  (继承)
class Person {
    static age:number=10;    //静态属性（类属性），无需实例化;
    readonly sex:string;   //只读属性
    private honer:string;  //私有属性
    name:string;
    gender:number;

    constructor(name:string,gender:number){
        this.name=name;
        this.gender=gender;
    }

    sayHello(){

    }
}

class Animal extends Person{
    grade:string;
    name:string;
    gender:number;
    constructor(name:string,gender:number,grade:string){
        super(name,gender);  //引用父类构造
        this.grade=grade;
    }

    sayHello() {
        // super.sayHello();   //super 表示当前类的父类
    }

    says(){
        console.log('${this.name}');
    }
}


/**
 * 抽象类
 * 专门用于继承，不能实例化
 * 抽象方法无方法体，子类必须重写
 */

/**
 * 接口
 * 用来定义一个类结构,规范
 * 所有属性不能有实际值
 * 所有方法都是抽象方法
 */
interface traver {
    name:string,
    age?:string,
    sayHello():void
}
class car implements traver{
    name:string;
    constructor(name:string){
        this.name=name;
    }
    sayHello() {
        console.log(222);
    }
}


/**
 * 泛型（不确定类型）
 */
function getTest<K>(a:K):K{
    return a;
}

interface Inter {
    length:number
}
function fn<T extends Inter>(a:T):number {
    return a.length;
}

class myClass<T> {
    name:T;
    constructor(name:T){
        this.name=name;
    }
}

/**
 * React.FC<>为typescript使用的泛型
 */
// const SampleModel: React.FC<{}> = () =>{};




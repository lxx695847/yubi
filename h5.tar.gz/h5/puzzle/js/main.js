window.onload = function () {
  var times = null, start = 30 * 60 * 1000;
  let Dsq = null, times1 = null;

  window.app = new Vue({
    el: '#xyx',
    data() {
      return {
        yxTitle: [
          'xyx_music', 'xyx_rule', "xyx_share",
        ],
        // 雅拉寻宝记
        YarraText: [
          '<h6>操作说明:</h6>点击空格四周相邻的碎片与空格区域交换位置，直至复原操作区域左上角的「完成版示意图」即算完成任务；',
          '<h6>排行榜说明:</h6>复原用时短者排名靠前；</br>用时相同，操作步数少者排名靠前；<br>用时和操作步数均相同，提交时间较早者排名靠前；',
          '<h6>奖励说明:</h6>完成「雅拉寻宝记」可获得比索奖励，每日通过此方式仅可获得一次奖励；</br>分享「雅拉寻宝记」链接给好友即可获得比索奖励，每日通过此方式仅可获得一次奖励；</br>2021.08.30日上线后每周为一期，直至2021年10月17日共进行7期挑战</br>每期的TOP3用户均可获得「孤岛惊魂6-标准版」一份，在7期挑战结束后统一以短信的方式将游戏兑换码发放至参与挑战登录的手机号；',
          '<h6>补充说明:</h6>每个「雅拉之旅活动专属帐号」每期挑战仅保留最优记录参与排名；</br>每个「雅拉之旅活动专属帐号」仅可获取一次TOP3排名奖励；</br>如多期有重复，则奖励发放至排名顺延对应的用户；</br>使用违规作弊手段参与挑战的用户，会取消「雅拉寻宝记」和其他模块的获奖资格，并封禁其「雅拉之旅活动专属帐号」',
        ],
        copy: '孤岛惊魂6雅拉之旅活动进行中，3A大作限量周边数码硬件众多好礼等你来拿！我在雅拉寻宝记中发现了一个秘密，你也要来试试吗：https://yara.ubisoft.com.cn/puzzle/index.html',
        // 表单信息
        user: {
          phone: "",
          code: '',
        },
        totalTime: 60,//倒计时
        content: '获取验证码',//倒计时内容
        canClick: true,//
        // 排行榜
        RankingShow: false,
        RankingData: null,
        //开始游戏按钮
        StartShow: true,
        // 规则说明
        descriptionShow: false,
        // 结果页
        resultShow: false,
        //登录框
        LoginShow: false,
        // 蒙版
        MaskShow: false,
        //拼图
        JigsawPuzzle: false,
        // 分享页
        ShareShow: false,
        ShareTimer: '2分25秒32',
        //提示弹框
        frameShow: false,
        time: 4,
        //音乐开关
        MusicSwitch: false,
        //图片顺序
        puzzles: ['', 1, 2, 3, 4, 5, 6, 7, 8,],
        version: 1,//图片期数
        puzzlesImg: [],
        complete: '',//完整图

        puzzlesShow: false,
        isOff: true,
        isPuzzle: false,//是否完成拼图
        leave: 5 * 60,
        timing: null,

        UserStatus: false,
        UserData: null,
        infor: '',
        TextInfo: '',
        setNum: 0,//点击次数
        LoginShare: false,
        CopyLinkData: null,
        ResultsPage: false,
        num: 30 * 60 * 1000,
        times: null,
        start: 30 * 60 * 1000,
        // start: 1 * 5 * 1000,

        loginTextShow: true,
        FailedPopUp: false,
        imgUrl: '',
        Notlogged: false,
        openDataShow: false,

        valid: true,
        elapsed: null,
        accomplish: null,
        Spass: '',
        pace: [],
        state: 1,
      }
    },
    created() {
      this.UserStatus = store.get('status');//用户登录状态
      this.UserData = store.get('User_information');//手机号接口数据
      this.RankingData = store.get('RankingData');//排行榜
      this.CopyLinkData = store.get('CopyLinkData'); //本周最佳纪录

      // 登录后
      if (this.UserStatus) {
        // 查询
        this.getsendResult(1)
        //排行榜
        this.getRank();
      } else {
        //排行榜
        this.getRank();
        // 查询
        this.getsendResult(1)
      }
    },
    mounted() {
      this.TeseArr(); //打乱拼图

      this.$nextTick(() => {
        this.PendantIsOpen();//精英补给开放 展示挂件
      });

    },
    methods: {
      // 定时器
      countDown() {
        times = window.setInterval(() => {
          start -= 10;
          if (start <= 0) {
            this.isPuzzle = true;//禁止点击图片
            clearInterval(times);
            vant.Toast('时间到!');
            this.FailedPopUp = true;//失败弹框
          }
          $(".my_time").html(gettimer(start, 1)); //倒计时时间
        }, 10);

      },
      // 打乱拼图
      rander() {
        // if (this.valid) {
        //   this.valid = false;
        //   setTimeout(() => {
        //     this.valid = true;
        //   }, 360)
        //   this.TeseArr()
        // }
      },
      //重置
      shuffle() {
        this.isOff = true;
        this.isPuzzle = false; //禁止图片点击
        this.setNum = 0; //次数
        // this.state = 1;

        // 登录
        if (this.UserStatus) {
          // 正常
          if (this.UserData.status == 2) {
            clearInterval(times);
            start = 30 * 60 * 1000;//重置时间
            $(".my_time").html(gettimer(start, 1)); //倒计时时间


            console.log(this.state)
            if (this.state == 2) {
              this.state = 1

              setTimeout(() => {
                var data = {
                  access: this.UserData.access
                }
                $axios.TestArr(data).then((res) => {
                  this.state = 2;
                  this.puzzles = res.data.data //打乱图片

                  this.elapsed = new Date().getTime();

                  let now = new Date().getTime()
                  this.pace = [];
                  this.pace[0] = { 'elapsed': now };
                  store.set('ks', now)
                  start = 30 * 60 * 1000;//重置时间
                  this.countDown();//开启定时器 
                })
              }, 200)

            }
          } else {
            // 活动未开始
            return false
          }

        } else {
          // 未登录
          start = 30 * 60 * 1000;//重置时间
          $(".my_time").html(gettimer(start, 1)); //倒计时时间
          
          clearInterval(times);

          // this.countDown();//开启定时器
          this.isOff = true;
          this.isPuzzle = false;
          this.FailedPopUp = false;//失败弹框
          if (this.state == 2) {
            this.state = 1

            setTimeout(() => {
              var data = {
                access: ""
              }
              $axios.TestArr(data).then((res) => {
                console.log(res, "打乱数组")
                this.state = 2;
                this.puzzles = res.data.data //打乱图片

                this.elapsed = new Date().getTime();

                let now = new Date().getTime()
                this.pace = [];
                this.pace[0] = { 'elapsed': now };
                store.set('ks', now)
                start = 30 * 60 * 1000;//重置时间
                this.countDown();//开启定时器 
              })
            }, 200)

          }

        }
      },
      //点击滑动拼图
      clickBlock(index) {

        if (!this.isPuzzle && this.state == 2) {
          this.setNum++;
          let curIndex = this.puzzles[index];
          let leftIndex = this.puzzles[index - 1];
          let rightIndex = this.puzzles[index + 1];
          let topIndex = this.puzzles[index - 3];
          let bottomIndex = this.puzzles[index + 3];
          let time = new Date().getTime();
          if (leftIndex === '' && index % 3) {
            this.$set(this.puzzles, index - 1, curIndex);
            this.$set(this.puzzles, index, '');
            this.pace.push({ curIndex: time })
          } else if (rightIndex === '' && 2 !== index % 3) {
            this.$set(this.puzzles, index + 1, curIndex);
            this.$set(this.puzzles, index, '');
            this.pace.push({ curIndex: time })
          } else if (topIndex === '') {
            this.$set(this.puzzles, index - 3, curIndex);
            this.$set(this.puzzles, index, '');
            this.pace.push({ curIndex: time })
          } else if (bottomIndex === '') {
            this.$set(this.puzzles, index + 3, curIndex);
            this.$set(this.puzzles, index, '');
            this.pace.push({ curIndex: time })
          }
          this.pass() //是否完成拼图

        }
        console.log(this.pace, "步骤")
      },
      // 保存图片
      SavePicture() {
        this.downloadImg();
      },
      //查看排行榜
      Leaderboard() {
        this.MaskShow = true;
        this.RankingShow = true;
        this.getRank();
      },
      //拼图概率 
      TeseArr() {
        if (this.UserStatus) {
          var data = {
            access: this.UserData.access
          }
        } else {
          data = {
            access: '',
          }
        }

        $axios.TestArr(data).then((res) => {
          this.state = 2;
          this.puzzles = res.data.data //图片
          // Object.freeze()
          this.elapsed = new Date().getTime();

          let now = new Date().getTime()
          this.pace = [];
          this.pace[0] = { 'elapsed': now };
          store.set('ks', now)
        })

      },
      //判断是否完成
      pass() {
        console.log(this.state)
        if (this.puzzles[8] === '' && this.isOff) {
          const newPuzzles = this.puzzles.slice(0, 8);
          const isPass = newPuzzles.every((e, i) => e === i + 1);
          if (isPass && this.state == 2) {
            this.isOff = false;
            this.isPuzzle = true;//禁止点击图片
            // 登录后
            if (this.UserStatus) {
              this.accomplish = new Date().getTime();

              $(".my_time").html(gettimer(this.start - (this.accomplish - this.elapsed), 1));//时间戳时间

              clearInterval(times);//清除定时器
              this.ShareShow = true;//分享弹框
              this.MaskShow = true;//蒙版
              $("#timer").text(gettimer(this.accomplish - this.elapsed))
              // 查询
              this.getsendResult(1);
              // 提交返回
              this.getsendResult(2);
              //更新排行榜
              this.getRank();
            } else {
              // 没登录
              clearInterval(times);
              this.LoginShow = true;
              $("#timer").text((this.num - start))
              this.accomplish = new Date().getTime();
            }
          }
        } else {
          return false
        }
      },
      // 未登录 复制按钮
      NotloggedIn() {
        if (this.UserStatus) {
          CopyText(".LoginCopy");
        } else {
          vant.Toast("请登录后复制!")
        }
      },
      // 提交分享  
      Submit() {
        if (!this.UserStatus) {
          this.LoginShow = true;//打卡登录弹框
          return false;
        }
        //  提交分享
        $axios.geteditState({
          sign: this.CopyLinkData.sign,
          access: this.UserData.access,
          title: gettimer(this.num - start),
        }).then((res) => {
          if (Object.keys(res.data.data.award).length) {
            let award = res.data.data.award;
            vant.Toast.success({
              duration: 2500,
              message: award.title + '奖励' + award.tip + '+' + award.worth,
            });
            //更新数据
            this.getUserDetail();
          }

          this.ResultsPage = true; //结果页 分享图
          this.imgUrl = res.data.data.imgSrc;
          console.log(res.data.data.imgSrc)

          document.getElementsByClassName("pic1")[0].src = `${this.imgsUrl(res.data.data.imgSrc)}`;
        }).catch((err) => {

        })

      },
      // 保存图片
      downloadImg() {
        var image = new Image()
        image.setAttribute('crossOrigin', 'anonymous')
        image.crossOrigin = "Anonymous"
        image.onload = function () {
          var canvas = document.createElement('canvas')
          canvas.width = image.width
          canvas.height = image.height
          var context = canvas.getContext('2d')
          context.drawImage(image, 0, 0, image.width, image.height)
          var url = canvas.toDataURL('image/png')
          // 生成一个a元素
          var a = document.createElement('a')
          // 创建一个单击事件
          var event = new MouseEvent('click')
          // 将a的download属性设置为我们想要下载的图片名称，若name不存在则使用‘下载图片名称’作为默认名称
          a.download = '雅拉寻宝'
          // 将生成的URL设置为a.href属性
          a.href = url
          // 触发a的单击事件
          a.dispatchEvent(event)
        }
        image.src = document.querySelector("#testImg").src

      },
      //返回图片地址
      setUrl(item) {
        return imgUrl + item;
      },
      // img
      imgsUrl(item) {
        return 'http://yubi.aju.cn/' + item;
      },
      //再来一次
      Comeagain() {
        this.FailedPopUp = false;
        this.ShareShow = false;
        this.MaskShow = false;
      },
      // 复制链接 
      CopyLink() {
        console.log("复制")
      },
      // 返回活动页
      GoHome() {
        location.replace('../index.html');
      },
      // 页头开关
      onRule(i) {
        // 音乐
        if (i === 0) {
          let oAudio = document.querySelector("#audio")
          if (!this.MusicSwitch) {
            document.querySelector(".MusicSwitch").src = "./image/TurnMusic.png"
            oAudio.play();//让音频文件开始播放 
          } else {
            oAudio.pause();//让音频文件暂停播放 
            document.querySelector(".MusicSwitch").src = "./image/xyx_music.png"
          }
          this.MusicSwitch = !this.MusicSwitch;
        }
        //规则
        if (i === 1) {
          this.MaskShow = true;//蒙版
          this.descriptionShow = true;
        }
        //分享
        if (i === 2) {
          this.MaskShow = true;//蒙版
          this.LoginShare = true;//分享框
        }
      },
      //开始游戏按钮
      onStart() {
        if (this.UserStatus) {
          this.JigsawPuzzle = true;//打开拼图
          this.StartShow = false;
          this.countDown();//开始定时器

          this.elapsed = new Date().getTime();

          let now = new Date().getTime();
          this.pace[0] = { 'elapsed': now };
          store.set('ks', now)

        } else {
          // 打开登录提示
          this.LoginShow = true;//登录框
          this.MaskShow = true;//蒙版
        }
      },
      //游客试玩
      UserDemo() {
        this.JigsawPuzzle = true;//打开拼图
        this.LoginShow = false;//关闭登录弹框
        this.StartShow = false;
        this.loginTextShow = false;
        this.MaskShow = false;//蒙版
        this.countDown();//开始定时器
        this.elapsed = new Date().getTime();
      },
      //获取验证码
      GetCode() {
        let self = this;
        if (this.user.phone == '') {
          vant.Toast('请输入手机号!');
          return false
        }
        if (!reg.test(this.user.phone)) {
          vant.Toast('请填写正确的手机号!');
          return false
        }
        //节流 每60秒只执行一次
        if (this.canClick) {
          let clock = window.setInterval(() => {
            self.totalTime--
            self.content = self.totalTime + 's后重新发送';
            if (self.totalTime === -1) {
              clearInterval(clock)
              self.content = '获取验证码';
              self.totalTime = 60;//验证码间隔时间
              self.canClick = true //重新开启
            }
          }, 1000)
          self.canClick = false //按钮不可点击

          // 请求手机验证码
          $axios.getsendReport({ phone: this.user.phone })
            .then((res) => {
              if (res.data.code == 200) {
                vant.Toast("发送成功")
              } else {
                vant.Toast("发送失败!")
              }
            })
        }
      },
      // 立即登录
      LogIn() {
        const reg = /^1[35789]\d{9}$/;
        const regcode = /^[0-9]{6}$/;
        if (!reg.test(this.user.phone)) {
          vant.Toast("请填写正确的手机号!")
          return false
        }
        if (this.user.code == '') {
          vant.Toast("验证码不能为空!")
          return false
        }
        if (!regcode.test(this.user.code)) {
          vant.Toast("验证码长度不符合!")
          return false
        }
        $axios.getLogin({
          phone: this.user.phone,
          code: this.user.code,
        }).then((res) => {
          if (res.data.status == 2) {
            vant.Toast('登录成功!');
            //更新用户登录状态
            store.set('status', true)
            this.UserStatus = true;
            store.set('User_information', res.data.data); //用户信息
            this.UserData = res.data.data;

            this.getRank();//排行榜
            this.getsendResult(1);// 查询
            setTimeout(() => {
              this.close();//关闭弹窗
              // this.UserDemo();
            }, 580)
          }
          if (res.data.status == 1) {
            if (res.data.code == 1200) {
              vant.Toast("验证码错误!")
            } else if (res.data.code == 1100) {
              vant.Toast("验证码已经失效!")
            } else if (res.data.code == 1005) {
              vant.Toast('账号异常');
            }
            return false;
          }
        }).catch((err) => { })

      },
      // 排行榜
      getRank() {
        var data = {
          type: 1,
        }
        if (this.UserStatus) {
          data = {
            type: 2,
            access: this.UserData.access,
          }
        }
        $axios.getRank(data).then((res) => {
          console.log(res, "排行榜")
          this.RankingData = res.data.data
          this.version = res.data.data.version
          //更新用户信息
          this.getUserDetail();
          store.set('RankingData', this.RankingData);
        }).catch((err) => { })

      },
      //更新数据
      getUserDetail() {
        $axios.getUserDetail({ access: this.UserData.access, })
          .then((res) => {
            if (res.data.status == 2) {
              console.log(res, "更新用户信息")
              this.UserData = res.data.data;
              store.set("User_information", res.data.data); //更新用户信息
              // 自动任务
              if (Object.keys(res.data.data.award).length) {
                let award = res.data.data.award
                vant.Toast.success({
                  duration: 2000,
                  message: award.title + '奖励' + award.tip + '+' + award.worth,
                });
                this.getUserDetail();
              }
            } else {
              this.Reload(res.data.code);
            }
          }).catch((err) => { })
      },
      //检测其他平台登录
      Reload(data) {
        if (data == 1008) {
          store.clear()//清空本地数据
          vant.Toast("当前设备已在其他设备登录,请重新登录");
          this.UserStatus = false;//状态更新
          location.reload()// 刷新页面
        }
      },
      // 查询1  提交2
      getsendResult(item) {
        let num = 30 * 60 * 1000;
        let data = {
          area: item
        }
        if (this.UserStatus && item == 1) {
          data = {
            area: item,
            access: this.UserData.access,
          }
        }
        if (this.UserStatus && item == 2) {

          data = {
            area: item,
            access: this.UserData.access,
            sign: window.btoa(JSON.stringify(this.pace))
          }
          console.log(JSON.stringify(this.pace))
        }
        $.ajax({
          url: baseURL + "sendResult",
          type: "post",
          // async: true,
          data: data,
          contentType: 'application/x-www-form-urlencoded',
          success: res => {
            this.Reload(res.code);//验证多设备登录
            if (item == 1) {
              console.log(res, "查询")
              if (res.data.grade.length) {
                this.infor = gettimer(Number(res.data.grade))
              }
              this.$nextTick(() => {
                this.complete = res.data.complete; //完整图
                this.puzzlesImg = res.data.img;  //9拼图
                this.puzzlesShow = true;
              });
              // console.log(res.data.img)
            };
            if (item == 2) {

              let now = store.get("ks")
              console.log(now)
              console.log(this.pace[0].elapsed)
              if (!(now == this.pace[0].elapsed)) {
                return false
              }
              store.remove('ks')

              // res.
              console.log(res, "提交返回")
              if (Object.keys(res.data.award).length) {
                let award = res.data.award
                vant.Toast.success({
                  duration: 2500,
                  message: award.title + award.tip + '+' + award.worth,
                });
                //更新数据
                this.getUserDetail();
                this.getRank()// 更新排行榜
              }
              store.set("CopyLinkData", res.data)
              this.CopyLinkData = res.data;
            }
          }
        })
      },
      gettimer(item) {
        return gettimer(Number(item))
      },
      //多设备登录 踢出
      Reload(data) {
        if (data == 1008) {
          store.clear()//清空本地数据
          vant.Toast("当前设备已在其他设备登录,请重新登录");
          this.UserStatus = false;//状态更新
          location.reload()// 刷新页面
        }
      },
      // 关闭按钮
      close() {
        this.MaskShow = false;
        this.descriptionShow = false;
        this.LoginShow = false;
        this.resultShow = false;
        this.ShareShow = false;
        this.LoginShare = false;
        this.RankingShow = false;
      },
      //高级宝箱 挂件开启
      PendantIsOpen() {
        var nowtime = new Date(),  //获取当前时间
          endtime = new Date("2021-10-14 00:00:00");  //定义结束时间
        let flg = nowtime.getTime() >= endtime.getTime();
        // 到达指定时间
        if (flg) {
          this.Notlogged = true;
        }
        // 登录后
        if (flg && this.UserStatus) {
          this.openDataShow = true;
        }
      },
    }
  });

  //时间戳格式转换
  function gettimer(time, area = 0) {
    // d = Math.floor(leftTime / 1000 / 60 / 60 / 24);
    // h = Math.floor(leftTime / 1000 / 60 / 60 % 24);
    var m = Math.floor(time / 1000 / 60 % 60);
    var s = Math.floor(time / 1000 % 60);
    var ms = Math.floor(time % 1000);
    if (ms / 10 < 10) {
      ms = "0" + ms
    }
    if (s < 10) {
      s = "0" + s;
    }
    if (m < 10) {
      m = "0" + m;
    }
    if (area == 1) {
      return m + ":" + s + ":" + parseInt(ms / 10);
    } else {
      return m + "分" + s + "秒" + parseInt(ms / 10);
    }
  }

  //监听 visibility change 事件
  document.addEventListener('visibilitychange', function () {
    // 页面变为不可见时触发
    if (document.visibilityState == 'hidden') {
      console.log("页面不可见");
      if (app.$data.isPuzzle) {
        console.log(app.$data.isPuzzle)
        return false
      }
      if (app.$data.JigsawPuzzle) {
        Dsq = start;
        times1 = setInterval(() => {
          Dsq -= 1000;
          console.log(gettimer(Dsq, 1))
        }, 1000);
      }

    }
    // 页面变为可见时触发
    if (document.visibilityState == 'visible') {
      console.log("页面可见")
      if (app.$data.isPuzzle) {
        return false
      }
      if (app.$data.JigsawPuzzle) {
        clearInterval(times1)
        start = Dsq - 1000;
        console.log(gettimer(start, 1))
      }

    }
  });


  var throttle = function (func, delay) {
    var prev = Date.now();
    return function () {
      var context = this;
      var args = arguments;
      var now = Date.now();
      if (now - prev >= delay) {
        func.apply(context, args);
        prev = Date.now();
      }
    }
  }
}
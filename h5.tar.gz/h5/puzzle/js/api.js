// import axios from '../node_modules/axios/axios';

const baseURL = "http://ybadmin.aju.cn/"
const imgUrl = baseURL + "Uploads/";

// http://ybadmin.aju.cn/Uploads/
const service = axios.create({
  baseURL: "http://ybadmin.aju.cn/",
  // method: 'post',
  // withCredentials: true, // 若跨域请求需要带 cookie 身份识别
  // headers: {
  //   'content-type': 'application/x-www-form-urlencoded',
  //   // 'content-type': 'application/x-www-form-urlencoded'
  // },
});

const $axios = {
  //手机号登陆
  async getLogin(data) {
    return await axios({ url: baseURL + 'getLogin', method: 'POST', params: data })
  },
  // 请求手机验证码
  async getsendReport(data) {
    return await axios({ url: baseURL + 'sendReport', method: 'POST', params: data })
  },
  // 获取登录信息
  async getUserDetail(data) {
    return await axios({ url: baseURL + 'getDetail', method: 'POST', params: data })
  },
  // 排行榜 type 1 2 是否登录   access 2 登录时 必传
  async getRank(data) {
    return await axios({ url: baseURL + 'getRank', method: 'POST', params: data })
  },
  
  //查询 提交 useTime 用时  step 步数  access 秘钥 
  async getsendResult(data) {
    return await axios({ url: baseURL + 'sendResult', method: 'POST', params: data })
  },
  // 提交分享 
  async geteditState(data) {
    return await axios({ url: baseURL + 'editState', method: 'POST', params: data })
  },
  async TestArr(data) {
    return await axios({ url: baseURL + 'test', method: 'POST', params: data })
  },



}

let reg = /^(?:(?:\+|00)86)?1[3-9]\d{9}$/;




window.onload = function () {
  window.app = new Vue({
    el: "#app",
    data() {
      return {
        cardImg: ['Postcard', 'Treasure'],
        user: {
          mobilephone: '',// 手机号
          code: '',//验证码
        },
        UserStatus: false,//用户登录状态
        UserData: {
          access: '', //秘钥
          avatar: '', //头像
          blind: '', //绑定
          status: '', //状态
          nickName: '', //昵称
          coin: 0, //雅拉币
          bullion: 0, //银条
          phone: '', //手机号
          status: '', //地址绑定状态
          award: null, //每日任务
          address: "", //地址
        },
        codeStatus: true, //滑块验证控制
        content: '获取验证码', // 按钮里显示的内容
        totalTime: 60, //记录具体倒计时时间
        canClick: true, //验证码状态
        loginPop: false, //登录弹框默认隐藏
        import: "", //微信绑定使用
        bindPhonePop: false, //绑定电话弹窗
        step: 0,//步骤
        zutuan: null,
        kinNumber: false,

        TurntableMessage: null, //转盘消息
        commonProgress: "",//普通宝箱进度
        higherProgress: "",//高级宝箱进度
        higherStartLeave: "",//高级宝箱还剩时间

        // 任务列表
        User_TaskList: [],
        coinCount: 0, //用户消耗比索数量
        unlock: 0, //解锁节点数

        task_list_show: false,//任务列表
        WinningBox_Show: false,//抽奖结果
        WinningBox_title: "",//抽奖结果标题（中奖时、查看）
        LotteryRules_Show: false,//明信片、寻宝、组队规则

        rewardShow: false,//里程碑将奖品记录
        couponsShow: false, //里程碑领券弹窗
        MilestoneSchedule: null,// 里程碑进度
        isCanclickCoupons: true, //是否可以点击领取里程碑
        couponsSingleData: null,
        menuShow: true,

        WinningRecord: [],//中奖纪录数据
        WinningItems: { kind: "" }, //中奖信息
        isCanWinning: true, //是否可以抽奖

        listBoxState: true, //点击导航栏时，暂时停止监听页面滚动
        AddressShow: false,//收获地址弹框
        midd_list: { // 收货地址信息
          province: '',
          city: '',
          area: '',
          name: '',
          phone: '',
          address: "",
        },
        isCanSubmitAddress: true,  //是否可以提交地址
        regionArr: Data,//地区数据
        cityArr: [], //选择对应省的市数据
        areaArr: [], //选择对应市的区数据

        textheader: ['明信片', '组团游览', '雅拉寻宝', '游乐场', '预购福利', '贡献统计', '雅拉风景'],
        LotteryShow: false, //抽奖规则 中奖纪录
        LotteryItem: null,// 0抽奖 1中奖
        // 抽奖规则文字说明
        LotteryText: [
          '<h6>抽奖规则说明:</h6>「普通补给」开放时间：2021年08月30日-2021年10月21日 积分消耗：5比索/次；</br>「精英补给」开放时间：2021年10月14日-2021年10月21日 积分消耗：5个银条/次；',
          '<h6>积分获取方式:</h6> 【比索】：参与并完成「雅拉之旅」活动各项任务获取雅拉岛货币；',
          '<h6>银条获取方式: </h6>【银条】：参与「雅拉组团游」任务，每成功邀请一名用户预购《孤岛惊魂6》即可获取5 银条；</br>「普通补给」也有一定几率抽取银条；',
          '<h6>补给箱奖励发放说明：</h6>【虚拟奖品-育碧商城优惠券】-即时发放；</br>【虚拟奖品-育碧游戏】- 3个工作日内发放至绑定的育碧帐号；</br>【虚拟奖品-孤岛惊魂6游戏币】- 游戏上线后7个工作日发放；</br>【虚拟奖品-孤岛惊魂6游戏币】- 游戏上线后7个工作日发放；</br>【实物奖品】- 2021.10.21活动结束后两个月内统一发放至用户提交的收货地址；',
          '<h6>补充说明：</h6>开启补给仅消耗对应【比索】和【银条】，每日不限抽奖次数上限；</br>实物奖品中奖后，请正确填写联系方式及收货地址，逾期未填该中奖资格视为作废；</br>（2021年10月21日 23:59:59后关闭收货地址修改功能）',
        ],
        // 明信片规则
        Postcard: [
          '<h6>任务说明:</h6>参与用户根据流程指引，订制专属「雅拉明信片」并分享给好友；',
          '<h6>任务奖励:</h6>分享明信片图片或链接给好友即可获得比索奖励，每日通过此方式仅可获得1次奖励；',
        ],
        // 组团规则
        PostRules: [
          '<h6>任务说明:</h6>参与用户根据流程指引，注册「雅拉之旅活动专属帐号」+绑定「育碧帐号」并完成《孤岛惊魂6》预购后，可生成「专属邀请链接」，分享给好友成功邀请预购后可获得奖励；',
          '<h6>任务奖励:</h6> 1. 前2000名通过「专属邀请链接」成功邀请他人预购的用户可获得「孤岛惊魂6神秘礼品」一份;<br>（每名用户仅可通过此方式获取一次奖励）；<br>10月7日会公示中奖名单并在两个月内统一安排快递发放 </br>2. 分享「专属链接」，每通过此链接成功预购《孤岛惊魂6》一次，向分享者发放5银条奖励；</br>（每日通过此方式获取此奖励次数不设上限）；',
          '<h6>补充说明:</h6>成功邀请的银条奖励即时发放。</br>但在2021年10月7日「组团游雅拉」结束前，如有受邀者的预购进行了退款，对应邀请人获取的银条积分会做扣除处理；<br>如邀请者对自己的预购进行了退款，则账户中所有通过「组团游雅拉」获取的银条会做扣除处理；',
        ],
        // 寻宝规则
        YarraText: [
          '<h6>操作说明:</h6>点击空格四周相邻的碎片与空格区域交换位置，直至复原操作区域左上角的「完成版示意图」即算完成任务；',
          '<h6>排行榜说明:</h6>复原用时短者排名靠前；</br>用时相同，操作步数少者排名靠前；<br>用时和操作步数均相同，提交时间较早者排名靠前；',
          '<h6>奖励说明:</h6>完成「雅拉寻宝记」可获得比索奖励，每日通过此方式仅可获得一次奖励；</br>分享「雅拉寻宝记」链接给好友即可获得比索奖励，每日通过此方式仅可获得一次奖励；</br>2021.08.30日上线后每周为一期，直至2021年10月17日共进行7期挑战</br>每期的TOP3用户均可获得「孤岛惊魂6-标准版」一份，在7期挑战结束后统一以短信的方式将游戏兑换码发放至参与挑战登录的手机号；',
          '<h6>补充说明:</h6>每个「雅拉之旅活动专属帐号」每期挑战仅保留最优记录参与排名；</br>每个「雅拉之旅活动专属帐号」仅可获取一次TOP3排名奖励；</br>如多期有重复，则奖励发放至排名顺延对应的用户；</br>使用违规作弊手段参与挑战的用户，会取消「雅拉寻宝记」和其他模块的获奖资格，并封禁其「雅拉之旅活动专属帐号」',
        ],
        //里程碑规则
        MilestoneText: [
          '<h6>里程碑解锁说明:</h6>「雅拉岛」设有六个需解锁地标，所有参与活动用户累计使用【比索】达标后即刻成功解锁对应地标奖励；',
          '<h6>里程碑解锁奖励发放说明:</h6>所有参与「雅拉之旅」的用户均可在地标解锁后手动领取奖励；<br>部分奖励有时效限制，超出则无法使用；',
        ],
        ruleText: [],
        ruleTitle: "",
        //雅拉旅游指南内容
        TravelData: [
          { url: '9.jpg', bigurl: '9.jpg', name: '狮王之塔' },
          { url: '10.jpg', bigurl: '10.jpg', name: '海风吹拂' },
          { url: '11.jpg', bigurl: '11.jpg', name: '东部海滩' },
          { url: '12.jpg', bigurl: '12.jpg', name: '宁静村庄' },
          { url: '8.jpg', bigurl: '8.jpg', name: '首都街景' },
          { url: '1.jpg', bigurl: '1.jpg', name: '中心街区' },
          { url: '7.jpg', bigurl: '7.jpg', name: '街区一隅' },
          { url: '3.jpg', bigurl: '3.jpg', name: '乡间小道' },
          { url: '5.jpg', bigurl: '5.jpg', name: '播撒希望' },
          { url: '2.jpg', bigurl: '2.jpg', name: '英勇士兵' },
          { url: '4.jpg', bigurl: '4.jpg', name: '游击战士' },
          { url: '6.jpg', bigurl: '6.jpg', name: '危险分子' },
        ],
        pictureView: false, // 图片预览
        viewPictureIndex: 0,
        idCard: "",//中奖虚拟卡号
        simpleID: -1,//中奖ID
        simpleArr: {},
        WinningRecordBulletBox: false,
        WinningNum: 0,
        tructions: false,
        wenToasShow: false,
        weixinShow: true, //微信登录 隐藏退出按钮
      }
    },
    created() {
      this.UserStatus = store.get('status')//用户登录状态
      // 页面刷新时获取数据 
      if (this.UserStatus) {
        // 用户信息 
        this.UserData = store.get('User_information');//手机号接口数据
        //转盘信息接口数据
        this.TurntableMessage = store.get('TurntableMessage')
        // 任务列表
        this.User_TaskList = store.get("User_TaskList")
        //中奖纪录
        this.WinningRecord = store.get("WinningRecord");
        //里程碑进度
        this.MilestoneSchedule = store.get("MilestoneSchedule")
        // 中奖纪录 ok
        this.getgetRecord()
        // 获取用户信息
        this.getUserDetail()
      }
      // 里程碑进度  *ok
      this.getLichengbeiList()
      // 转盘消息（奖品列表）
      this.getlotteryAward()
    },
    mounted() {
      window.addEventListener('scroll', this.scrollToTop)
      setTimeout(() => {
        new Swiper('.turntable', {
          spaceBetween: 10,
          loop: true,
          loopAdditionalSlides: 2,
          slidesPerView: 'auto',
          loopedSlides: 5,
        });
      }, 1000);
      new Swiper('#touristGuideBox', {
        spaceBetween: 10,
        slidesPerView: 'auto',
      });
      clipboard.on('success', function (e) {
        console.info('Text:', e.text);
        vant.Toast("复制成功！")
      });

      if (this.isWeixn()) {
        var weixinData = this.getJsUrl();
        if (weixinData.openid && weixinData.unionid) {
          this.moreLogin(weixinData)
          this.weixinShow = false;
        }
        if (!this.UserStatus && !weixinData.openid && !weixinData.unionid) {
          this.weixinLogin()
        }
        
      }
    },
    destroyed() {
      window.removeEventListener('scroll', this.scrollToTop)
    },
    methods: {
      onwenToasShow() {
        this.wenToasShow = !this.wenToasShow;
      },
      // 页头菜单
      menu() {
        this.menuShow = !this.menuShow;
      },
      //页头标题点击事件
      onclick(i) {
        this.headerNum = i;
        if (i === 0 || i === 1 || i === 2) {
          Top_Backto('#card');
          return false
        }
        Top_Backto(`#id${i}`);
        this.listBoxState = false;
        let timeId;
        clearTimeout(timeId);
        timeId = setTimeout(() => {
          this.listBoxState = true;
        }, 2500);
      },
      //监听滚动条
      scrollToTop() {
        const that = this
        let scrollTop = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop
        that.scrollTop = scrollTop
        if (that.listBoxState) {
          that.textheader.map((item, i) => {
            // 获取监听元素距离视窗顶部距离
            if (i > 2) {
              var offsetTop = document.getElementById(`id${i}`).offsetTop;
              // 获取监听元素本身高度
              var scrollHeight = document.getElementById(`id${i}`).scrollHeight;
              // console.log(scrollHeight)
              // 如果 dom滚动位置 >= 元素距离视窗距离 && dom滚动位置 <= 元素距离视窗距离+元素本身高度
              // 则表示页面已经滚动到可视区了。
              if (scrollTop >= offsetTop && scrollTop <= (offsetTop + scrollHeight)) {
                // 导航栏背景色选中
                that.headerNum = i;
              }
            } else {
              // that.headerNum = 2;
            }
          })
        }
        if (that.scrollTop > 650) {
          that.btnFlag = true;
        } else {
          that.btnFlag = false;
        }
      },
      // 获取更多
      click_more() {
        if (this.UserStatus) {
          this.task_list_show = true
          this.getList() //任务列表
        } else {
          this.login() //弹框
        }
      },
      //开启宝箱抽奖
      OpenTreasureChest(index) {
        if (!this.UserStatus) {
          this.login();
          return false;
        }
        // console.log(123)
        // this.isCanWinning = false
        // if (this.UserData.coin < this.TurntableMessage.base.coin && index == 1) {
        //   vant.Toast("可用比索不足")
        //   this.isCanWinning = true; //避免多次触发
        //   return false
        // }//普通宝箱
        // if (this.UserData.bullion < this.TurntableMessage.base.bullion && index == 2) {
        //   vant.Toast("可用银条不足")
        //   this.isCanWinning = true; //避免多次触发
        //   return false
        // }//高级宝箱

        // 抽奖领奖  ok  
        $axios.getlotteryReceive({
          access: this.UserData.access,
          pass: this.TurntableMessage.pass,
          area: index,
        }).then((res) => {
          this.Reload(res.data.code);
          this.simpleID = -1;
          console.log(res, "抽奖")
          // this.isCanWinning = true; //可继续抽奖
          if (res.data.status === 2) {
            if (res.data.data.virtual) {
              this.idCard = res.data.data.virtual.idCard //卷
            }
            this.simpleID = res.data.data.id; //中奖id
            console.log(this.simpleID)
            this.getUserDetail()// 用户详情
            this.getgetRecord()// 中奖记录
            this.simpleArr = this.TurntableMessage.row.filter((item, i) => {
              return item.id == res.data.data.id //奖品id比对
            })
            console.log(this.simpleArr, '抽中奖品')
            this.WinningBox_Show = true;//奖品弹框
          } else {
            if (res.data.code == 1200) {
              vant.Toast("抽奖人数较多，请稍后再试");
            }
            if (index == 1 && res.data.code == 1010) {
              vant.Toast("可用比索不足");
            }
            if (index == 2 && res.data.code == 1010) {
              vant.Toast("可用银条不足");
            }
          }
        }).catch((err) => {
          // this.isCanWinning = true;
        })

      },
      //更新市数据
      updataCity() {
        this.regionArr.forEach((item, index) => {
          if (item.name === this.midd_list.province) {
            this.cityArr = item.city;
          }
        });
        // 初始化默认值
        this.midd_list.city = this.cityArr
      },
      //更新区数据
      updataSub() {
        this.cityArr.forEach((item, index) => {
          if (item.name === this.midd_list.city) {
            this.areaArr = item.area;
          }
        });
        this.midd_list.area = this.areaArr;
      },
      // 规则说明 弹框
      OnRuleitem(i) {
        if (i == 0) {
          // 明信片规则
          this.ruleText = this.Postcard
          this.ruleTitle = "规则说明"
        } else if (i == 1) {
          this.ruleText = this.YarraText
          this.ruleTitle = "规则说明"
        } else if (i == 2) {
          this.ruleText = this.PostRules
          this.ruleTitle = "规则说明"
        } else {
          this.ruleText = this.MilestoneText
          this.ruleTitle = "规则说明"
        }
        this.LotteryRules_Show = true
      },
      // 获取验证码
      countDown() {
        let el = document.getElementsByClassName("fixed")[0]
        const reg = /^1((34[0-8]\d{7})|((3[0-3|5-9])|(4[5-7|9])|(5[0-3|5-9])|(66)|(7[2-3|5-8])|(8[0-9])|(9[1|8|9]))\d{8})$/;
        if (!this.canClick) return
        if (!reg.test(this.user.mobilephone)) {
          vant.Toast("请输入正确的手机号!")
          return false;
        }
        if (!this.codeStatus) {
          el.style = 'display:block'; //打开验证码滑块弹框
        } else {
          if (!this.canClick) return //节流 每60秒只执行一次
          this.canClick = false //按钮不可点击
          let clock = window.setInterval(() => {
            this.totalTime--
            this.content = this.totalTime + 's后重新发送';
            if (this.totalTime === -1) {
              clearInterval(clock)
              this.content = '获取验证码';
              this.totalTime = 60;//验证码间隔时间
              this.canClick = true //重新开启
            }
          }, 1000)
          // 请求手机验证码
          $axios.getsendReport({ phone: this.user.mobilephone })
            .then((res) => {
              console.log(res)
            })
            .catch((err) => {
              console.log(err)
            })
        }
      },
      // 立即登录
      Signin() {
        const reg = /^1((34[0-8]\d{7})|((3[0-3|5-9])|(4[5-7|9])|(5[0-3|5-9])|(66)|(7[2-3|5-8])|(8[0-9])|(9[1|8|9]))\d{8})$/;
        const regcode = /^[0-9]{6}$/;
        if (!reg.test(this.user.mobilephone)) {
          vant.Toast("请填写正确的手机号!")
          return false
        }
        if (this.user.code === '') {
          vant.Toast("验证码不能为空!")
          return false
        }
        if (!regcode.test(this.user.code)) {
          vant.Toast("验证码长度不符合!")
          return false
        }
        // 手机号登陆
        $axios.getLogin({ phone: this.user.mobilephone, code: this.user.code }).then((res) => {
          if (res.data.status == 2) {
            this.UserData = res.data.data;
            this.UserStatus = true;
            // if (this.UserData.bind === '1') {
            //   this.step = 1
            // } else {
            //   this.step = 3
            // }
            store.set('status', true)
            store.set('User_information', this.UserData)
            vant.Toast("登录成功!")
            // 获取任务列表
            this.getList();
            // 转盘消息（奖品列表）
            this.getlotteryAward();
            // 里程碑进度  *ok
            this.getLichengbeiList();
            // 中奖记录
            this.getgetRecord();
            // 用户信息
            this.getUserDetail();

            setTimeout(() => {
              this.closeButton(); //关闭弹窗
            }, 680)
          }
          if (res.data.status == 1) {
            switch (res.data.code) {
              case '1200':
                vant.Toast("验证码错误!");
                break;
              case '1100':
                vant.Toast("验证码已经失效!");
                break;
              case '1005':
                vant.Toast("账号异常!");
                break;
            }
          }
        }).catch((err) => {
          console.log(err, "手机号登录")
        })

      },
      instructions(i) {
        this.tructions = true;
      },
      // 获取登录信息
      getUserDetail() {
        $axios.getUserDetail({ access: this.UserData.access })
          .then((res) => {
            this.Reload(res.data.code);
            if (res.data.status == 1 && res.data.code == 1008) {
              this.Log_out()
            } else if (res.data.status == 2) {
              this.UserData = res.data.data;
              if (this.UserData.bind === '1') {
                this.step = 1
              } else {
                this.step = 3
              }

              if (Object.keys(res.data.data.award).length) {
                var award = res.data.data.award
                vant.Toast(award.title + award.tip + '+' + award.worth)
              }
              store.set('User_information', this.UserData)
            }
          }).catch((err) => { })
      },
      // 获取任务列表
      getList() {
        $axios.getList({ access: this.UserData.access, area: 1 })
          .then((res) => {
            this.User_TaskList = res.data.data
            store.set('User_TaskList', this.User_TaskList)
          })
          .catch((err) => {
            console.log(err)
          })
      },
      // 中奖纪录 ok
      getgetRecord() {
        $axios.getgetRecord({ access: this.UserData.access })
          .then((res) => {
            this.WinningRecord = res.data.data;
            store.set('WinningRecord', this.WinningRecord)
          })
          .catch((err) => {
            console.log(err, "中奖纪录")
          })
      },
      // 转盘消息
      getlotteryAward() {
        var data = {};
        if (this.UserStatus) {
          data = {
            access: this.UserData.access
          }
        }
        $axios.getlotteryAward(data)
          .then((res) => {
            console.log(res, "奖池")
            this.TurntableMessage = res.data.data;
            this.commonProgress = res.data.data.base.common.progress;
            this.higherProgress = res.data.data.base.higher.progress;
            this.higherStartLeave = res.data.data.base.higher.start_leave;
            store.set('TurntableMessage', this.TurntableMessage)
            this.Reload(res.data.code);
          })
          .catch((err) => {
            console.log(err)
          })
      },
      // 组队信息查询 *
      getInformationService() {
        $axios.getInformationService({ access: this.UserData.access, area: 1 })
          .then((res) => {
            console.log(res, "信息查询")
          })
          .catch((err) => {
            console.log(err)
          })
      },
      // 里程碑进度  *ok
      getLichengbeiList() {
        var data = { area: 2 };
        if (this.UserStatus) {
          data = {
            area: 2,
            access: this.UserData.access
          }
        }
        $axios.getList(data)
          .then((res) => {
            this.MilestoneSchedule = res.data.data.detail//里程碑数据
            this.coinCount = res.data.data.coinCount//贡献比索
            this.unlock = res.data.data.unlock//解锁节点数 
            store.set("MilestoneSchedule", this.MilestoneSchedule);
            this.Reload(res.data.code);
          })
          .catch((err) => { console.log(err) })
      },
      // 里程碑规则弹窗
      lichenbeiRulesOpen() {
        this.lichenbeiRules_Show = true
      },
      // 登录注册弹框
      login() {
        this.loginPop = true;
      },
      //退出登录
      Log_out() {
        store.clear()//清空本地数据
        this.UserStatus = false;
        this.UserData = {
          access: '', //秘钥
          avatar: '', //头像
          blind: '', //绑定
          status: '', //状态
          nickName: '', //昵称
          coin: 0, //雅拉币
          bullion: 0, //银条
          phone: '', //手机号
          status: '', //地址绑定状态
          award: null, //每日任务
          address: "", //地址
        };//数据清空
        this.step = 0; //任务变为第一步
      },
      //登录注册关闭按钮
      closeButton() {
        this.loginPop = false;//关闭页面弹窗
        this.user.mobilephone = '';
        this.user.code = '';
      },
      //立即绑定
      bind_now() {
        this.step = 2;
        vant.Toast("绑定成功!")
      },
      // 已预购完成组团
      reserved() {
        this.step = 3;
      },
      //抽奖规则,中奖纪录点击事件
      Lottery(i) {
        if (i === 0) {
          this.LotteryShow = true;
          this.LotteryItem = 0;
        } else {
          if (!this.UserStatus) {
            this.login();
            return false;
          }
          this.LotteryShow = true;
          this.LotteryItem = 1;
        }
      },
      //收获地址点击事件
      Address() {
        this.LotteryShow = false;
        this.AddressShow = true;
        if (this.UserData.address) {
          this.midd_list = JSON.parse(this.UserData.address)
          this.regionArr.forEach((item) => {
            if (item.name === this.midd_list.province) {
              this.cityArr = item.city;
            }
          });
          this.cityArr.forEach((item) => {
            if (item.name === this.midd_list.city) {
              this.areaArr = item.area;
            }
          });
          console.log("midd_list", this.midd_list)
        }
      },
      // 收货地址提交
      submitAddress() {
        if (!this.isCanSubmitAddress) {
          return false;
        }
        if (this.midd_list.name === '') {
          vant.Toast("名字不能为空")
          return false;
        }
        if (!regPhone.test(this.midd_list.phone)) {
          vant.Toast("手机号格式错误")
          return false;
        }
        if (!(this.midd_list.province !== '' && this.midd_list.city !== '' && this.midd_list.address !== '')) {
          vant.Toast("地区不能为空")
          return false;
        }
        this.isCanSubmitAddress = false
        var collect = {
          name: this.midd_list.name,
          phone: this.midd_list.phone,
          province: this.midd_list.province,
          city: this.midd_list.city,
          area: this.midd_list.area,
          address: this.midd_list.address
        }
        $axios.getblindAddress({
          access: this.UserData.access,
          detail: JSON.stringify(collect),
        }).then((res) => {
          this.isCanSubmitAddress = true
          vant.Toast("提交成功！")
          this.getUserDetail()
          this.AddressShow = false;
        }).catch((err) => { console.log(err) })
      },
      // 中奖纪录单个查看
      awardView(i) {
        // this.WinningItems = item;
        this.WinningRecordBulletBox = true;
        this.WinningNum = i;
        this.kinNumber = this.WinningRecord[i].kind
        // if (item.kind == 2) {
        //   this.idCard = item.idCard
        // }
        // this.WinningBox_title = "奖品详情"
      },
      //立即组队 
      Teamupnow(i) {
        if (i === 0) {
          location.href = '../new/card/index.html';
        }
        if (i === 1) {
          location.href = '../puzzle/index.html'
        }
      },
      // 预览图片
      viewPicure(index) {
        this.pictureView = true;
        this.viewPictureIndex = index;
      },
      // 前往任务
      goTask(sort) {
        this.task_list_show = false
        if (sort === 2) { //明信片
          location.href = '../new/card/index.html';
        } else if (sort === 3) { //游戏
          location.href = '../puzzle/index.html';
        } else if (sort === 4) { //组队
          this.onclick(2)
        } else {
          return false
        }
      },
      getImage(pic) {
        return imgUrl + pic;
      },
      // 查看优惠券
      loolCoupons(item) {
        if (!this.UserStatus) {
          this.login();
          return false;
        }
        this.couponsShow = true
        this.couponsSingleData = item
      },
      // 优惠券是否过期
      isNoExpire(expire) {
        var millisecond = new Date().getTime()
        return expire > millisecond / 1000
      },
      // 领取优惠券
      collectCoupons(item) {
        if (!this.UserStatus) {
          this.login();
          return false;
        }
        this.isCanclickCoupons = false
        $axios.getreceiveAward({
          access: this.UserData.access,
          sign: item.sign,
        }).then((res) => {
          if (res.data.status == 2) {
            vant.Toast("领取成功！")
            setTimeout(() => {
              this.getUserDetail(); //更新用户信息
              this.getLichengbeiList()
              this.isCanclickCoupons = true
            }, 3000);
          } else {
            this.isCanclickCoupons = true
          }
        }).catch((err) => { this.isCanclickCoupons = true })
      },
      // 宝箱剩余时间
      getTimeCountDown(timeStamp) {
        if (this.higherProgress === 'off') {
          var lefttime = Number(timeStamp) * 1000
          leftd = Math.floor(lefttime / (1000 * 60 * 60 * 24)),  //计算天数
            lefth = Math.floor(lefttime / (1000 * 60 * 60) % 24)  //计算小时数
          return "距离开放还有" + leftd + "天" + lefth + "小时"
        } else {
          return ''
        }
      },
      // 优惠券 过期时间
      youhuiquanExpire(timeStamp) {
        var nowtime = new Date(),  //获取当前时间
          endtime = new Date(Number(timeStamp) * 1000);  //定义结束时间
        var lefttime = endtime.getTime() - nowtime.getTime(),  //距离结束时间的毫秒数
          leftd = Math.floor(lefttime / (1000 * 60 * 60 * 24)),  //计算天数
          lefth = Math.floor(lefttime / (1000 * 60 * 60) % 24),  //计算小时数
          leftm = Math.floor(lefttime / (1000 * 60) % 60),  //计算分钟数
          lefts = Math.floor(lefttime / 1000 % 60);  //计算秒数
        return leftd + "天" + lefth + "小时" + leftm + "分"
        // + lefts + "秒"
      },
      // 是否可以修改地址
      addressIsCanUpdate() {
        var nowtime = new Date(),  //获取当前时间
          endtime = new Date("2021-10-22 00:00:00");  //定义结束时间
        return nowtime.getTime() >= endtime.getTime()
      },
      // 微信登录
      weixinLogin() {
        var wechatAppId = "wxf6b9a58bf53410e3";
        // var targetUrl = "http://192.168.0.42:5500/wap/index.html";
        var targetUrl = "http://yubi.aju.cn/wap/index.html";

        var authUrl = "https://app.jingsocial.com/api/oauth/authorize?scope=snsapi_userinfo&appid=" + wechatAppId + "&redirect_uri=" + encodeURIComponent(targetUrl);
        var a = document.createElement('a'); // 创建一个a节点插入的document
        var event = new MouseEvent('click') // 模拟鼠标click点击事件
        a.href = authUrl; // 将图片的src赋值给a节点的href
        a.dispatchEvent(event) // 触发鼠标点击事件
      },
      // 获取url参数
      getJsUrl() {
        var weixinJson = {}
        var str = decodeURIComponent(location.href)
        if (str.indexOf("?") > -1) {
          var parastr = str.split("?")[1]
          var arr = parastr.split("&")
          for (var i = 0; i < arr.length; i++) {
            weixinJson[arr[i].split("=")[0]] = arr[i].split("=")[1]
          }
        }
        return weixinJson;
      },
      // 微信授权
      moreLogin(weixinData) {
        $axios.moreLogin({ detail: JSON.stringify(weixinData) }).then(res => {
          console.log(res, "微信授权")
          if (res.data.status === 2) {
            if (res.data.data.phone_need === 1) {
              this.UserData = res.data.data.info;
              this.UserStatus = true;
              if (this.UserData.bind === '1') {
                this.step = 1
              } else {
                this.step = 3
              }
              store.set('status', true)
              store.set('User_information', this.UserData)
              vant.Toast("登录成功!")
              this.weixinShow = false;
              // 获取任务列表
              this.getList();
              // 转盘消息（奖品列表）
              this.getlotteryAward();
              // 里程碑进度  *ok
              this.getLichengbeiList();
              // 中奖记录
              this.getgetRecord();
              // 用户信息
              this.getUserDetail();
              setTimeout(() => {
                this.closeButton(); //关闭弹窗
              }, 680)
            } else {
              this.closeButton()
              this.import = res.data.data.import; //秘钥
              this.bindPhonePop = true; //微信绑定弹框
            }
          }
        })
      },
      // 手机号码绑定
      bindPhone() {
        $axios.otherLogin({
          phone: this.user.mobilephone,
          code: this.user.code,
          import: this.import
        }).then(res => {
          if (res.data.status === 2) {
            this.UserData = res.data.data;
            this.UserStatus = true;
            // if (this.UserData.bind === '1') {
            //   this.step = 1
            // } else {
            //   this.step = 3
            // }
            store.set('status', true)
            store.set('User_information', this.UserData)
            vant.Toast("绑定成功!")
            // 获取任务列表
            this.getList();
            // 转盘消息（奖品列表）
            this.getlotteryAward();
            // 里程碑进度  *ok
            this.getLichengbeiList();
            // 中奖记录
            this.getgetRecord();
            // 用户信息
            this.getUserDetail();
            setTimeout(() => {
              this.bindPhonePop = false
              this.user.mobilephone = '';
              this.user.code = '';
            }, 680)
          } else {
            vant.Toast(res.data.info)
          }
        })
      },
      // 是否为微信浏览器
      isWeixn() {
        var ua = navigator.userAgent.toLowerCase();
        if (ua.match(/MicroMessenger/i) == "micromessenger") {
          return true;
        } else {
          return false;
        }
      },
      //多设备登录 踢出
      Reload(data) {
        if (data == 1008) {
          store.clear()//清空本地数据
          vant.Toast("当前设备已在其他设备登录,请重新登录");
          this.UserStatus = false;//状态更新
          location.reload()// 刷新页面
        }
      },
    },
    computed: {
      Winningfn() {
        if (this.LotteryItem == 1) {
          return this.WinningRecord.filter((item, index) => {
            return index == this.WinningNum
          })
        }
      },
    },
  })
}

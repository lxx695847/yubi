window.onload = function () {
  window.app = new Vue({
    el: '#mxp',
    data() {
      return {
        order: 0,//步骤
        // 选择图片
        tup: [
          'pic1', 'pic2', 'pic3',
        ],
        cur: 0,
        SeleSwith: false,
        // 选择卡片
        card: [
          'card1', 'card2', 'card3',
        ],
        card_num: 0,
        cardSwith: false,
        cardItem: false,
        // 文案输入
        confirm: false,

        //选择邮票
        stampsPic: ['stamp1', 'stamp2', 'stamp3'],
        stamps_num: 0,
        stampShow: false,
        stampItem: false,
        // 选择邮戳
        postmarkPic: ['postmark1', 'postmark2', 'postmark3'],
        postmark_num: 0,
        postmarkShow: false,
        postmarkItem: false,

        close: false,// 关闭按钮
        QrCode: false,//二维码

        Photo: [],//图片集
        userTxet: false,
        UserInfo: {
          name: '',
          text: '雅拉风光无限好',
          id: '',
        },
        Fuser: null,

        isOff: true,
        Tips: '播放',

        user: {
          mobilephone: '',// 手机号
          code: '',//验证码
        },
        canClick: true, //验证码状态
        content: '获取验证码', // 按钮里显示的内容
        pear: false, //登录弹框默认隐藏
        codeStatus: true,
        totalTime: 60,//验证码倒计时
        cardMation: null,
        UserStatus: false,
        copy: "孤岛惊魂6雅拉之旅活动进行中，3A大作限量周边数码硬件众多好礼等你来拿！快来生成专属于你的雅拉明信片吧https://yara.ubisoft.com.cn/new/card/index.html",
        remnant: 7,//文案初始长度

        PictureResults: false,//图片保存 结果页
        imgUrl: '',
        loginBox: false,
        Notlogged: false,
        openDataShow: false,


        import: "", //微信绑定使用
        bindPhonePop: false, //绑定电话弹窗
        bindPhonePop: false,
      }
    },
    created() {
      this.UserStatus = store.get('status');//登录状态
      this.UserData = store.get('User_information');
      let self = this;
      if (this.UserStatus) {
        //更新用户信息
        this.getUserDetail();
      }

      // 照片集
      $axios.getGroup({ area: 2, })
        .then((res) => {
          console.log(res, "图片集")
          self.Photo = res.data.data;

          self.Photo.card.forEach((item) => {
            return item.src = imgUrl + item.src
          })
          self.Photo.photo.forEach((item) => {
            return item.src = imgUrl + item.src
          })
          self.Photo.poster.forEach((item) => {
            return item.src = imgUrl + item.src
          })
          self.Photo.mark.forEach((item) => {
            return item.src = imgUrl + item.src
          })
        }).catch((err) => { })

      setTimeout(() => {
        document.getElementsByClassName("goTo")[0].style = "display:none"
      }, 2400)
    },

    mounted() {
      if (this.UserStatus) {
        this.getGroup(3);//最新记录
      };
      this.$nextTick(() => {
        this.PendantIsOpen();
      });
      // 如果是微信浏览器
      if (this.isWeixn()) {
        var weixinData = this.getJsUrl()
        if (weixinData.openid && weixinData.unionid) {
          this.moreLogin(weixinData)
        }
      }
    },
    watch: {

    },
    methods: {
      // 微信登录
      weixinLogin() {
        var wechatAppId = "wxf6b9a58bf53410e3";
        var targetUrl = "http://192.168.0.42:5500/new/card/index.html";
        // var targetUrl = "http://yubi.aju.cn/new/card/index.html";

        var authUrl = "https://app.jingsocial.com/api/oauth/authorize?scope=snsapi_userinfo&appid=" + wechatAppId + "&redirect_uri=" + encodeURIComponent(targetUrl);
        var a = document.createElement('a'); // 创建一个a节点插入的document
        var event = new MouseEvent('click') // 模拟鼠标click点击事件
        a.href = authUrl; // 将图片的src赋值给a节点的href
        a.dispatchEvent(event) // 触发鼠标点击事件
      },
      // 获取url参数
      getJsUrl() {
        var weixinJson = {}
        var str = decodeURIComponent(location.href)
        if (str.indexOf("?") > -1) {
          var parastr = str.split("?")[1]
          var arr = parastr.split("&")
          for (var i = 0; i < arr.length; i++) {
            weixinJson[arr[i].split("=")[0]] = arr[i].split("=")[1]
          }
        }
        return weixinJson;
      },
      // 微信授权
      moreLogin(weixinData) {
        $axios.moreLogin({ detail: JSON.stringify(weixinData) }).then(res => {
          console.log(res, "微信授权")
          if (res.data.status === 2) {
            if (res.data.data.phone_need === 1) {
              this.UserData = res.data.data.info;
              this.UserStatus = true;

              // if (this.UserData.bind === '1') {
              //   this.step = 1
              // } else {
              //   this.step = 3
              // }

              store.set('status', true)
              store.set('User_information', this.UserData)
              vant.Toast("登录成功!")

              setTimeout(() => {
                this.closeButton(); //关闭弹窗
              }, 680)
            } else {
              document.getElementsByClassName("goTo")[0].style = "display:none"
              this.closeButton();//关闭弹窗
              this.import = res.data.data.import;
              this.bindPhonePop = true
            }
          }
        })
      },
      // 手机号码绑定
      bindPhone() {
        const reg = /^1[35789]\d{9}$/;
        if (!reg.test(this.user.mobilephone)) {
          vant.Toast("请填写正确的手机号!")
          return false
        }
        if (this.user.code == '') {
          vant.Toast("验证码不能为空!")
          return false
        }
        $axios.otherLogin({
          phone: this.user.mobilephone,
          code: this.user.code,
          import: this.import
        }).then(res => {
          if (res.data.status === 2) {
            this.UserData = res.data.data;
            this.UserStatus = true;
            // if (this.UserData.bind === '1') {
            //   this.step = 1
            // } else {
            //   this.step = 3
            // }
            store.set('status', true)
            store.set('User_information', res.data.data)
            vant.Toast("绑定成功!")

            setTimeout(() => {
              this.bindPhonePop = false;
              this.user.mobilephone = '';
              this.user.code = '';
            }, 680)
          } else {
            // vant.Toast(res.data.info)

          }
        })
      },
      // 是否为微信浏览器
      isWeixn() {
        var ua = navigator.userAgent.toLowerCase();
        if (ua.match(/MicroMessenger/i) == "micromessenger") {
          return true;
        } else {
          return false;
        }
      },
      // 自动播放
      audioAutoPlay() {
        let audio = document.getElementById("audio");
        audio.play();
        document.removeEventListener("touchstart", this.audioAutoPlay);
      },
      // 监听文案输入长度
      descInput() {
        this.remnant = this.UserInfo.text.length;
      },
      // 登录弹框
      closeButton() {
        // this.pear = false;//关闭页面弹窗
        // 清空表单数据
        this.user.mobilephone = '';
        this.user.code = '';
        this.loginBox = false;
        // document.getElementsByClassName("Mask_Box")[0].style = "display:none";
      },
      //获取验证码倒计时
      countDown() {
        const reg = /^1[35789]\d{9}$/;
        let self = this;
        if (!this.canClick) return
        if (!reg.test(this.user.mobilephone)) {
          vant.Toast('请输入正确的手机号!');
          return false;
        }
        if (!this.canClick) return //节流 每60秒只执行一次
        this.canClick = false //按钮不可点击
        let clock = window.setInterval(() => {
          self.totalTime--
          self.content = self.totalTime + 's后重新发送';

          if (self.totalTime === -1) {
            clearInterval(clock)
            self.content = '获取验证码';
            self.totalTime = 60;//验证码间隔时间
            self.canClick = true //重新开启
            self.phoneCode = ''  //验证码清除
          }
        }, 1000)

        // 请求手机验证码
        $axios.getsendReport({ phone: this.user.mobilephone })
          .then((res) => {
            if (res.data.code == 200) {
              vant.Toast("发送成功")
            } else {
              vant.Toast("发送失败!")
            }
          })
      },
      // 立即登录
      Signin() {
        const reg = /^1[35789]\d{9}$/;
        const regcode = /^[0-9]{6}$/;
        if (!reg.test(this.user.mobilephone)) {
          vant.Toast("请填写正确的手机号!")
          return false
        }
        if (this.user.code == '') {
          vant.Toast("验证码不能为空!")
          return false
        }
        if (!regcode.test(this.user.code)) {
          vant.Toast("验证码长度不符合!")
          return false
        }
        // 手机号登录
        $axios.getLogin({
          phone: this.user.mobilephone,
          code: this.user.code,
        }).then((res) => {
          if (res.data.status == 2) {
            vant.Toast('登录成功');
            this.UserStatus = true;
            store.set('status', true)
            this.UserData = res.data.data;
            store.set('User_information', res.data.data)
            setTimeout(() => {
              this.closeButton(); //关闭弹窗
            }, 680)
          }
          if (res.data.status == 1) {
            if (res.data.code == 1200) {
              vant.Toast("验证码错误!")
            } else if (res.data.code == 1100) {
              vant.Toast("验证码已经失效!")
            } else if (res.data.code == 1005) {
              vant.Toast("用户状态异常，请联系客服");
            }
            return false;
          }

        }).catch((err) => { })
      },
      //返回首页
      ToHome() {
        location.replace('../../index.html')
      },
      // 关闭按钮
      onClose() {
        this.PictureResults = false;
      },
      //播放音乐
      play_Music() {
        let oAudio = document.querySelector("#audio");
        let music = document.querySelector(".music")
        if (this.isOff) {
          oAudio.play();//让音频文件开始播放 
          this.Tips = '暂停';
          music.src = './image/play.png';

        } else {
          oAudio.pause();//让音频文件暂停播放 
          this.Tips = '播放';
          music.src = './image/closePlay.png';
        }
        this.isOff = !this.isOff;
      },
      // 选择照片
      SelectPic(i) {
        this.cur = i
      },
      //
      show_pic(i) {
        if (this.SeleSwith) {
          if (this.cur === i) {
            return true
          } else {
            return false;
          }
        }
        return true
      },
      //选择卡片
      SelectCard(i) {
        this.card_num = i
      },
      show_card(i) {
        if (this.cardSwith) {
          if (this.card_num === i) {
            return true
          } else {
            return false;
          }
        }
        return true
      },
      // 文案输入 确认
      ConFirm() {
        let flg = this;
        if (!this.UserInfo.text.length) {
          vant.Toast("寄语不能为空!")
          return false;
        }
        this.order++;
        this.confirm = false;//文案输入框关闭
        setTimeout(() => {
          flg.stampShow = true;
          flg.userTxet = true;
        }, 500)
      },
      // 跳过
      coskip() {
        let flg = this;
        this.order++;
        this.confirm = false;//文案输入框关闭
        setTimeout(() => {
          flg.stampShow = true;
          flg.userTxet = true;
          this.UserInfo.text = '雅拉风光无限好';
        }, 500)
      },
      // 选择邮票
      show_stamps(i) {
        if (this.stampItem) {
          if (this.stamps_num === i) {
            return true
          } else {
            return false;
          }
        }
        return true
      },
      //选择邮戳
      show_postmark(i) {
        if (this.postmarkItem) {
          if (this.postmark_num === i) {
            return true
          } else {
            return false;
          }
        }
        return true
      },
      //照片确认按钮
      pic_btn() {
        this.SeleSwith = true;
        document.querySelector(".Pic_cur").classList.add("active_Pic");
        this.order++
        setTimeout(() => {
          this.cardItem = true;
          document.getElementsByClassName("box")[0].style = "display:block"
        }, 300)
      },
      //卡片确认按钮
      card_btn() {
        let flg = this;
        this.cardSwith = true
        document.querySelector(".card_num").classList.add("active_Card");
        this.order++
        flg.confirm = true;

      },
      // 邮票确认按钮  
      stamp_btn() {
        let flg = this;
        this.stampItem = true
        document.querySelector(".active_stamps").classList.add("animate")
        this.order++
        setTimeout(() => {
          flg.postmarkShow = true;
        }, 300)
      },
      //邮戳确认按钮  
      postmark_btn() {
        let flg = this;
        if (!this.UserStatus) {
          this.loginBox = true;
          return false;
        }
        this.order++;
        this.postmarkItem = true;
        document.querySelector(".active_postmark").classList.add("active_trans")


        console.log(this.UserInfo.text)
        $axios.getcardResult({
          result: {
            'photo': this.cur + 1,
            'card': this.card_num + 1,
            'poster': this.stamps_num + 1,
            'mark': this.postmark_num + 1,
            'title': this.UserInfo.text,
          },
          access: this.UserData.access,
        }).then((res) => {
          this.cardMation = res.data.data
          console.log(res, "提交返回")
          if (Object.keys(res.data.data.award).length) {
            let award = res.data.data.award
            // vant.Toast(award.title + '奖励' + award.tip + '+' + award.worth);
            vant.Toast.success({
              duration: 2500,
              message: award.title + '奖励' + award.tip + '+' + award.worth,
            });
            this.getUserDetail();
          }
        }).catch((err) => { })

      },
      // 重新开始
      onNew() {
        this.order = 0;//清空步骤
        this.SeleSwith = false;
        this.cardSwith = false;
        this.cardItem = false;
        this.confirm = false;
        this.stampShow = false;
        this.stampItem = false;
        this.postmarkShow = false;
        this.postmarkItem = false;
        this.userTxet = false;
        this.UserInfo.text = "雅拉风光无限好"
        document.querySelector(".active_postmark").classList.remove("active_trans");
        document.querySelector(".active_stamps").classList.remove("animate");
        document.querySelector(".card_num").classList.remove("active_Card");
        document.querySelector(".Pic_cur").classList.remove("active_Pic");
        document.getElementsByClassName("box")[0].style = "display:none";
      },
      // 寄出分享
      share() {
        // this.QrCode = true;
        this.order++;
        this.PictureResults = true; //结果页
        // 提交分享
        this.geteditState();
      },
      // 保存图片按钮
      Ex_share() {
        this.downloadImg();
      },
      // 保存图片
      downloadImg() {
        // var img = document.getElementById('testImg'); // 获取要下载的图片
        // var url = img.src; // 获取图片地址
        // var a = document.createElement('a'); // 创建一个a节点插入的document
        // var event = new MouseEvent('click') // 模拟鼠标click点击事件
        // a.download = '雅拉明信片' // 设置a节点的download属性值
        // a.href = url; // 将图片的src赋值给a节点的href
        // a.dispatchEvent(event) // 触发鼠标点击事件

        var image = new Image()
        image.setAttribute('crossOrigin', 'anonymous')
        image.onload = function () {
          var canvas = document.createElement('canvas')
          canvas.width = image.width
          canvas.height = image.height
          var context = canvas.getContext('2d')
          context.drawImage(image, 0, 0, image.width, image.height)
          var url = canvas.toDataURL('image/png')
          // 生成一个a元素
          var a = document.createElement('a')
          // 创建一个单击事件
          var event = new MouseEvent('click')
          // 将a的download属性设置为我们想要下载的图片名称，若name不存在则使用‘下载图片名称’作为默认名称
          a.download = '雅拉明信片'
          // 将生成的URL设置为a.href属性
          a.href = url
          // 触发a的单击事件
          a.dispatchEvent(event)
        }
        image.src = document.querySelector("#testImg").src

      },
      //提交分享
      geteditState() {
        console.log(this.UserInfo.text)
        // 提交分享
        $axios.geteditState({
          sign: this.cardMation.sign,
          access: this.UserData.access,
          title: this.UserInfo.text,
        }).then((res) => {
          console.log(res, "提交分享")
          if (Object.keys(res.data.data.award).length) {
            let award = res.data.data.award
            // vant.Toast(award.title + '奖励' + award.tip + '+' + award.worth);
            vant.Toast.success({
              duration: 2500,
              message: award.title + '奖励' + award.tip + '+' + award.worth,
            });

            //更新数据
            this.getUserDetail();
          }
          this.imgUrl = res.data.data.imgSrc;
          console.log(res.data.data.imgSrc)
          document.getElementsByClassName("ResPic")[0].src = `${this.imgsUrl(res.data.data.imgSrc)}`;
          // document.getElementsByClassName("pic")[0].style = `background-image:url('${this.imgsUrl(res.data.data.imgSrc)}')`;
          // this.downloadImg();
        }).catch((err) => {
          console.log(err)
        })
      },
      // 照片集 最新记录
      getGroup(item) {
        let data = {
          area: item,
        }
        if (this.UserStatus && item == 3) {
          data = {
            area: item,
            access: this.UserData.access,
          }
        }
        $axios.getGroup(data)
          .then((res) => {
            if (item == 2) {

              self.Photo = res.data.data;
              self.Photo.card.forEach(function (item) {
                return item.src = imgUrl + item.src
              })
              self.Photo.photo.forEach(function (item) {
                return item.src = imgUrl + item.src
              })
              self.Photo.poster.forEach(function (item) {
                return item.src = imgUrl + item.src
              })
              self.Photo.mark.forEach((item) => {
                return item.src = imgUrl + item.src
              })
            }
            if (item == 3) {
              console.log(res, "最新记录")

              // console.log(Object.keys(res.data.data).length)
              if (Object.keys(res.data.data).length) {
                let { photo, card, poster, markid, title } = res.data.data;
                //照片
                this.cur = photo - 1;
                //卡片
                this.card_num = card - 1;
                //文案确认
                this.UserInfo.text = title;
                //邮票
                this.stamps_num = poster - 1;
                //邮戳
                this.postmark_num = markid - 1;
                // setTimeout(() => {
                //   this.pic_btn();
                //   this.card_btn();
                //   this.ConFirm();
                //   this.stamp_btn();
                //   this.postmark_btn();
                // }, 1200)
                // this.$nextTick(() => {
                //   this.confirm = false;//文案输入框关闭
                // })
                // setTimeout(() => {
                //   this.confirm = false;//文案输入框关闭
                // }, 1500)
              }
            }
          }).catch((err) => { })
      },
      //更新数据 用户信息回调
      getUserDetail() {
        $axios.getUserDetail({ access: this.UserData.access, })
          .then((res) => {
            if (res.data.status == 2) {

              this.UserData = res.data.data;
              store.set("User_information", res.data.data); //更新用户信息
              // 自动任务
              if (Object.keys(res.data.data.award).length) {
                let award = res.data.data.award
                // vant.Toast(award.title + '奖励' + award.tip + '+' + award.worth);
                vant.Toast.success({
                  duration: 2500,
                  message: award.title + '奖励' + award.tip + '+' + award.worth,
                });
                this.getUserDetail();
              }
            } else {
              this.Reload(res.data.code);
            }
          })
          .catch((err) => {

          })
      },
      //其他设备登录
      Reload(data) {
        if (data == 1008) {
          store.clear()//清空本地数据
          vant.Toast("当前设备已在其他设备登录,请重新登录");
          this.UserStatus = false;//状态更新
          location.reload()// 刷新页面
        }
      },
      //返回图片地址
      setUrl(item) {
        return imgUrl + item;
      },
      // img
      imgsUrl(item) {
        return 'http://yubi.aju.cn/' + item;
      },
      //高级宝箱 挂件开启
      PendantIsOpen() {
        var nowtime = new Date(),  //获取当前时间
          endtime = new Date("2021-10-14 00:00:00");  //定义结束时间
        let flg = nowtime.getTime() >= endtime.getTime();
        // 到达指定时间
        if (flg) {
          this.Notlogged = true;
          // 登录后
          if (this.UserStatus) {
            this.openDataShow = true;
          }
        }
      },
    },

  })





}



// http://ybadmin.aju.cn/Uploads/rule/card.jpg
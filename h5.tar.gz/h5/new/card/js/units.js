const baseURL = "http://ybadmin.aju.cn/"
const imgUrl = baseURL + "Uploads/";

// http://ybadmin.aju.cn/Uploads/

axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';
const $axios = {
  //手机号登陆
  async getLogin(data) {
    return await axios({ url: baseURL + 'getLogin', method: 'POST', params: data })
  },
  // 请求手机验证码
  async getsendReport(data) {
    return await axios({ url: baseURL + 'sendReport', method: 'POST', params: data })
  },
  // 照片集1 最新记录3
  async getGroup(data) {
    return await axios({ url: baseURL + 'getGroup', method: 'POST', params: data })
  },
  //提交返回
  async getcardResult(data) {
    return await axios({ url: baseURL + 'cardResult', method: 'POST', params: data })
  },
  // 提交分享
  async geteditState(data) {
    return await axios({ url: baseURL + 'editState', method: 'POST', params: data })
  },
  // 获取登录信息
  async getUserDetail(data) {
    return await axios({ url: baseURL + 'getDetail', method: 'POST', params: data })
  },

  
  //微信三方授权
  async moreLogin(data) {
    return await axios({ url: baseURL + 'moreLogin', method: 'POST', params: data })
  },

  //微信第三方登录
  async otherLogin(data) {
    return await axios({ url: baseURL + 'otherLogin', method: 'POST', params: data })
  },
}


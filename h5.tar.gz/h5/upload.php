<?php
header("content-type:text/html;charset=utf-8");
$file = $_FILES["file_via_curl"];

//获取文件名
$filename = $file['name'];
	//获取文件临时路径
$temp_name = $file['tmp_name'];
$arr = pathinfo($filename);
//获取文件的后缀名
$ext_suffix = $arr['extension'];
$error = $_FILES['file']['error'];
//检测存放上传文件的路径是否存在，如果不存在则新建目录
if (!file_exists('uploads')){
	mkdir('uploads');
}
	//为上传的文件新起一个名字，保证更加安全
$new_filename = date('YmdHis',time()).rand(100,1000).'.'.$ext_suffix;
	//将文件从临时路径移动到磁盘
if (move_uploaded_file($temp_name, 'uploads/'.$new_filename)){
	   echo 'uploads/'.$new_filename;
}else{
	   echo $error;
}
?>
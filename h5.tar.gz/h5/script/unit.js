// //验证手机号合法性
// function validatePhone(value, callback) {
//   const reg = /^[1][3-9][0-9]{9}$/;
//   if (value == '' || value == undefined || value == null) {
//     callback();
//   } else {
//     if ((!reg.test(value)) && value != '') {
//       callback(new Error('请输入正确的电话号码'));
//     } else {
//       callback();
//     }
//   }
// }

// function Post(url, data, cb, fa) {
//   return new Promise((resolve, reject) => {
//     wx.request({
//       method: 'POST',
//       url: baseUrl + url,
//       data: data,
//       header: {
//         'content-type': 'application/x-www-form-urlencoded'
//       },
//       success: (res) => {
//          resolve(res.data)
//       },
//       fail: (err) => {
//         reject(err);
//       }
//     });
//   });
// };

// 轮播图配置项
function Rotation() {
  new Swiper(".swiper-container", {
    direction: 'horizontal', //横向切换
    autoplay: true,
    calculateHeight: true,
    pagination: {
      el: '.swiper-pagination',
      clickable :true,//小圆点
    },
    slidesPerView: 5,
    slidesPerGroup: 5,
    autoplayDisableOnInteraction: true,
    // autoplay: {
    //   delay: 4500,
    // },
    mousewheel: true,
  });
}

// 手机正则验证
let regPhone = /^(?:(?:\+|00)86)?1[3-9]\d{9}$/
// /^(?:(?:\+|00)86)?1\d{10}$/

// cookie 读取指定值
function getCookieValue(name) {
  let result = document.cookie.match("(^|[^;]+)\\s*" + name + "\\s*=\\s*([^;]+)")
  return result ? result.pop() : ""
}
// el:节点 
function Top_Backto(el) {
  app.$el.querySelector(el).scrollIntoView({
    behavior: "smooth",  // 平滑过渡
    block: "start"  // 上边框与视窗顶部平齐。默认值
  });
}
//禁止滚动条
function stop() {
  // var mo = function (e) { e.preventDefault(); };
  // document.body.style.overflow = 'hidden';
  // document.addEventListener("touchmove", mo, false);//禁止页面滑动
}
// 允许滚动条
function move() {
  // var mo = function (e) { e.preventDefault(); };
  // document.body.style.overflow = '';//出现滚动条
  // document.removeEventListener("touchmove", mo, false);
}

// 弹框
function message(text, time, type) {
  app.$message({
    message: text,
    center: true,
    type: type || "warning",
    // duration: time || 1800,
    // duration: 0,
  })
}

function setCookie(name, value) {
  var Days = 30; //有效期为30天
  //取出当前日期，加上30天，得出有效截止日期
  var exp = new Date();
  exp.setTime(exp.getTime() + 30 * 24 * 60 * 60 * 1000);

  document.cookie = name + "=" + escape(value) + ";expries=" + exp.toGMTString();
}

function getCookie(name) {
  var arr, reg = new RegExp("(^| )" + name + "=([^;]*)(;|$)");
  if (arr = document.cookie.match(reg))
    return unescape(arr[2]);
  else
    return null;
}


//随机 (type为2是包括上限值)
function getRound(lower, upper, type) {
  var rand = "";
  switch (type) {
    case 1:
      rand = Math.floor(Math.random() * (upper - lower)) + lower;
      break;
    case 2:
      rand = Math.floor(Math.random() * (upper - lower + 1)) + lower;
      break;
    case 3:
      //随机小数
      rand = (Math.random() * (upper - lower) + lower).toFixed(2);
      break;
  }
  return rand;
}

document.onselectstart = function () { return false; }; //取消字段选择功能



//时间戳格式转换 毫秒
function gettimer(time) {
  var m = Math.floor(time / 1000 / 60 % 60);
  var s = Math.floor(time / 1000 % 60);
  var ms = Math.floor(time % 1000) / 10;
  // console.log(ms)
  if (ms < 10) {
    ms = "0" + ms
  }
  if (s < 10) {
    s = "0" + s;
  }
  if (m < 10) {
    m = "0" + m;
  }
  return m + "分" + s + "秒" + ms;

}

function getTime(time, type) {
  var date = "";  //用时
  var d = parseInt(time / (3600 * 24))
  var h = parseInt(time % 86400 / 3600);
  var m = parseInt(time % 3600 / 60);
  var s = parseInt(time % 60);
  d = d < 10 ? "0" + d : d;
  h = h < 10 ? "0" + h : h;
  m = m < 10 ? "0" + m : m;
  s = s < 10 ? "0" + s : s;
  if (type == 1) {
    if (d == 0) {
      if (h == 0) {
        if (m == 0) {
          if (s == 0) {
            date = '';
          } else {
            date += s + "秒";
          }
        } else {
          date += m + "分" + s + "秒";
        }
      } else {
        date += h + "时" + m + "分" + s + "秒";
      }
    } else {
      date += d + "天" + h + "时" + m + "分";
      // + s + "秒"
    }
  } else {
    // if (d == 0) {
    //   date += d + "天" + h + "时";
    //   if (h == 0) {
    //     date = '';
    //   } else{
    //     date += d + "天" + h + "时";
    //   }
    // }
    if (d == 0) {
      if (h == 0) {
        if (m == 0) {
          data = ''
        } else {
          date += m + "分" + s + "秒";
        }
      } else {
        date += h + "时" + m + "分" + s + "秒";
      }
    } else {
      date += d + "天" + h + "时" + m + "分";
    }

  }

  return date;
}
// vue 时间倒计时
//时间倒计时函数
// countdown() {
//   const end = Date.parse(new Date('2021-10-07'))
//   const now = Date.parse(new Date())
//   const msec = end - now
//   let day = parseInt(msec / 1000 / 60 / 60 / 24)
//   let hr = parseInt(msec / 1000 / 60 / 60 % 24)
//   let min = parseInt(msec / 1000 / 60 % 60)
//   let sec = parseInt(msec / 1000 % 60)
//   this.day = day
//   this.hr = hr > 9 ? hr : '0' + hr
//   this.min = min > 9 ? min : '0' + min
//   this.sec = sec > 9 ? sec : '0' + sec
//   const that = this
//   setTimeout(function () {
//     that.countdown()
//   }, 1000)
// },

let myDate = parseInt(new Date().getTime() / 1000);






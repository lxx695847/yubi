// 育碧
const baseURL = "http://ybadmin.aju.cn/"
const imgUrl = baseURL + "Uploads/";

const service = axios.create({
  baseURL: "http://ybadmin.aju.cn/",
  method: 'post',
  // withCredentials: true, // 若跨域请求需要带 cookie 身份识别
  // headers: {
  //   'content-type': 'application/x-www-form-urlencoded',
  //   // 'content-type': 'application/x-www-form-urlencoded'
  //   // Access-Control-Allow-Method
  // },
});

// mock模拟数据
const instance = axios.create({
  baseURL: 'https://www.fastmock.site/mock/072075cf79332a2fd1aec73eab922d80/api',
  // timeout: 1000,
  // headers: { 'X-Custom-Header': 'foobar' }
});

axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';
const $axios = {
  // 请求手机验证码
  async getsendReport(data) {
    return await axios({ url: baseURL + 'sendReport', method: 'POST', params: data })
  },
  //手机号登陆
  async getLogin(data) {
    return await axios({ url: baseURL + 'getLogin', method: 'POST', params: data })
  },

  // 任务列表  area: 1 / 里程碑进度  area: 2
  async getList(data) {
    return axios({ url: baseURL + 'getList', method: 'POST', params: data })
  },
  // 任务/里程碑领取奖励
  async getreceiveAward(data) {
    return await axios({ url: baseURL + 'receiveAward', method: 'POST', params: data })
  },
  // 信息查询
  async getInformationService(data) {
    return await axios({ url: baseURL + 'getGroup', method: 'POST', params: data })
  },
  // 中奖纪录
  async getgetRecord(data) {
    return await axios({ url: baseURL + 'getRecord', method: 'POST', params: data })
  },
  // 收货地址绑定
  async getblindAddress(data) {
    return await axios({ url: baseURL + 'blindAddress', method: 'POST', params: data })
  },

  //转盘消息 area 1为普通，2高级
  async getlotteryAward(data) {
    return await axios({ url: baseURL + 'lotteryAward', method: 'POST', params: data })
  },

  // 抽奖领奖 access：秘钥 pass签名
  async getlotteryReceive(data) {
    return await axios({ url: baseURL + 'lotteryReceive', method: 'POST', params: data })
  },

 // 获取登录信息
  async getUserDetail(data) {
    return await axios({ url: baseURL + 'getDetail', method: 'POST', params: data })
  },

  //明信片 照片ji
  async getGroup(data) {
    return await axios({ url: baseURL + 'getGroup', method: 'POST', params: data })
  },

}














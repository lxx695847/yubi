window.onload = function () {
  window.app = new Vue({
    el: '#app',
    data() {
      return {
        //页头标题
        textheader: ['明信片', '组团游览', '雅拉寻宝', '游乐场', '预购福利', '贡献统计', '雅拉风景'],
        // 雅拉游乐场 图片
        // imgurl: ['Mug.jpg', 'Rogue.jpg', 'GarageKit.jpg', 'dog.jpg', 'Rogue.jpg', 'character.jpg', 'Mug.jpg',
        //   'Rogue.jpg', 'GarageKit.jpg', 'dog.jpg', 'Rogue.jpg', 'character.jpg',
        // ],
        //雅拉旅游指南图片
        TravelUrl: ['coconut1.jpg', 'town2.jpg', 'island3.jpg', 'vehicle4.jpg', 'sheep5.jpg', 'locomotive6.jpg',
          'street7.jpg',
        ],
        velUrl: ['9', '10', '11', '12', '8', '1', '7', '3', '5', '2', '4', '6',],
        TravelUrl_title: [
          '狮王之塔', '海风吹拂', '东部海滩', '宁静村庄', '首都街景', '中心街区', '街区一隅', '乡间小道', '播撒希望', '英勇士兵', '游击战士', '危险分子',
        ],
        //卡片信息
        card: {
          title: ['雅拉明信片', '组团游雅拉', '雅拉寻宝记',],
          explain: ['快来挑选一张具有雅拉岛特色的明信片寄给好友吧', '呼朋唤友一起来玩 雅拉给您体验最美妙的旅行体验', '看似风平浪静的雅拉岛中似乎隐藏着巨大的秘密'],
          info: ['马上定制', '立即组团', '前往寻宝',]
        },
        // 组队流程
        team: [
          '登录活动专属账号',
          '绑定育碧账号',
          '预购《孤岛惊魂6》获取专属链接',
          '好友通过专属链接购买即可入团',
        ],
        footer_log: [
          'http://cdn.hommk.com/pcgame/ubi2015/img/u2019/wx_ico.png?1', 'https://cdn.hommk.com/pcgame/ubi2015/img/u2019/wb_ico.png?1', 'http://cdn.hommk.com/pcgame/ubi2015/img/u2019/bili_ico.png?1', 'http://cdn.hommk.com/pcgame/ubi2015/img/u2019/Tmall_icon.png?1',
        ],
        maxTip: [
          'BigPicture', , 'BigPicture', 'coconut1', 'BigPicture', 'BigPicture', 'BigPicture', 'coconut1'
        ],
        maxTipNum: -1,
        headerNum: - 1, //页头内容默认显示项
        btnFlag: null, //侧边栏状态
        content: '获取验证码', // 按钮里显示的内容
        totalTime: 60, //记录具体倒计时时间
        canClick: true, //验证码状态
        pear: false, //登录弹框默认隐藏
        // 雅拉游乐场自动轮播
        index: 0, //当前轮播页数
        timer: null, //定时器
        DoTnum: 0, // 当前小圆点状态
        BigPictureShow: false,//大图

        // 里程碑 -进度 1~6
        oneShow: false,
        twoShow: false,
        threeShow: false,
        fourShow: false,
        fiveShow: false,
        sixShow: false,
        NcbNum: -1,
        Notlogged: false,
        openDataShow: false,

        reward: false,// 查看领取虚拟奖励 弹框
        //组队开关
        flag: false,
        user: {
          mobilephone: '',// 手机号
          code: '',//验证码
        },
        codeStatus: false,//验证码状态
        phoneCode: '123456', //请求返回的手机验证码
        UserStatus: null,//用户登录状态
        //宝箱奖励弹框 
        WinningBox_Show: false,
        task_list_show: false,//任务列表弹框
        exchange_show: false,// 兑换银条弹框

        //抽奖规则 中奖纪录
        Lottery_show: false,
        Lottery_item: null,// 0抽奖 1中奖
        // 雅拉游乐场 抽奖规则文字说明  ok
        LotteryText: [
          '<h6>抽奖规则说明:</h6>「普通补给」开放时间：2021年08月30日-2021年10月21日 积分消耗：5比索/次；</br>「精英补给」开放时间：2021年10月14日-2021年10月21日 积分消耗：5个银条/次；',
          '<h6>积分获取方式:</h6> 【比索】：参与并完成「雅拉之旅」活动各项任务获取雅拉岛货币；',
          '<h6>银条获取方式: </h6>【银条】：参与「雅拉组团游」任务，每成功邀请一名用户预购《孤岛惊魂6》即可获取5 银条；</br>「普通补给」也有一定几率抽取银条；',
          '<h6>补给箱奖励发放说明：</h6>【虚拟奖品-育碧商城优惠券】-即时发放；</br>【虚拟奖品-育碧游戏】- 3个工作日内发放至绑定的育碧帐号；</br>【虚拟奖品-孤岛惊魂6游戏币】- 游戏上线后7个工作日发放；</br>【虚拟奖品-孤岛惊魂6游戏币】- 游戏上线后7个工作日发放；</br>【实物奖品】- 2021.10.21活动结束后两个月内统一发放至用户提交的收货地址；',
          '<h6>补充说明：</h6>开启补给仅消耗对应【比索】和【银条】，每日不限抽奖次数上限；</br>实物奖品中奖后，请正确填写联系方式及收货地址，逾期未填该中奖资格视为作废；</br>（2021年10月21日 23:59:59后关闭收货地址修改功能）',
        ],
        // 明信片规则    ok
        Postcard: [
          '<h6>任务说明:</h6>参与用户根据流程指引，订制专属「雅拉明信片」并分享给好友；',
          '<h6>任务奖励:</h6>分享明信片图片或链接给好友即可获得比索奖励，每日通过此方式仅可获得1次奖励；',
        ],
        // 组团游雅拉 ok！
        PostRules: [
          '<h6>任务说明:</h6>参与用户根据流程指引，注册「雅拉之旅活动专属帐号」+绑定「育碧帐号」并完成《孤岛惊魂6》预购后，可生成「专属邀请链接」，分享给好友成功邀请预购后可获得奖励；',
          '<h6>任务奖励:</h6> 1. 前2000名通过「专属邀请链接」成功邀请他人预购的用户可获得「孤岛惊魂6神秘礼品」一份;<br>（每名用户仅可通过此方式获取一次奖励）；<br>10月7日会公示中奖名单并在两个月内统一安排快递发放 </br>2. 分享「专属链接」，每通过此链接成功预购《孤岛惊魂6》一次，向分享者发放5银条奖励；</br>（每日通过此方式获取此奖励次数不设上限）；',
          '<h6>补充说明:</h6>成功邀请的银条奖励即时发放。</br>但在2021年10月7日「组团游雅拉」结束前，如有受邀者的预购进行了退款，对应邀请人获取的银条积分会做扣除处理；<br>如邀请者对自己的预购进行了退款，则账户中所有通过「组团游雅拉」获取的银条会做扣除处理；',
        ],
        // 雅拉寻宝记 ok
        YarraText: [
          '<h6>操作说明:</h6>点击空格四周相邻的碎片与空格区域交换位置，直至复原操作区域左上角的「完成版示意图」即算完成任务；',
          '<h6>排行榜说明:</h6>复原用时短者排名靠前；</br>用时相同，操作步数少者排名靠前；<br>用时和操作步数均相同，提交时间较早者排名靠前；',
          '<h6>奖励说明:</h6>完成「雅拉寻宝记」可获得比索奖励，每日通过此方式仅可获得一次奖励；</br>分享「雅拉寻宝记」链接给好友即可获得比索奖励，每日通过此方式仅可获得一次奖励；</br>2021.08.30日上线后每周为一期，直至2021年10月17日共进行7期挑战</br>每期的TOP3用户均可获得「孤岛惊魂6-标准版」一份，在7期挑战结束后统一以短信的方式将游戏兑换码发放至参与挑战登录的手机号；',
          '<h6>补充说明:</h6>每个「雅拉之旅活动专属帐号」每期挑战仅保留最优记录参与排名；</br>每个「雅拉之旅活动专属帐号」仅可获取一次TOP3排名奖励；</br>如多期有重复，则奖励发放至排名顺延对应的用户；</br>使用违规作弊手段参与挑战的用户，会取消「雅拉寻宝记」和其他模块的获奖资格，并封禁其「雅拉之旅活动专属帐号」',
        ],
        // 里程碑 ok
        MilestoneText: [
          '<h6>里程碑解锁说明:</h6>「雅拉岛」设有六个需解锁地标，所有参与活动用户累计使用【比索】达标后即刻成功解锁对应地标奖励；',
          '<h6>里程碑解锁奖励发放说明:</h6>所有参与「雅拉之旅」的用户均可在地标解锁后手动领取奖励；<br>部分奖励有时效限制，超出则无法使用；',
        ],
        // 收获地址弹框
        Address_show: false,
        number: 0,//宝箱开启次数
        // 时间倒计时
        day: 0, hr: 0, min: 0, sec: 0,
        listBoxState: true,//点击导航栏时，暂时停止监听页面滚动
        // 预购状态
        PreOrderStatus: false,
        // 收货地址信息
        midd_list: {
          name: '',//姓名
          phone: '',//手机
          province: '', //被选择的省
          city: '',  //被选择的市
          area: '',  //被选择的区
          address: "", //详细地址

          collect: '',//返回全部地址信息
        },
        //是否可以提交地址
        isCanSubmitAddress: true,
        // 省市区地区消息
        arr: Data,//地区数据
        cityArr: [], //选择对应省的市数据
        areaArr: [], //选择对应市的区数据
        // 请求返回的用户信息
        UserData: {
          // access: '', //秘钥
          // avatar:'', 头像
          blind: 1, //绑定
          status: '',// 状态
          // nickName:'', 昵称
          coin: 0, //雅拉币
          bullion: 0, //银条
          // phone:'', 手机号
        },
        //奖池商品
        TurntableMessage: {
          row: [],
          pass: '',
          base: {
            bullion: 4,
            coin: 1,
            common: {
              progress: "start",  // start正常  end已结束 off待解锁
              start_leave: 0,
            },
            // 高级宝箱
            higher: {
              progress: "off",
              start_leave: 4881812,
            },
          },
        },
        simpleArr: {
          // 0: {
          //   area: 2,
          //   id: 32,
          //   intro: "",
          //   kind: 1,
          //   pic: "goods/1628740356/61149b04cba87.jpg",
          //   title: "Xbox Series X 一台",
          //   worth: 1,
          // }
        },
        // 任务列表
        User_TaskList: {
          id: 1,
          ids: "1",
          intro: "比索*2",
          kind: 3,
          pic: "icon/coin.png",
          show: 2,
          sign: "",
          sort: 1,
          state: 1,
          title: "每日访问",
          type: 1,
          worth: 2,
        },
        // 里程碑进度
        MilestoneSchedule: {},
        goal: 0,//里程碑进度
        unlock: 1,
        unPart: 0,
        // 中奖纪录
        WinningRecord: {
          // 0: {
          //   give: 2,
          //   id: 113,
          //   intro: "",
          //   kind: 2,
          //   pic: "",
          //   receive_time: "",
          //   title: "",
          // },
        },
        // 说明
        ReturnInfo: '',
        WinningItems: -1,
        PostcardRules: false,
        GroupRules: false,
        YarraRule: false,
        MilestoneRule: false,

        WinningRecordBulletBox: false,
        WinningNum: -1,
        kinNumber: '',  //kind 奖品类型
        switer: false,
        isCanWinning: true, //是否可以抽奖
        virtual: '',//优惠券
        mapNum: 0,
        simpleArrShow: true,
        simpleID: -1,//抽奖ID
        common: "",//普通宝箱进度
        higher: "",//高级宝箱进度
        times: null,
        start: null,

        tructions: false,
        wenToasShow: false,
      }
    },
    created() {
      store.remove('code');
      // this.UserStatus = getCookieValue("status")//用户登录状态cookie
      this.UserStatus = store.get('status')//用户登录状态

      // 登录
      if (this.UserStatus) {
        // 用户信息 
        this.UserData = store.get('User_information');
        //奖池商品
        this.TurntableMessage = store.get('TurntableMessage')
        // 任务列表
        this.User_TaskList = store.get("User_TaskList")
        //中奖纪录
        this.WinningRecord = store.get("WinningRecord");
        //里程碑进度
        this.MilestoneSchedule = store.get("MilestoneSchedule")
        // 更新用户信息
        this.getUserDetail()
        // 中奖纪录 ok
        this.getgetRecord();
        // 任务列表
        this.getList(1);
      }
      // 里程碑进度  *ok
      this.getList(2);
      // 奖池
      this.getlotteryAward();
    },
    mounted() {
      // Rotation(); //轮播图
      // this.$nextTick(() => {
      //   Rotation(); //轮播图
      // });

      this.PendantIsOpen();//精英补给开放 展示挂件
      window.addEventListener('scroll', this.scrollToTop)
    },
    // beforeUpdate(){
    //   // this.$nextTick(() => {
    //     Rotation(); //轮播图
    //   // });
    // },
    destroyed() {
      window.removeEventListener('scroll', this.scrollToTop)
    },
    methods: {
      onwenToasShow() {
        this.wenToasShow = !this.wenToasShow;
      },

      // 里程碑背景进度
      OnBigPicture(i) {
        this.BigPictureShow = true;
        document.querySelector(".max").src = `./image/guideMax/${this.velUrl[i]}.jpg`;
      },
      // log回去顶部
      Backtotop() {
        Top_Backto('#headerTop');
      },
      // 规则说明 弹框
      OnRuleitem(i) {
        if (i == 0) {
          this.PostcardRules = true;
        }
        if (i == 1) {
          this.GroupRules = true;
        }
        if (i == 2) {
          this.YarraRule = true;
        }
      },
      //雅拉旅游指南 轮播图滑动左右切换
      prev() {
        if (!this.mapNum <= 0) {
          this.mapNum--
          this.$refs.slide.style = `transform: translateX(${this.mapNum * -1170}px)`;
        }
      },
      next() {
        if (this.mapNum < 2) {
          this.mapNum++
          this.$refs.slide.style = `transform: translateX(${this.mapNum * -1170}px)`;
        }
      },
      // 登录注册弹框
      login() {
        this.pear = true;
      },
      //登录注册关闭按钮
      closeButton() {
        this.pear = false;//关闭页面弹窗
        // 清空表单数据
        this.user.mobilephone = '';
        this.user.code = '';
        store.remove('code')//清除
      },
      // 开启宝箱
      OpenTreasureChest(index) {
        if (!this.UserStatus) { this.login(); return false; }
        if (index === 1 && this.isCanWinning) {
          this.getlotteryReceive(1);// 普通宝箱
        }
        if (index === 2 && this.isCanWinning) {
          this.getlotteryReceive(2);// 高级宝箱
        }
      },
      //关闭宝箱按钮
      closeBox() {
        this.WinningBox_Show = false; //中奖信息弹框
        this.task_list_show = false; //获取更多
        this.Lottery_show = false; //中奖规则 中奖纪录
        this.Address_show = false;//收获地址
        this.reward = false;//里程碑奖励
        this.PostcardRules = false;
        this.GroupRules = false;
        this.YarraRule = false;
        this.MilestoneRule = false;
        this.WinningRecordBulletBox = false;//查看奖品信息
        this.NcbNum = -1;
        clearInterval(this.times);
      },
      //获取更多
      click_more() {
        this.task_list_show = true;
        // 任务列表
        this.getList(1);
      },
      // 查看 中奖信息详情
      onRecord(i) {
        this.WinningRecordBulletBox = true;
        this.WinningNum = i;
        this.kinNumber = this.WinningRecord[i].kind
      },
      //立即组队 
      Teamupnow(i) {
        if (i === 0) {
          // window.open("http://yubi.aju.cn/card/");
          location.replace('new/card/index.html');
        }
        if (i === 1) {
          this.flag = true;
          this.$refs.box.style = "z-index:2;opacity: 1;";
          this.$refs.cardBox.style = "opacity:0";
        }
        if (i === 2) {
          // window.open("http://yubi.aju.cn/puzzle/");
          location.replace('puzzle/index.html');
        }
      },
      //立即组队滑块关闭按钮
      disappear() {
        this.$refs.box.style = "z-index:0;opacity: 0;";
        this.flag = false;
        this.$refs.cardBox.style = "opacity:1";
      },
      //立即绑定
      bind_now() {
        this.UserData.blind = 2;
        vant.Toast("绑定成功!")
      },
      // 立即预购按钮
      immediately() {
        this.PreOrderStatus = true;
        vant.Toast("预购成功!")
      },
      // 里程碑 开启
      status(i) {
        if (i === 0) {
          this.oneShow = !this.oneShow;
        }
        if (i === 1) {
          this.twoShow = !this.twoShow
        }
        if (i === 2) {
          this.threeShow = !this.threeShow
        }
        if (i === 3) {
          this.threeShow = !this.threeShow
        }
        if (i === 4) {
          this.fourShow = !this.fourShow
        }
        if (i === 5) {
          this.sixShow = !this.sixShow
        }
      },
      // 里程碑显示隐藏
      MilestoneDisplay(i) {
        let self = this;
        if (i === 1) {
          return this.oneShow === true;
        }
        if (i === 2) {
          return this.twoShow === true;
        }
        if (i === 3) {
          return this.threeShow === true;
        }
        if (i === 4) {
          return this.fourShow === true;
        }
        if (i === 5) {
          return this.fiveShow === true;
        }
        if (i === 6) {
          return this.sixShow === true;
        }
      },
      // 里程碑 关闭
      statusSwitch() {
        // this.oneShow = false;
        // this.twoShow = false;
        // this.threeShow = false;
      },
      //里程碑 领取奖励
      ReceiveRewards(i) {
        if (!this.UserStatus) {
          this.login();
          return false;
        }
        let sign = this.MilestoneSchedule[i].sign
        $axios.getreceiveAward({
          access: this.UserData.access,
          sign: sign,
        }).then((res) => {
          if (res.data.status == 2) {
            vant.Toast("领取成功!")
            this.getUserDetail()//更新用户信息
            this.getList(2)// 里程碑进度  *ok
          }
        }).catch((err) => {

        })
      },
      // 领取 查看奖励 按钮
      receive(i) {
        if (!this.UserStatus) {
          this.login();
          return false;
        }
        //里程碑进度
        this.getList(2)
        this.reward = true;
        this.NcbNum = i;

        // clearInterval(this.times);
        // this.times = setInterval(() => {
        //   this.MilestoneSchedule[i].expire -= 1;
        //   if (this.MilestoneSchedule[i].expire <= 0) {
        //     // self.isPuzzle = true;//禁止点击图片
        //     clearInterval(this.times);
        //   }
        // }, 1000);
      },
      //获取验证码倒计时
      CodeDown() {
        let el = document.getElementsByClassName("fixed")[0]
        const reg = /^1((34[0-8]\d{7})|((3[0-3|5-9])|(4[5-7|9])|(5[0-3|5-9])|(66)|(7[2-3|5-8])|(8[0-9])|(9[1|8|9]))\d{8})$/;
        let self = this;
        if (!this.canClick) return
        if (!reg.test(this.user.mobilephone)) {
          vant.Toast("请输入正确的手机号!")
          return false;
        }
        var codeStatus = store.get('code');
        // var codeStatus = true;
        if (!codeStatus) {
          el.style = 'display:block'; //打开验证码滑块弹框
        } else {
          if (!this.canClick) return //节流 每60秒只执行一次
          self.canClick = false; //按钮不可点击
          this.codeStatus = false;
          let clock = window.setInterval(() => {
            self.totalTime--
            self.content = self.totalTime + 's后重新发送';

            if (self.totalTime === -1) {
              clearInterval(clock)
              self.content = '获取验证码';
              self.totalTime = 60;//验证码间隔时间
              self.canClick = true //重新开启
              self.phoneCode = ''  //验证码清除
              store.set('code', false)
            }
          }, 1000)

          // 请求手机验证码
          $axios.getsendReport({ phone: this.user.mobilephone })
            .then((res) => {
              //(res, "获取手机验证码")
              if (res.data.code == 200) {
                vant.Toast("发送成功")
              } else {
                vant.Toast("发送失败!")
              }
            })
        }
      },
      // 立即登录
      Signin() {
        const reg = /^1((34[0-8]\d{7})|((3[0-3|5-9])|(4[5-7|9])|(5[0-3|5-9])|(66)|(7[2-3|5-8])|(8[0-9])|(9[1|8|9]))\d{8})$/;
        const regcode = /^[0-9]{6}$/;
        if (!reg.test(this.user.mobilephone)) {
          vant.Toast("请填写正确的手机号!")
          return false
        }
        if (this.user.code == '') {
          vant.Toast("验证码不能为空!")
          return false
        }
        if (!regcode.test(this.user.code)) {
          vant.Toast("验证码长度不符合!")
          return false
        }
        $axios.getLogin({
          phone: this.user.mobilephone,
          code: this.user.code,
        }).then((res) => {
          //(res, "手机号")
          if (res.data.status == 2) {
            vant.Toast("登录成功!")
            store.set('status', true);
            this.UserStatus = true;
            store.set('User_information', res.data.data);
            this.UserData = res.data.data;

            this.getlotteryAward();// 奖池商品
            this.getList(2);// 里程碑进度
            this.getUserDetail();// 更新用户信息
            setTimeout(() => {
              this.closeButton(); //关闭弹窗
            }, 680)
          }
          if (res.data.status == 1) {
            if (res.data.code == 1200) {
              vant.Toast("验证码错误!")
              return false;
            }
            if (res.data.code == 1100) {
              vant.Toast("验证码已经失效!")
              return false;
            }
            if (res.data.code == 1005) {
              // vant.Toast(res.data.info);
              vant.Toast("用户状态异常，请联系客服");
              return false;
            }
          }

        }).catch((err) => { })
      },
      // 抽奖
      getlotteryReceive(index) {
        // this.isCanWinning = false; //避免多次触发

        // // console.log(this.UserData.coin)
        // // console.log(this.TurntableMessage.base.coin)

        // if (this.UserData.coin < this.TurntableMessage.base.coin && index == 1) {
        //   vant.Toast("可用比索不足")
        //   this.isCanWinning = true; //避免多次触发
        //   return false
        // }//普通宝箱
        // if (this.UserData.bullion < this.TurntableMessage.base.bullion && index == 2) {
        //   vant.Toast("可用银条不足")
        //   this.isCanWinning = true; //避免多次触发
        //   return false
        // }//高级宝箱
        // console.log(123)
        // 抽奖领奖  ok  
        $axios.getlotteryReceive({
          access: this.UserData.access,
          pass: this.TurntableMessage.pass,
          area: index,
        }).then((res) => {
          this.simpleID = -1;
          console.log(res, "抽奖")
          if (res.data.status === 2) {
            // 更新用户信息
            this.getUserDetail();
            // 中奖记录
            this.getgetRecord();
            this.virtual = res.data.data.virtual;//券
            this.simpleID = res.data.data.id; //中奖id
            console.log(this.simpleID, "中奖id")
            this.$nextTick(() => {
              this.simpleArr = this.TurntableMessage.row.filter((item, i) => {
                return item.id == res.data.data.id //奖品id比对
              })
              if (res.data.data.id == -1) {
                this.simpleArrShow = false;
              }
              this.WinningBox_Show = true;//奖品弹框
              // this.isCanWinning = true; //可继续抽奖
              // console.log(this.simpleArr)
              this.Reload(res.data.code);//验证多设备登录
            });
          } else {
            if (res.data.code == 1200) {
              vant.Toast("抽奖人数较多，请稍后再试");
            }
            if (index == 1 && res.data.code == 1010) {
              vant.Toast("可用比索不足");
            }
            if (index == 2 && res.data.code == 1010) {
              vant.Toast("可用银条不足");
            }
          }
        }).catch((err) => { })
      },
      // 中奖纪录 ok
      getgetRecord() {
        $axios.getgetRecord({ access: this.UserData.access })
          .then((res) => {
            console.log(res, "中奖纪录")
            this.WinningRecord = res.data.data;
            store.set('WinningRecord', this.WinningRecord)
            // this.Reload(res.data.code);
          }).catch((err) => { })
      },
      // 任务列表1 里程碑进度2  *ok
      getList(item) {
        let data = {
          area: item
        }
        if (this.UserStatus) {
          data = {
            area: item,
            access: this.UserData.access,
          }
        }
        $axios.getList(data)
          .then((res) => {
            if (item == 2) {
              console.log(res, "里程碑")
              this.MilestoneSchedule = res.data.data.detail;//里程碑数据
              store.set("MilestoneSchedule", res.data.data.detail);

              this.goal = res.data.data.coinCount;//贡献比索
              this.unPart = res.data.data.unPart;//文字节点
              this.unlock = res.data.data.unlock;//进度节点


              // if (this.MilestoneSchedule) {
              //   this.MilestoneSchedule.forEach((item) => {
              //     return item.reach_time = getTime(Number(item.expire - myDate), 1)
              //   })
              // }
              // this.$nextTick(() => {

              // });
              // this.countDown()

            } else {
              // 任务列表
              this.User_TaskList = res.data.data
              store.set('User_TaskList', this.User_TaskList)
            }
          }).catch((err) => { })

      },
      // 奖池  ok
      getlotteryAward() {
        let data = {
          area: 1,
        }
        if (this.UserStatus) {
          data = {
            access: this.UserData.access,
          }
        }
        $axios.getlotteryAward(data)
          .then((res) => {
            console.log(res, "奖池")
            store.set('TurntableMessage', res.data.data)
            this.TurntableMessage = res.data.data;

            let { common, higher } = res.data.data.base;
            console.log(common, higher, "宝箱开启状态")
            this.common = common;
            this.higher = higher;
            this.$nextTick(() => {
              Rotation();
            });
          }).catch((err) => { })
      },
      //里程碑奖品使用说明
      instructions(i) {
        this.tructions = true;
        console.log(i)
      },
      // 优惠券 倒计时
      // countDown(data) {
      //   clearInterval(this.times);
      //   this.start = data;
      //   this.times = setInterval(() => {
      //     this.start -= 1000;
      //     if (this.start <= 0) {
      //       // self.isPuzzle = true;//禁止点击图片
      //       clearInterval(this.times);
      //       // vant.Toast('时间到!');
      //       // self.FailedPopUp = true;//失败弹框

      //     }
      //     return getTime(data, 1)
      //     // $("#Expire").html(getTime(data, 1));
      //   }, 1000);
      // },
      //高级宝箱倒计时
      GetDate(item) {
        return getTime(item, 2)
      },
      //多设备登录 踢出
      Reload(data) {
        if (data == 1008) {
          store.clear()//清空本地数据
          vant.Toast("当前设备已在其他设备登录,请重新登录");
          this.UserStatus = false;//状态更新
          location.reload()// 刷新页面
        }
      },
      // 用户信息
      getUserDetail() {
        $axios.getUserDetail({ access: this.UserData.access, })
          .then((res) => {
            if (res.data.status == 2) {

              this.UserData = res.data.data;
              store.set("User_information", res.data.data); //更新用户信息
              // 自动任务
              if (Object.keys(res.data.data.award).length) {
                let award = res.data.data.award
                // vant.Toast(award.title + '奖励' + award.tip + '+' + award.worth);
                vant.Toast.success({
                  duration: 2500,
                  message: award.title + '奖励' + award.tip + '+' + award.worth,
                });
                this.getUserDetail();
              }
            } else {
              this.Reload(res.data.code);
            }
          })
          .catch((err) => {

          })
      },
      //退出登录
      Log_out() {
        // document.cookie = "status = false"; //更新登录状态
        store.clear()//清空本地数据
        this.UserStatus = false;
        this.UserData = {};//数据清空
        vant.Toast("退出成功")
        this.PreOrderStatus = false;//预购
      },
      //抽奖规则,中奖纪录 点击事件
      Lottery(i) {
        if (i === 0) {
          this.Lottery_show = true;
          this.Lottery_item = 0;
        }
        if (i === 1) {
          if (!this.UserStatus) {
            this.login();
            return false;
          }
          this.Lottery_show = true;
          this.Lottery_item = 1;
          // 中奖纪录 ok
          this.getgetRecord();
        }
      },
      //收获地址点击事件
      Address() {
        // this.Lottery_show = false;//中奖记录
        this.Address_show = true;//收获地址

        // 如果已经填写过收获地址
        if (this.UserData.address) {
          this.midd_list = JSON.parse(this.UserData.address)
          this.arr.forEach((item) => {
            if (item.name === this.midd_list.province) {
              this.cityArr = item.city;
            }
          });
          this.cityArr.forEach((item) => {
            if (item.name === this.midd_list.city) {
              this.areaArr = item.area;
            }
          });

        }

      },
      // 收货地址信息保存
      SaveInformation() {
        let self = this;
        let res = this.midd_list
        if (!this.isCanSubmitAddress) {
          return false;
        }
        if (this.midd_list.name === '') {
          vant.Toast("名字不能为空")
          return false;
        }
        if (!regPhone.test(this.midd_list.phone)) {
          vant.Toast("手机号格式错误")
          return false;
        }
        if (!(this.midd_list.province !== '' && this.midd_list.city !== '' && this.midd_list.address !== '')) {
          vant.Toast("地区不能为空")
          return false;
        }
        this.isCanSubmitAddress = false;
        var collect = {
          name: this.midd_list.name,
          phone: this.midd_list.phone,
          province: this.midd_list.province,
          city: this.midd_list.city,
          area: this.midd_list.area,
          address: this.midd_list.address
        }
        //收货地址绑定 ok
        $axios.getblindAddress({
          access: self.UserData.access,
          detail: JSON.stringify(collect),
        }).then((res) => {
          this.isCanSubmitAddress = true;
          vant.Toast("提交成功！")
          this.Address_show = false;
          this.getUserDetail();//更新
        }).catch((err) => { })
      },
      // 是否可以修改地址 
      addressIsCanUpdate() {
        var nowtime = new Date(),  //获取当前时间
          endtime = new Date("2021-10-22 00:00:00");  //定义结束时间
        // console.log(nowtime.getTime() >= endtime.getTime(), "10.22")
        return nowtime.getTime() >= endtime.getTime()
      },
      //高级宝箱 挂件开启
      PendantIsOpen() {
        var nowtime = new Date(),  //获取当前时间
          endtime = new Date("2021-10-14 00:00:00");  //定义结束时间
        let flg = nowtime.getTime() >= endtime.getTime();
        // 到达指定时间
        if (flg) {
          this.Notlogged = true;
        }
        // 登录后
        if (flg && this.UserStatus) {
          this.openDataShow = true;
        }
      },
      //返回图片地址
      setUrl(item) {
        return imgUrl + item;
      },
      // 侧边栏
      backTop() {
        Top_Backto('#id3');
      },
      //页头标题点击事件
      onclick(i) {
        this.headerNum = i;
        if (i === 0 || i === 1 || i === 2) {
          Top_Backto('#title');
          return false
        }
        Top_Backto(`#id${i}`);

        this.listBoxState = false;
        let timeId;
        clearTimeout(timeId);
        timeId = setTimeout(() => {
          this.listBoxState = true;
        }, 2500);
      },
      //监听滚动条
      scrollToTop() {
        const that = this
        let scrollTop = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop
        that.scrollTop = scrollTop

        if (that.listBoxState) {
          that.textheader.map((item, i) => {
            // 获取监听元素距离视窗顶部距离
            if (i > 2) {
              var offsetTop = document.getElementById(`id${i}`).offsetTop;
              // 获取监听元素本身高度
              var scrollHeight = document.getElementById(`id${i}`).scrollHeight;

              // 如果 dom滚动位置 >= 元素距离视窗距离 && dom滚动位置 <= 元素距离视窗距离+元素本身高度
              // 则表示页面已经滚动到可视区了。
              if (scrollTop >= offsetTop && scrollTop <= (offsetTop + scrollHeight)) {
                // 导航栏背景色选中
                that.headerNum = i;
              }
            } else {
              // that.headerNum = 2;
            }
          })
        }

        if (that.scrollTop > 650) {
          that.btnFlag = true;
        } else {
          that.btnFlag = false;
        }
      },
      //更新市数据
      updataCity() {
        this.arr.forEach((item, index) => {
          if (item.name === this.midd_list.province) {
            this.cityArr = item.city;
          }
        });
        // 初始化默认值
        this.midd_list.city = this.cityArr
      },
      //更新区数据
      updataSub() {
        this.cityArr.forEach((item, index) => {
          if (item.name === this.midd_list.city) {
            this.areaArr = item.area;
          }
        });
        this.midd_list.area = this.areaArr;
      },
    },
    computed: {
      // 日常任务
      activeUsers1() {
        if (this.task_list_show && this.User_TaskList) {
          return this.User_TaskList.filter((item) => {
            return item.type == 1
          })
        }
      },
      // 一次性任务
      activeUsers2() {
        if (this.task_list_show && this.User_TaskList) {
          return this.User_TaskList.filter((item) => {
            return item.type == 2
          })
        }
      },
      Winningfn() {
        if (this.Lottery_item == 1) {
          return this.WinningRecord.filter((item, index) => {
            return index == this.WinningNum
          })
        }
      },
    },
    watch: {
      // 验证码 
      "codeStatus"(val) {
        if (val) {
          this.CodeDown();
        }
      },
    }
  })


  // // var touchMe = $(".touchMe");


  // var audioElement = document.createElement('audio');
  // audioElement.setAttribute('src', './image/click.mp3');

  // audioElement.addEventListener("load", function () {
  //   audioElement.play();
  // }, true);



  // for (let i = 0; i < touchMe.length; i++) {
  //   $(".touchMe").eq(i).bind("click",{
  //     index: i
  //   },audioElement.play()) 











}

